import { useState } from "react";
import { useApp } from "../../lib/store";
import { timeAgo, visibleName } from "../../lib/logic";
import { Avatar, Button, Chip, Icon, INPUT_CLS, Reveal, SectionTitle } from "../../components/ui";
import type { BannedWordSeverity, ContentFlag, FlagStatus } from "../../lib/types";

export function ModerationView() {
  const { db, me, reviewFlag, addBannedWord, removeBannedWord, toast } = useApp();
  const [newWord, setNewWord] = useState("");
  const [newSeverity, setNewSeverity] = useState<BannedWordSeverity>("WARN");
  const [filterStatus, setFilterStatus] = useState<FlagStatus | "ALL">("PENDING");

  if (!me) return null;

  // Получаем группы, которые курирует этот учитель
  const teacherGroups = db.groups.filter((g) => g.teacherId === me.id);
  const teacherGroupIds = teacherGroups.map((g) => g.id);

  // Фильтруем флаги по группам учителя
  const relevantFlags = db.contentFlags.filter((flag) => {
    if (flag.contentType === "MESSAGE") {
      const msg = db.messages.find((m) => m.id === flag.contentId);
      return msg && teacherGroupIds.includes(msg.classGroupId);
    }
    // Для других типов контента показываем все флаги
    return true;
  });

  const filteredFlags = filterStatus === "ALL" ? relevantFlags : relevantFlags.filter((f) => f.status === filterStatus);
  const pendingCount = relevantFlags.filter((f) => f.status === "PENDING").length;

  const handleReview = (flagId: string, status: FlagStatus) => {
    reviewFlag(flagId, status);
    toast(status === "REVIEWED_OK" ? "Контент одобрен" : "Контент удалён");
  };

  const handleAddWord = () => {
    if (!newWord.trim()) {
      toast("Введите слово", "warn");
      return;
    }
    addBannedWord(newWord, newSeverity);
    setNewWord("");
    toast("Запрещённое слово добавлено");
  };

  const handleRemoveWord = (wordId: string) => {
    removeBannedWord(wordId);
    toast("Запрещённое слово удалено");
  };

  const getFlagContent = (flag: ContentFlag) => {
    if (flag.contentType === "MESSAGE") {
      return db.messages.find((m) => m.id === flag.contentId);
    }
    if (flag.contentType === "DIARY_ENTRY") {
      return db.diaryEntries.find((d) => d.id === flag.contentId);
    }
    if (flag.contentType === "COLLAB_DOC") {
      return db.docs.find((d) => d.id === flag.contentId);
    }
    return null;
  };

  return (
    <div className="flex flex-col gap-6">
      {/* -------- очередь флагов -------- */}
      <section>
        <SectionTitle
          kicker="модуль moderation · очередь модерации"
          title="Флаги контента"
          right={<Chip tone={pendingCount ? "coral" : "green"}>{pendingCount ? `${pendingCount} ожидают` : "очередь пуста"}</Chip>}
        />

        <div className="mb-4 flex gap-2">
          {(["PENDING", "REVIEWED_OK", "REVIEWED_REMOVED", "ALL"] as const).map((status) => (
            <button
              key={status}
              onClick={() => setFilterStatus(status)}
              className={`cursor-pointer rounded-lg border-2 px-3 py-1.5 text-[13px] font-bold transition ${
                filterStatus === status ? "border-pine bg-pine-soft text-pine-deep" : "border-line bg-card text-ink-2 hover:border-ink-3/40"
              }`}
            >
              {status === "ALL" ? "Все" : status === "PENDING" ? "Ожидают" : status === "REVIEWED_OK" ? "Одобрены" : "Удалены"}
            </button>
          ))}
        </div>

        {filteredFlags.length === 0 ? (
          <div className="rounded-xl border border-dashed border-line bg-card/60 px-6 py-10 text-center">
            <span className="mx-auto grid h-12 w-12 place-items-center rounded-full bg-pine-soft text-pine">
              <Icon name="shield" size={22} />
            </span>
            <p className="mt-3 font-display text-[14px] font-bold text-ink">Нет флагов</p>
            <p className="mx-auto mt-1 max-w-sm text-[12.5px] text-ink-3">
              {filterStatus === "PENDING" ? "Все флаги обработаны" : "Нет флагов с выбранным статусом"}
            </p>
          </div>
        ) : (
          <div className="grid gap-3 lg:grid-cols-2">
            {filteredFlags.map((flag, i) => {
              const content = getFlagContent(flag);
              const author = content && "authorId" in content ? db.users.find((u) => u.id === content.authorId) : null;
              const group = content && "classGroupId" in content ? db.groups.find((g) => g.id === content.classGroupId) : null;

              return (
                <Reveal key={flag.id} delay={i * 60}>
                  <div
                    className={`card-hover rounded-xl border-2 bg-card p-4 ${
                      flag.status === "PENDING" ? "border-coral/30" : flag.status === "REVIEWED_OK" ? "border-pine/30" : "border-ink-3/30"
                    }`}
                  >
                    <div className="mb-2 flex items-center gap-2.5">
                      <Chip
                        tone={
                          flag.status === "PENDING" ? "coral" : flag.status === "REVIEWED_OK" ? "green" : "ink"
                        }
                      >
                        {flag.status === "PENDING" ? "Ожидает" : flag.status === "REVIEWED_OK" ? "Одобрено" : "Удалено"}
                      </Chip>
                      <Chip tone="sky">{flag.contentType}</Chip>
                      {group && <Chip tone="ink">{group.name}</Chip>}
                    </div>

                    {author && (
                      <div className="mb-2 flex items-center gap-2">
                        <Avatar user={author} size={28} />
                        <div className="leading-tight">
                          <p className="text-[12.5px] font-bold text-ink">{visibleName(me.role, author)}</p>
                          <p className="text-[11px] text-ink-3">{timeAgo(flag.createdAt)}</p>
                        </div>
                      </div>
                    )}

                    {content && "content" in content && (
                      <p className="mb-2 rounded-lg border border-coral/25 bg-coral-soft/50 px-3 py-2 text-[13px] leading-relaxed text-[#7c3018]">
                        {flag.status === "REVIEWED_REMOVED" ? (
                          <span className="select-none blur-[4px]">{content.content}</span>
                        ) : (
                          content.content
                        )}
                      </p>
                    )}

                    <p className="mb-2 flex items-center gap-1.5 text-[12px] font-semibold text-ink-2">
                      <Icon name="alert" size={13} /> {flag.flagReason}
                    </p>

                    {flag.status === "PENDING" && (
                      <div className="mt-3 flex gap-2">
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => handleReview(flag.id, "REVIEWED_OK")}
                        >
                          <Icon name="check" size={13} /> Оставить
                        </Button>
                        <Button
                          size="sm"
                          variant="danger"
                          onClick={() => handleReview(flag.id, "REVIEWED_REMOVED")}
                        >
                          <Icon name="trash" size={13} /> Удалить
                        </Button>
                      </div>
                    )}

                    {flag.status !== "PENDING" && flag.reviewedBy && (
                      <p className="mt-2 text-[11px] text-ink-3">
                        Проверено: {db.users.find((u) => u.id === flag.reviewedBy)?.displayName ?? "—"} ·{" "}
                        {flag.reviewedAt && timeAgo(flag.reviewedAt)}
                      </p>
                    )}
                  </div>
                </Reveal>
              );
            })}
          </div>
        )}
      </section>

      <div className="grid gap-6 lg:grid-cols-[1fr_340px]">
        {/* -------- SafetyLog -------- */}
        <Reveal>
          <section>
            <SectionTitle
              kicker="append-only · никогда не удаляется"
              title="SafetyLog"
              right={<Chip tone="ink">{db.safetyLog.length} записей</Chip>}
            />
            <div className="max-h-[420px] overflow-y-auto rounded-xl border border-line bg-card">
              {db.safetyLog.slice().reverse().map((e) => {
                const actor = db.users.find((u) => u.id === e.actorId);
                const tone =
                  e.actionType === "MESSAGE_HIDDEN" || e.actionType === "MESSAGE_DELETED"
                    ? "coral"
                    : e.actionType === "USER_SUSPENDED" || e.actionType === "USER_WARNED"
                      ? "amber"
                      : "green";
                return (
                  <div key={e.id} className="flex items-start gap-3 border-b border-line/60 px-4 py-2.5 last:border-0">
                    <Chip tone={tone as "coral" | "amber" | "green"} className="mt-0.5 shrink-0">
                      {e.actionType}
                    </Chip>
                    <div className="min-w-0 flex-1 leading-tight">
                      <p className="text-[12.5px] font-bold text-ink">{e.targetType}: {e.targetId}</p>
                      <p className="text-[11.5px] text-ink-3">
                        {e.reason} · актер: {actor ? visibleName(me.role, actor) : e.actorId}
                      </p>
                    </div>
                    <span className="shrink-0 text-[11px] text-ink-3">{timeAgo(e.createdAt)}</span>
                  </div>
                );
              })}
            </div>
          </section>
        </Reveal>

        {/* -------- словарь запрещённых слов -------- */}
        <Reveal delay={70}>
          <section>
            <SectionTitle kicker="конфигурируется учителем/админом" title="Запрещённые слова" />
            <div className="rounded-xl border border-line bg-card p-4">
              <div className="flex gap-2">
                <input
                  className={INPUT_CLS}
                  placeholder="Новое слово…"
                  value={newWord}
                  onChange={(e) => setNewWord(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter" && newWord.trim()) {
                      handleAddWord();
                    }
                  }}
                />
                <select
                  className={INPUT_CLS + " !w-32"}
                  value={newSeverity}
                  onChange={(e) => setNewSeverity(e.target.value as BannedWordSeverity)}
                >
                  <option value="WARN">WARN</option>
                  <option value="AUTO_HIDE">AUTO_HIDE</option>
                </select>
                <Button onClick={handleAddWord}>
                  <Icon name="plus" size={14} />
                </Button>
              </div>
              <div className="mt-3 flex flex-col gap-1.5">
                {db.bannedWords.map((bw) => (
                  <div key={bw.id} className="flex items-center justify-between rounded-lg border border-line bg-paper px-3 py-2">
                    <div className="flex items-center gap-2">
                      <span className="text-[13px] font-bold text-ink">«{bw.word}»</span>
                      <Chip tone={bw.severity === "AUTO_HIDE" ? "coral" : "amber"}>
                        {bw.severity === "AUTO_HIDE" ? "Автоскрытие" : "Предупреждение"}
                      </Chip>
                    </div>
                    <button
                      onClick={() => handleRemoveWord(bw.id)}
                      className="cursor-pointer text-ink-3 transition hover:text-coral"
                      aria-label={`Удалить ${bw.word}`}
                    >
                      <Icon name="trash" size={14} />
                    </button>
                  </div>
                ))}
              </div>
              <p className="mt-3 text-[11.5px] leading-relaxed text-ink-3">
                <b>AUTO_HIDE</b> — сообщение автоматически скрывается и создаётся флаг.
                <br />
                <b>WARN</b> — сообщение остаётся видимым, но создаётся флаг для проверки учителем.
              </p>
            </div>
          </section>
        </Reveal>
      </div>
    </div>
  );
}
