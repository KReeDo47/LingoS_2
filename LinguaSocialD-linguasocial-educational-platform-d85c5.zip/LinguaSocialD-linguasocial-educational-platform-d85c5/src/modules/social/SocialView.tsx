import { useEffect, useMemo, useRef, useState } from "react";
import { useApp } from "../../lib/store";
import { avgScoreFromProgress, clockTime, daysLeft, questProgress, reviewAverage, suggestTandems, timeAgo, visibleName } from "../../lib/logic";
import { fetchGroupMessages } from "./chatApi";
import { Avatar, Button, Chip, Icon, INPUT_CLS, Modal, Reveal, Ring, SectionTitle } from "../../components/ui";
import type { IconName } from "../../components/ui";
import type { GroupQuest, PairedReason, RubricScore, TaskSubmission, User } from "../../lib/types";
import { RUBRIC_CRITERIA } from "../../lib/types";

type Nav = (r: string) => void;

/* ============================================================
   Модуль social (QWEN.md, модуль 3): тандемы · квесты · документы ·
   peer-review · чат (поллинг 5 с, только внутри classGroupId).
   ============================================================ */

function Empty({ icon, title, text }: { icon: IconName; title: string; text: string }) {
  return (
    <div className="rounded-xl border border-dashed border-line bg-card/60 px-6 py-10 text-center">
      <span className="mx-auto grid h-12 w-12 place-items-center rounded-full bg-paper-2 text-ink-3"><Icon name={icon} size={22} /></span>
      <p className="mt-3 font-display text-[14px] font-bold text-ink">{title}</p>
      <p className="mx-auto mt-1 max-w-sm text-[12.5px] text-ink-3">{text}</p>
    </div>
  );
}

/* ================= тандемы ================= */
function TandemTab({ gid, teacherMode, meId }: { gid: string; teacherMode: boolean; meId: string }) {
  const { db, me, createTandem, autoPairTandems, toast } = useApp();
  const [a, setA] = useState("");
  const [b, setB] = useState("");
  const [reason, setReason] = useState<PairedReason>("ZPD_MENTOR");
  const [showPreview, setShowPreview] = useState(false);

  const students = db.users.filter((u) => u.role === "STUDENT" && u.classGroupId === gid);
  const active = db.tandems.filter((t) => t.classGroupId === gid && t.active);
  const suggestions = useMemo(() => suggestTandems(db, gid), [db, gid]);
  const u = (id: string | null) => db.users.find((x) => x.id === id);

  const myTandem = !teacherMode ? active.find((t) => t.studentAId === meId || t.studentBId === meId) : null;
  const partner = myTandem ? u(myTandem.studentAId === meId ? myTandem.studentBId : myTandem.studentAId) : undefined;

  return (
    <div className="flex flex-col gap-5">
      {teacherMode ? (
        <Reveal>
          <div className="rounded-xl border border-line bg-card p-5">
            <SectionTitle
              kicker="QWEN.md п.1 · ZPD"
              title="Подбор пар"
              right={
                <div className="flex gap-2">
                  <Button size="sm" variant="soft" onClick={() => setShowPreview((v) => !v)}><Icon name="sparkle" size={13} /> Предпросмотр автоподбора</Button>
                  <Button size="sm" onClick={() => { const n = autoPairTandems(gid); toast(n ? `Создано ${n} пар «сильный + слабый»` : "Недостаточно учеников для пар", n ? "ok" : "warn"); }}>
                    <Icon name="users" size={13} /> Автоматически подобрать пары
                  </Button>
                </div>
              }
            />
            {showPreview && (
              <div className="mb-4 rounded-xl border border-amber/35 bg-amber-soft/50 p-4">
                <p className="text-[12px] font-bold uppercase tracking-wider text-[#7a4d0d]">suggestTandems(classGroupId) — по среднему score из StudentProgress</p>
                <div className="mt-2 grid gap-1.5 sm:grid-cols-2">
                  {suggestions.map((s) => (
                    <p key={s.a.id + s.b.id} className="rounded-lg bg-card/70 px-3 py-1.5 text-[12.5px] font-semibold text-ink">
                      {s.a.displayName} <span className="text-pine">⇄</span> {s.b.displayName} <span className="text-ink-3">· Δ {s.diff} п.п.</span>
                    </p>
                  ))}
                </div>
              </div>
            )}
            <div className="grid items-end gap-3 sm:grid-cols-[1fr_1fr_auto_auto]">
              <div>
                <label className="mb-1 block text-[12px] font-semibold text-ink-2">Ученик A</label>
                <select className={INPUT_CLS} value={a} onChange={(e) => setA(e.target.value)}>
                  <option value="">— выбрать —</option>
                  {students.map((s) => <option key={s.id} value={s.id}>{s.displayName}</option>)}
                </select>
              </div>
              <div>
                <label className="mb-1 block text-[12px] font-semibold text-ink-2">Ученик B</label>
                <select className={INPUT_CLS} value={b} onChange={(e) => setB(e.target.value)}>
                  <option value="">— выбрать —</option>
                  {students.map((s) => <option key={s.id} value={s.id}>{s.displayName}</option>)}
                </select>
              </div>
              <div>
                <label className="mb-1 block text-[12px] font-semibold text-ink-2">Основание</label>
                <select className={INPUT_CLS} value={reason} onChange={(e) => setReason(e.target.value as PairedReason)}>
                  <option value="ZPD_MENTOR">ZPD_MENTOR (сильный+слабый)</option>
                  <option value="PEER">PEER (равный уровень)</option>
                </select>
              </div>
              <Button onClick={() => {
                const res = createTandem(a, b, reason);
                if (!res.ok) return toast(res.error ?? "Не удалось создать тандем", "err");
                toast("Тандем создан");
                setA(""); setB("");
              }}><Icon name="plus" size={14} /> Создать</Button>
            </div>
          </div>
        </Reveal>
      ) : (
        myTandem && partner && (
          <Reveal>
            <div className="flex flex-wrap items-center gap-4 rounded-xl border border-pine/30 bg-pine-soft/40 p-5">
              <div className="flex items-center gap-2.5">
                <Avatar user={u(meId)!} size={44} mentor={myTandem.pairedReason === "ZPD_MENTOR" && myTandem.studentAId === meId} />
                <Icon name="refresh" size={18} className="text-pine" />
                <Avatar user={partner} size={44} mentor={myTandem.pairedReason === "ZPD_MENTOR" && myTandem.studentBId === meId} />
              </div>
              <div className="min-w-0 flex-1">
                <p className="font-display text-[15px] font-bold text-ink">Ваш тандем: {me && visibleName(me.role, partner)}</p>
                <p className="text-[12.5px] text-ink-2">
                  {myTandem.pairedReason === "ZPD_MENTOR"
                    ? "Пара «сильный + слабый»: объясняя друг другу, вы растёте оба (зона ближайшего развития)."
                    : "Пара примерно равного уровня — тренируйтесь на равных."}
                </p>
              </div>
              <Chip tone={myTandem.pairedReason === "ZPD_MENTOR" ? "amber" : "sky"}>{myTandem.pairedReason}</Chip>
            </div>
          </Reveal>
        )
      )}

      {active.length === 0 ? (
        <Empty icon="users" title="Активных тандемов нет" text={teacherMode ? "Подберите пары автоматически по среднему score или создайте вручную." : "Учитель ещё не распределил пары."} />
      ) : (
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {active.map((t, i) => {
            const sa = u(t.studentAId);
            const sb = u(t.studentBId);
            if (!sa || !sb) return null;
            return (
              <Reveal key={t.id} delay={i * 50}>
                <div className="card-hover rounded-xl border border-line bg-card p-4">
                  <div className="flex items-center justify-between">
                    <Chip tone={t.pairedReason === "ZPD_MENTOR" ? "amber" : "sky"}>{t.pairedReason === "ZPD_MENTOR" ? "ZPD · наставничество" : "PEER · равные"}</Chip>
                    <span className="text-[11px] font-semibold text-ink-3">{timeAgo(t.createdAt)}</span>
                  </div>
                  <div className="mt-3 flex items-center gap-2">
                    <Avatar user={sa} size={36} />
                    <span className="flex-1 text-center font-display text-[13px] font-bold text-pine">⇄</span>
                    <Avatar user={sb} size={36} />
                  </div>
                  <p className="mt-2 text-center text-[13px] font-bold text-ink">{sa.displayName} · {sb.displayName}</p>
                  <p className="mt-1 text-center text-[11.5px] text-ink-3">
                    ср. score: {Math.round(avgScoreFromProgress(db.progress, sa.id))}% / {Math.round(avgScoreFromProgress(db.progress, sb.id))}%
                  </p>
                </div>
              </Reveal>
            );
          })}
        </div>
      )}
    </div>
  );
}

/* ================= квесты ================= */
function QuestCard({ q, teacherMode, students, u, meId, navigate, assignQuestRole, delay }: {
  q: GroupQuest; teacherMode: boolean; students: User[]; u: (id: string | null) => User | undefined; meId: string;
  navigate: Nav; assignQuestRole: (questId: string, roleName: string, studentId: string | null) => void; delay: number;
}) {
  const pct = questProgress(q);
  const left = daysLeft(q.deadline);
  const myRole = q.roles.find((r) => r.assignedTo === meId);
  return (
    <Reveal delay={delay}>
      <div className="card-hover flex h-full flex-col rounded-xl border border-line bg-card p-4">
        <div className="flex items-start justify-between gap-2">
          <div>
            <p className="font-display text-[15px] font-bold leading-tight text-ink">{q.title}</p>
            <p className="mt-0.5 line-clamp-2 text-[12px] leading-relaxed text-ink-3">{q.description}</p>
          </div>
          <Chip tone={q.status === "done" ? "green" : left < 2 ? "coral" : "ink"}>
            <Icon name="clock" size={11} /> {q.status === "done" ? "завершён" : left < 0 ? "просрочен" : `${left} дн.`}
          </Chip>
        </div>
        <div className="mt-3 flex flex-col gap-1.5">
          {q.roles.map((r) => {
            const assignee = u(r.assignedTo);
            return (
              <div key={r.name} className={`flex items-center gap-2 rounded-lg border px-2.5 py-1.5 ${r.done ? "border-pine/30 bg-pine-soft/40" : "border-line bg-paper"}`}>
                <span className={`grid h-5 w-5 shrink-0 place-items-center rounded-full ${r.done ? "bg-pine text-white" : "bg-paper-2 text-ink-3"}`}>
                  {r.done ? <Icon name="check" size={11} strokeWidth={3} /> : <span className="h-1.5 w-1.5 rounded-full bg-current" />}
                </span>
                <span className="min-w-0 flex-1 truncate text-[12.5px] font-bold text-ink">{r.name}</span>
                {teacherMode ? (
                  <select
                    className="max-w-[120px] cursor-pointer rounded-md border border-line bg-card px-1.5 py-0.5 text-[11.5px] font-semibold text-ink-2"
                    value={r.assignedTo ?? ""}
                    onChange={(e) => assignQuestRole(q.id, r.name, e.target.value || null)}
                  >
                    <option value="">— не назначен —</option>
                    {students.map((s) => <option key={s.id} value={s.id}>{s.displayName}</option>)}
                  </select>
                ) : (
                  <span className="truncate text-[11.5px] font-semibold text-ink-3">{assignee ? assignee.displayName : "свободна"}</span>
                )}
              </div>
            );
          })}
        </div>
        <div className="mt-3 flex items-center gap-3">
          <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-paper-2">
            <div className="anim-bar h-full rounded-full bg-pine" style={{ width: `${pct}%` }} />
          </div>
          <span className="font-display text-[12px] font-black text-pine">{pct}%</span>
        </div>
        <div className="mt-3 flex items-center justify-between">
          <Chip tone="amber">+{q.bonus} б. команде</Chip>
          {!teacherMode && (
            <Button size="sm" variant={myRole ? "primary" : "ghost"} onClick={() => navigate(`student/quests/${q.id}`)}>
              {myRole ? <>Моя роль: {myRole.name} <Icon name="arrowRight" size={12} /></> : <>Открыть <Icon name="arrowRight" size={12} /></>}
            </Button>
          )}
        </div>
      </div>
    </Reveal>
  );
}

function QuestTab({ gid, teacherMode, meId, navigate }: { gid: string; teacherMode: boolean; meId: string; navigate: Nav }) {
  const { db, createQuest, assignQuestRole, toast } = useApp();
  const [creating, setCreating] = useState(false);
  const [title, setTitle] = useState("");
  const [desc, setDesc] = useState("");
  const [days, setDays] = useState(7);

  const quests = db.quests.filter((q) => q.classGroupId === gid);
  const students = db.users.filter((u0) => u0.role === "STUDENT" && u0.classGroupId === gid);
  const u = (id: string | null) => db.users.find((x) => x.id === id);

  return (
    <div>
      {teacherMode && (
        <div className="mb-4 flex justify-end">
          <Button size="sm" onClick={() => setCreating(true)}><Icon name="flag" size={13} /> Новый квест</Button>
        </div>
      )}
      {quests.length === 0 ? (
        <Empty icon="flag" title="Квестов пока нет" text={teacherMode ? "Создайте первый групповой квест с ролями." : "Учитель скоро запустит командный квест."} />
      ) : (
        <div className="grid gap-4 sm:grid-cols-2">
          {quests.map((q, i) => (
            <QuestCard key={q.id} q={q} teacherMode={teacherMode} students={students} u={u} meId={meId} navigate={navigate} assignQuestRole={assignQuestRole} delay={i * 60} />
          ))}
        </div>
      )}
      <Modal open={creating} onClose={() => setCreating(false)} title="Новый групповой квест">
        <label className="mb-1 block text-[12px] font-semibold text-ink-2">Название</label>
        <input className={INPUT_CLS} placeholder="Например: Интервью со звездой" value={title} onChange={(e) => setTitle(e.target.value)} />
        <label className="mb-1 mt-3 block text-[12px] font-semibold text-ink-2">Описание</label>
        <textarea className={INPUT_CLS} rows={3} placeholder="Что нужно сделать команде…" value={desc} onChange={(e) => setDesc(e.target.value)} />
        <label className="mb-1 mt-3 block text-[12px] font-semibold text-ink-2">Дедлайн (дней)</label>
        <input type="number" min={1} max={60} className={INPUT_CLS} value={days} onChange={(e) => setDays(parseInt(e.target.value || "7", 10))} />
        <p className="mt-2 text-[11.5px] text-ink-3">Роли (Ведущий, Исследователь, Спикер, Оформитель) назначаются прямо в карточке квеста.</p>
        <Button className="mt-4 w-full" onClick={() => {
          if (!title.trim()) return toast("Укажите название квеста", "warn");
          createQuest(gid, title, desc, days);
          setCreating(false); setTitle(""); setDesc("");
          toast("Квест создан — назначьте роли");
        }}><Icon name="flag" size={14} /> Создать квест</Button>
      </Modal>
    </div>
  );
}

/* ================= страница квеста /student/quests/[id] ================= */
export function QuestPage({ questId, navigate }: { questId: string; navigate: Nav }) {
  const { db, me, completeRole, toast } = useApp();
  if (!me) return null;
  const q = db.quests.find((x) => x.id === questId);
  if (!q) return <Empty icon="flag" title="Квест не найден" text="Возможно, он был удалён учителем." />;
  const u = (id: string | null) => db.users.find((x) => x.id === id);
  const myRole = q.roles.find((r) => r.assignedTo === me.id);
  const pct = questProgress(q);
  const left = daysLeft(q.deadline);
  const team = [...new Set(q.roles.map((r) => r.assignedTo).filter(Boolean) as string[])].map((id) => u(id)).filter(Boolean) as User[];
  const doc = db.docs.find((dc) => dc.groupQuestId === q.id);

  return (
    <div className="flex flex-col gap-5">
      <button onClick={() => navigate("social")} className="flex w-fit cursor-pointer items-center gap-1.5 text-[12.5px] font-bold text-ink-3 transition hover:text-pine">
        <Icon name="arrowRight" size={13} className="rotate-180" /> К сообществу
      </button>
      <Reveal>
        <div className="grid gap-6 rounded-xl border border-line bg-night p-6 text-paper lg:grid-cols-[auto_1fr]">
          <Ring value={pct / 100} size={116} stroke={11} color="var(--color-amber)" track="#243b45">
            <span className="font-display text-[22px] font-black text-amber">{pct}%</span>
          </Ring>
          <div>
            <div className="flex flex-wrap items-center gap-2">
              <h2 className="font-display text-[22px] font-black">{q.title}</h2>
              <Chip tone={q.status === "done" ? "green" : left < 2 ? "coral" : "night"}><Icon name="clock" size={11} /> {q.status === "done" ? "завершён" : left < 0 ? "дедлайн прошёл" : `ещё ${left} дн.`}</Chip>
              <Chip tone="amber">+{q.bonus} б. каждому участнику</Chip>
            </div>
            <p className="mt-2 max-w-xl text-[13.5px] leading-relaxed text-paper/70">{q.description}</p>
            <div className="mt-4 flex flex-wrap gap-2">
              {team.map((t) => (
                <span key={t.id} className="flex items-center gap-1.5 rounded-full border border-night-3 bg-night-2 px-2.5 py-1 text-[12px] font-bold text-paper/85">
                  <Avatar user={t} size={20} /> {t.displayName}
                </span>
              ))}
              {team.length === 0 && <span className="text-[12px] text-paper/50">Роли ещё не распределены.</span>}
            </div>
          </div>
        </div>
      </Reveal>

      <div className="grid gap-4 lg:grid-cols-2">
        <Reveal delay={60}>
          <div className="rounded-xl border border-line bg-card p-5">
            <SectionTitle kicker="роли команды" title="Кто что делает" />
            <div className="flex flex-col gap-2">
              {q.roles.map((r) => {
                const assignee = u(r.assignedTo);
                const mine = r.assignedTo === me.id;
                return (
                  <div key={r.name} className={`flex items-center gap-3 rounded-xl border-2 px-3.5 py-2.5 ${mine ? "border-pine bg-pine-soft/40" : "border-line bg-paper"}`}>
                    {assignee ? <Avatar user={assignee} size={32} /> : <span className="grid h-8 w-8 place-items-center rounded-full bg-paper-2 text-ink-3"><Icon name="users" size={14} /></span>}
                    <div className="min-w-0 flex-1 leading-tight">
                      <p className="text-[13.5px] font-bold text-ink">{r.name} {mine && <Chip tone="green" className="ml-1">ваша</Chip>}</p>
                      <p className="text-[11.5px] text-ink-3">{assignee ? assignee.displayName : "роль свободна"}</p>
                    </div>
                    {mine && !r.done && q.status !== "done" && (
                      <Button size="sm" onClick={() => { completeRole(q.id, r.name); toast("Роль выполнена: +10 баллов"); }}><Icon name="check" size={13} /> Готово</Button>
                    )}
                    {(r.done || (!mine && r.done)) && r.done && <Chip tone="green"><Icon name="check" size={11} /> сделано</Chip>}
                  </div>
                );
              })}
            </div>
            {!myRole && q.status !== "done" && (
              <p className="mt-3 rounded-lg bg-amber-soft px-3 py-2 text-[12.5px] font-semibold text-[#7a4d0d]">Учитель пока не назначил вам роль — напомните в чате группы.</p>
            )}
          </div>
        </Reveal>
        <Reveal delay={110}>
          <div className="flex flex-col gap-4">
            <div className="rounded-xl border border-line bg-card p-5">
              <p className="flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-[0.14em] text-ink-3"><Icon name="doc" size={13} /> Общий документ квеста</p>
              {doc ? (
                <>
                  <p className="mt-2 text-[14px] font-bold text-ink">{doc.title}</p>
                  <p className="mt-1 line-clamp-4 whitespace-pre-line text-[12.5px] leading-relaxed text-ink-2">{doc.content || "Пока пусто — начните вместе!"}</p>
                  <Button size="sm" variant="soft" className="mt-3" onClick={() => navigate("social")}><Icon name="pen" size={13} /> Редактировать во вкладке «Документы»</Button>
                </>
              ) : (
                <p className="mt-2 text-[12.5px] text-ink-3">Документа пока нет — создайте его во вкладке «Документы» и привяжите к квесту.</p>
              )}
            </div>
            <div className="rounded-xl border border-line bg-night p-5 text-paper">
              <p className="text-[11px] font-bold uppercase tracking-[0.14em] text-paper/45">Как работает командный бонус</p>
              <p className="mt-2 text-[12.5px] leading-relaxed text-paper/70">
                Когда все роли отмечены «готово», каждый участник получает <b className="text-amber">+{q.bonus} баллов</b> в PointsLedger.
                Вклад каждого виден: без вашей роли команда бонус не получит.
              </p>
            </div>
          </div>
        </Reveal>
      </div>
    </div>
  );
}

/* ================= совместные документы ================= */
function DocTab({ gid, meId, teacherMode }: { gid: string; meId: string; teacherMode: boolean }) {
  const { db, createDoc, saveDocRevision, toast } = useApp();
  const docs = db.docs.filter((dc) => dc.classGroupId === gid);
  const [selId, setSelId] = useState<string | null>(docs[0]?.id ?? null);
  const doc = docs.find((dc) => dc.id === selId) ?? docs[0] ?? null;
  const [text, setText] = useState(doc?.content ?? "");
  const [showHistory, setShowHistory] = useState(false);
  const [newTitle, setNewTitle] = useState("");

  useEffect(() => {
    setText(doc?.content ?? "");
  }, [doc?.id, doc?.content]);

  const revisions = db.docRevisions.filter((r) => r.docId === doc?.id).sort((a, b) => b.createdAt - a.createdAt);
  const u = (id: string) => db.users.find((x) => x.id === id);
  const dirty = doc !== null && text !== doc.content;

  return (
    <div className="grid gap-4 lg:grid-cols-[240px_1fr]">
      <div className="flex flex-col gap-2">
        {!teacherMode && (
          <div className="rounded-xl border border-line bg-card p-3">
            <input className={INPUT_CLS} placeholder="Название документа" value={newTitle} onChange={(e) => setNewTitle(e.target.value)} />
            <Button size="sm" className="mt-2 w-full" onClick={() => {
              if (!newTitle.trim()) return toast("Укажите название", "warn");
              const id = createDoc(newTitle);
              setNewTitle("");
              setSelId(id);
              toast("Документ создан");
            }}><Icon name="plus" size={13} /> Новый документ</Button>
          </div>
        )}
        {docs.length === 0 && <Empty icon="doc" title="Документов нет" text="Создайте общий текст для тандема или квеста." />}
        {docs.map((dc) => (
          <button key={dc.id} onClick={() => { setSelId(dc.id); setShowHistory(false); }} className={`cursor-pointer rounded-xl border-2 px-3.5 py-2.5 text-left transition ${doc?.id === dc.id ? "border-pine bg-pine-soft/50" : "border-line bg-card hover:border-ink-3/40"}`}>
            <p className="truncate text-[13px] font-bold text-ink">{dc.title}</p>
            <p className="text-[11px] text-ink-3">{timeAgo(dc.updatedAt)} · {db.docRevisions.filter((r) => r.docId === dc.id).length} ревизий</p>
          </button>
        ))}
      </div>

      {doc && (
        <div className="rounded-xl border border-line bg-card p-5">
          <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
            <div>
              <p className="font-display text-[16px] font-bold text-ink">{doc.title}</p>
              <p className="text-[11.5px] text-ink-3">
                {doc.groupQuestId ? "привязан к квесту" : doc.tandemId ? "документ тандема" : "общий документ группы"} · обновлён {timeAgo(doc.updatedAt)}
              </p>
            </div>
            <div className="flex gap-2">
              <Button size="sm" variant="ghost" onClick={() => setShowHistory((v) => !v)}>
                <Icon name="doc" size={13} /> История правок ({revisions.length})
              </Button>
              {!teacherMode && (
                <Button size="sm" disabled={!dirty} onClick={() => { saveDocRevision(doc.id, text); toast("Сохранено: новая ревизия записана"); }}>
                  <Icon name="check" size={13} /> Сохранить
                </Button>
              )}
            </div>
          </div>
          {showHistory ? (
            <div className="flex flex-col gap-2.5">
              {revisions.length === 0 && <p className="text-[12.5px] text-ink-3">Ревизий пока нет.</p>}
              {revisions.map((r, i) => {
                const author = u(r.authorId);
                return (
                  <div key={r.id} className="rounded-xl border border-line bg-paper p-3.5">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <p className="flex items-center gap-2 text-[12.5px] font-bold text-ink">
                        {author && <Avatar user={author} size={22} />} {author ? author.displayName : "—"}
                        <Chip tone="ink">v{revisions.length - i}</Chip>
                      </p>
                      <div className="flex items-center gap-2">
                        <span className="text-[11px] text-ink-3">{timeAgo(r.createdAt)}</span>
                        {!teacherMode && (
                          <Button size="sm" variant="soft" onClick={() => { setText(r.contentSnapshot); setShowHistory(false); }}>
                            <Icon name="refresh" size={12} /> Вернуть
                          </Button>
                        )}
                      </div>
                    </div>
                    <p className="mt-2 line-clamp-3 whitespace-pre-line text-[12.5px] leading-relaxed text-ink-2">{r.contentSnapshot}</p>
                  </div>
                );
              })}
            </div>
          ) : (
            <>
              <textarea
                className={`${INPUT_CLS} min-h-[220px] font-[inherit] leading-relaxed`}
                value={text}
                readOnly={teacherMode}
                onChange={(e) => setText(e.target.value)}
                placeholder="Пишите вместе: каждое сохранение — новая ревизия в истории."
              />
              <p className="mt-2 text-[11.5px] text-ink-3">
                MVP без real-time курсора: ревизия создаётся при каждом нажатии «Сохранить», откат — кнопкой «Вернуть».
                {dirty && <b className="ml-1 text-amber">Есть несохранённые изменения.</b>}
              </p>
            </>
          )}
        </div>
      )}
    </div>
  );
}

/* ================= peer-review ================= */
function ReviewTab({ gid, meId, teacherMode }: { gid: string; meId: string; teacherMode: boolean }) {
  const { db, submitForReview, giveReview, toast } = useApp();
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [forId, setForId] = useState<string | null>(null);
  const [scores, setScores] = useState<Record<string, number>>({});
  const [comment, setComment] = useState("");

  const inGroup = (s: TaskSubmission) => db.users.find((x) => x.id === s.studentId)?.classGroupId === gid;
  const subs = db.submissions.filter(inGroup);
  const u = (id: string) => db.users.find((x) => x.id === id);
  const forSub = subs.find((s) => s.id === forId) ?? null;
  const myReviewed = db.peerReviews.filter((r) => r.reviewerId === meId).map((r) => r.taskSubmissionId);

  return (
    <div className="grid gap-5 lg:grid-cols-2">
      {/* работы группы */}
      <div className="flex flex-col gap-3">
        <SectionTitle kicker="работы группы" title="Что разбираем" right={<Chip tone="ink">{subs.length}</Chip>} />
        {subs.length === 0 && <Empty icon="pen" title="Работ пока нет" text="Отправьте свой текст — он появится здесь для разборов." />}
        {subs.map((s) => {
          const author = u(s.studentId);
          const reviews = db.peerReviews.filter((r) => r.taskSubmissionId === s.id);
          const avg = reviewAverage(db.peerReviews, s.id);
          const canReview = !teacherMode && s.studentId !== meId && !myReviewed.includes(s.id);
          return (
            <Reveal key={s.id}>
              <div className="card-hover rounded-xl border border-line bg-card p-4">
                <div className="flex items-center gap-2.5">
                  {author && <Avatar user={author} size={32} />}
                  <div className="min-w-0 flex-1 leading-tight">
                    <p className="truncate text-[14px] font-bold text-ink">{s.title}</p>
                    <p className="text-[11.5px] text-ink-3">{author ? visibleName(teacherMode ? "TEACHER" : "STUDENT", author) : "—"} · {timeAgo(s.at)}{s.taskId ? " · из задания курса" : ""}</p>
                  </div>
                  {avg !== null && <Chip tone="green"><Icon name="star" size={11} /> {avg}/5</Chip>}
                </div>
                <p className="mt-2.5 rounded-lg bg-paper px-3.5 py-2.5 text-[13px] leading-relaxed text-ink-2">{s.content}</p>
                {reviews.length > 0 && (
                  <div className="mt-2.5 flex flex-col gap-2">
                    {reviews.map((r) => {
                      const rev = u(r.reviewerId);
                      const ravg = Math.round((r.rubricScores.reduce((sm, x) => sm + x.value, 0) / r.rubricScores.length) * 10) / 10;
                      return (
                        <div key={r.id} className="rounded-lg border border-pine/25 bg-pine-soft/35 px-3.5 py-2.5">
                          <p className="flex items-center justify-between text-[12px] font-bold text-pine-deep">
                            <span>{rev ? rev.displayName : "—"} · разбор</span><span>{ravg}/5</span>
                          </p>
                          <div className="mt-1 flex flex-wrap gap-1">
                            {r.rubricScores.map((rs) => (
                              <span key={rs.criteria} className="rounded-md bg-card px-1.5 py-0.5 text-[10.5px] font-semibold text-ink-2">{rs.criteria}: {rs.value}</span>
                            ))}
                          </div>
                          {r.comment && <p className="mt-1.5 text-[12.5px] leading-relaxed text-ink-2">{r.comment}</p>}
                        </div>
                      );
                    })}
                  </div>
                )}
                {canReview && (
                  <Button size="sm" variant="soft" className="mt-3" onClick={() => { setForId(s.id); setScores({}); setComment(""); window.scrollTo({ top: 0, behavior: "smooth" }); }}>
                    <Icon name="star" size={13} /> Разобрать по рубрике
                  </Button>
                )}
                {!teacherMode && s.studentId === meId && reviews.length === 0 && (
                  <p className="mt-2 text-[11.5px] font-semibold text-ink-3">Это ваша работа — ждёт разбора одноклассниками.</p>
                )}
              </div>
            </Reveal>
          );
        })}
      </div>

      {/* форма */}
      <div className="flex flex-col gap-4">
        {forSub && !teacherMode ? (
          <Reveal>
            <div className="rounded-xl border-2 border-pine/40 bg-card p-5">
              <SectionTitle kicker="рубрика · 1–5 по каждому критерию" title={`Разбор: ${forSub.title}`} right={<Button size="sm" variant="ghost" onClick={() => setForId(null)}>Отмена</Button>} />
              <div className="flex flex-col gap-2.5">
                {RUBRIC_CRITERIA.map((c) => (
                  <div key={c} className="flex items-center justify-between gap-3 rounded-lg border border-line bg-paper px-3.5 py-2.5">
                    <p className="text-[13px] font-semibold text-ink">{c}</p>
                    <div className="flex gap-1">
                      {[1, 2, 3, 4, 5].map((v) => (
                        <button key={v} onClick={() => setScores((sc) => ({ ...sc, [c]: v }))} className={`h-8 w-8 cursor-pointer rounded-lg text-[12.5px] font-black transition-all ${(scores[c] ?? 0) >= v ? "bg-pine text-white" : "bg-paper-2 text-ink-3 hover:bg-line"}`}>
                          {v}
                        </button>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
              <textarea className={`${INPUT_CLS} mt-3`} rows={3} placeholder="Добрый и конкретный комментарий: что получилось, что усилить…" value={comment} onChange={(e) => setComment(e.target.value)} />
              <Button className="mt-3 w-full" disabled={Object.keys(scores).length < RUBRIC_CRITERIA.length} onClick={() => {
                const rubricScores: RubricScore[] = RUBRIC_CRITERIA.map((c) => ({ criteria: c, value: scores[c] ?? 1 }));
                const res = giveReview(forSub.id, rubricScores, comment);
                if (!res.ok) return toast(`Стоп-фильтр не пропустил комментарий (${res.hits.join(", ")})`, "err");
                toast("Разбор отправлен: +5 баллов");
                setForId(null);
              }}><Icon name="send" size={14} /> Отправить разбор</Button>
            </div>
          </Reveal>
        ) : (
          !teacherMode && (
            <Reveal>
              <div className="rounded-xl border border-line bg-card p-5">
                <SectionTitle kicker="ваш текст" title="Отправить на peer-review" />
                <input className={INPUT_CLS} placeholder="Название (например: My weekend)" value={title} onChange={(e) => setTitle(e.target.value)} />
                <textarea className={`${INPUT_CLS} mt-2.5`} rows={5} placeholder="Текст на английском…" value={content} onChange={(e) => setContent(e.target.value)} />
                <Button className="mt-3 w-full" onClick={() => {
                  if (!title.trim() || !content.trim()) return toast("Нужны название и текст", "warn");
                  const res = submitForReview(title, content, null);
                  if (!res.ok) return toast(`Стоп-фильтр: ${res.hits.join(", ")}`, "err");
                  setTitle(""); setContent("");
                  toast("Работа выставлена на разбор: +5 баллов");
                }}><Icon name="send" size={14} /> Выставить на разбор</Button>
                <p className="mt-2 text-[11.5px] text-ink-3">Тексты из WRITING-заданий попадают сюда автоматически.</p>
              </div>
            </Reveal>
          )
        )}
        <Reveal delay={70}>
          <div className="rounded-xl border border-line bg-night p-5 text-paper">
            <p className="text-[11px] font-bold uppercase tracking-[0.14em] text-paper/45">Правила разбора</p>
            <ul className="mt-2 space-y-1.5 text-[12.5px] leading-relaxed text-paper/70">
              <li>• Сначала что получилось, потом — что усилить.</li>
              <li>• Оцениваем текст, не автора.</li>
              <li>• Комментарии проходят стоп-фильтр модерации.</li>
            </ul>
          </div>
        </Reveal>
      </div>
    </div>
  );
}

/* ================= чат (поллинг раз в 5 с) ================= */
function ChatTab({ gid, meId, teacherMode }: { gid: string; meId: string; teacherMode: boolean }) {
  const { db, me, sendMessage, peerReply, toast } = useApp();
  const [text, setText] = useState("");
  const [lastPoll, setLastPoll] = useState<number>(Date.now());
  const boxRef = useRef<HTMLDivElement>(null);

  const group = db.groups.find((g) => g.id === gid);
  const msgs = useMemo(() => fetchGroupMessages(gid, me?.role ?? "STUDENT"), [db, gid, me?.role, lastPoll]);

  /* поллинг GET /api/groups/:id/messages раз в 5 секунд */
  useEffect(() => {
    const t = window.setInterval(() => setLastPoll(Date.now()), 5000);
    return () => window.clearInterval(t);
  }, []);

  useEffect(() => {
    boxRef.current?.scrollTo({ top: boxRef.current.scrollHeight, behavior: "smooth" });
  }, [msgs.length]);

  if (!me) return null;

  const send = () => {
    if (!text.trim()) return;
    const res = sendMessage(gid, text);
    if (res.error) return toast(res.error, "err");
    if (res.hidden) toast("Сообщение скрыто стоп-фильтром и ждёт решения учителя", "warn");
    else {
      setText("");
      // имитация ответа сверстника (в боевом стеке — реальные участники)
      window.setTimeout(() => peerReply(gid, meId), 2500 + Math.random() * 2500);
    }
  };

  return (
    <div className="overflow-hidden rounded-xl border border-line bg-card">
      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-line bg-paper px-4 py-3">
        <p className="flex items-center gap-2 font-display text-[14px] font-bold text-ink">
          <Icon name="chat" size={16} className="text-pine" /> Чат {group?.name}
        </p>
        <div className="flex items-center gap-2 text-[11px] font-semibold text-ink-3">
          <span className="blink-dot h-1.5 w-1.5 rounded-full bg-pine" />
          поллинг каждые 5 с · обновлено {clockTime(lastPoll)}
        </div>
      </div>

      <div ref={boxRef} className="flex max-h-[430px] min-h-[300px] flex-col gap-2.5 overflow-y-auto p-4">
        {msgs.length === 0 && <p className="m-auto text-[13px] text-ink-3">Сообщений пока нет — начните обсуждение!</p>}
        {msgs.map((m) => {
          const author = db.users.find((x) => x.id === m.authorId);
          const mine = m.authorId === meId;
          return (
            <div key={m.id} className={`flex items-end gap-2 ${mine ? "flex-row-reverse" : ""}`}>
              {author && <Avatar user={author} size={28} />}
              <div className={`max-w-[78%] rounded-2xl px-3.5 py-2 ${mine ? "rounded-br-md bg-night text-paper" : "rounded-bl-md border border-line bg-paper"}`}>
                <p className={`text-[10.5px] font-bold ${mine ? "text-paper/50" : "text-pine"}`}>
                  {author ? visibleName(me.role, author) : "—"} · {clockTime(m.createdAt)}
                </p>
                {m.hidden ? (
                  <p className={`mt-0.5 flex items-center gap-1.5 text-[13px] font-semibold ${mine ? "text-amber" : "text-[#8a5a10]"}`}>
                    <Icon name="shield" size={13} /> скрыто модерацией{m.hiddenReason ? ` · ${m.hiddenReason}` : ""}
                  </p>
                ) : (
                  <p className={`mt-0.5 whitespace-pre-line text-[13.5px] leading-relaxed ${mine ? "text-paper" : "text-ink"}`}>{m.content}</p>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {teacherMode ? (
        <div className="flex items-center gap-2 border-t border-line bg-paper px-4 py-3 text-[12.5px] font-semibold text-ink-2">
          <Icon name="eye" size={15} className="text-sky" /> Режим наблюдателя: вам видны и скрытые сообщения (для модуля модерации).
        </div>
      ) : (
        <div className="flex items-center gap-2 border-t border-line bg-paper px-3 py-2.5">
          <input
            className={INPUT_CLS}
            placeholder={`Написать в ${group?.name ?? "группу"}…`}
            value={text}
            onChange={(e) => setText(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && send()}
          />
          <Button onClick={send} disabled={!text.trim()}><Icon name="send" size={15} /></Button>
        </div>
      )}
      <p className="border-t border-line bg-paper-2/60 px-4 py-2 text-[11px] text-ink-3">
        Чат существует только внутри учебной группы: API отклоняет отправку в чужую группу, личных сообщений нет.
      </p>
    </div>
  );
}

/* ================= корневая страница ================= */
export function SocialView({ navigate }: { navigate: Nav }) {
  const { db, me } = useApp();
  const [tab, setTab] = useState("tandems");
  const [groupId, setGroupId] = useState(me?.classGroupId ?? "g1");
  if (!me) return null;
  const teacherMode = me.role !== "STUDENT";
  const gid = teacherMode ? groupId : me.classGroupId ?? "g1";

  const tabs: { id: string; label: string; icon: IconName }[] = [
    { id: "tandems", label: "Тандемы", icon: "users" },
    { id: "quests", label: "Квесты", icon: "flag" },
    { id: "docs", label: "Документы", icon: "doc" },
    { id: "reviews", label: "Разборы", icon: "star" },
    { id: "chat", label: "Чат", icon: "chat" },
  ];

  return (
    <div className="flex flex-col gap-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex flex-wrap gap-1.5 rounded-xl border border-line bg-card p-1.5">
          {tabs.map((t) => (
            <button key={t.id} onClick={() => setTab(t.id)} className={`flex cursor-pointer items-center gap-1.5 rounded-lg px-3.5 py-2 text-[13px] font-bold transition-all ${tab === t.id ? "bg-night text-paper shadow" : "text-ink-2 hover:bg-paper-2"}`}>
              <Icon name={t.icon} size={14} /> {t.label}
            </button>
          ))}
        </div>
        {teacherMode && (
          <select className={`${INPUT_CLS} !w-auto`} value={groupId} onChange={(e) => setGroupId(e.target.value)}>
            {db.groups.map((g) => <option key={g.id} value={g.id}>{g.name}</option>)}
          </select>
        )}
      </div>

      {tab === "tandems" && <TandemTab gid={gid} teacherMode={teacherMode} meId={me.id} />}
      {tab === "quests" && <QuestTab gid={gid} teacherMode={teacherMode} meId={me.id} navigate={navigate} />}
      {tab === "docs" && <DocTab gid={gid} meId={me.id} teacherMode={teacherMode} />}
      {tab === "reviews" && <ReviewTab gid={gid} meId={me.id} teacherMode={teacherMode} />}
      {tab === "chat" && <ChatTab gid={gid} meId={me.id} teacherMode={teacherMode} />}
    </div>
  );
}
