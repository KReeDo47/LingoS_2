/* ============================================================
   Модуль mechanics · unit-тесты
   Запуск: npx vitest run src/modules/mechanics/mechanics.test.ts
   ============================================================ */
import { describe, expect, it } from "vitest";
import { getLevel, checkMentorEligibility, checkAndAwardBadges } from "./mechanics";
import type { DB, User } from "../../lib/types";

const mkUser = (id: string, role: User["role"] = "STUDENT"): User => ({
  id,
  role,
  email: `${id}@test.io`,
  passwordHash: "x",
  fullName: `Полное Имя ${id}`,
  displayName: id.toUpperCase(),
  showAvatar: true,
  mustChangePassword: false,
  hue: 100,
  classGroupId: "g1",
  cefr: "A2",
  lastActiveAt: Date.now(),
  createdAt: Date.now(),
});

const mkDB = (overrides: Partial<DB> = {}): DB => ({
  version: 5,
  sessionId: null,
  users: [],
  groups: [],
  consents: [],
  courses: [],
  progress: [],
  ledger: [],
  badges: [
    { id: "b1", code: "FIRST_10_TASKS", title: "Первые шаги", description: "Выполнить 10 заданий", iconUrl: "🌱" },
    { id: "b2", code: "STREAK_7_DAYS", title: "Неделя без пропусков", description: "7 дней подряд с активностью", iconUrl: "🔥" },
    { id: "b3", code: "PEER_REVIEW_5", title: "Критик", description: "Дать 5 peer-review", iconUrl: "✏️" },
  ],
  studentBadges: [],
  challenges: [],
  challengeResults: [],
  mentorRoles: [],
  tandems: [],
  quests: [],
  docs: [],
  docRevisions: [],
  submissions: [],
  peerReviews: [],
  messages: [],
  queue: [],
  safetyLog: [],
  reflections: [],
  diaryEntries: [],
  selfAssessmentChecklists: [],
  selfAssessmentResponses: [],
  feedbackNotes: [],
  checklists: [],
  canDoList: [],
  contentFlags: [],
  bannedWords: [],
  ...overrides,
});

describe("getLevel — чистая функция расчёта уровня", () => {
  it("0 баллов → уровень 0 (Новичок)", () => {
    const result = getLevel(0);
    expect(result.level).toBe(0);
    expect(result.name).toBe("Новичок");
    expect(result.icon).toBe("🌱");
    expect(result.nextThreshold).toBe(100);
    expect(result.progress).toBe(0);
  });

  it("50 баллов → уровень 0, прогресс 50%", () => {
    const result = getLevel(50);
    expect(result.level).toBe(0);
    expect(result.progress).toBe(0.5);
  });

  it("100 баллов → уровень 1 (Ученик)", () => {
    const result = getLevel(100);
    expect(result.level).toBe(1);
    expect(result.name).toBe("Ученик");
    expect(result.icon).toBe("📚");
    expect(result.nextThreshold).toBe(300);
  });

  it("300 баллов → уровень 2 (Практик)", () => {
    const result = getLevel(300);
    expect(result.level).toBe(2);
    expect(result.name).toBe("Практик");
  });

  it("700 баллов → уровень 3 (Знаток)", () => {
    const result = getLevel(700);
    expect(result.level).toBe(3);
    expect(result.name).toBe("Знаток");
  });

  it("1500 баллов → уровень 4 (Мастер)", () => {
    const result = getLevel(1500);
    expect(result.level).toBe(4);
    expect(result.name).toBe("Мастер");
  });

  it("3000 баллов → уровень 5 (Эксперт)", () => {
    const result = getLevel(3000);
    expect(result.level).toBe(5);
    expect(result.name).toBe("Эксперт");
  });

  it("5000 баллов → уровень 6 (Легенда)", () => {
    const result = getLevel(5000);
    expect(result.level).toBe(6);
    expect(result.name).toBe("Легенда");
    expect(result.nextThreshold).toBe(null);
    expect(result.progress).toBe(1);
  });

  it("10000 баллов → уровень 6 (максимальный)", () => {
    const result = getLevel(10000);
    expect(result.level).toBe(6);
    expect(result.progress).toBe(1);
  });

  it("детерминированность: одинаковый вход → одинаковый результат", () => {
    const r1 = getLevel(450);
    const r2 = getLevel(450);
    expect(r1).toEqual(r2);
  });
});

describe("checkMentorEligibility — проверка на наставника", () => {
  it("недостаточно баллов → false", () => {
    const db = mkDB({
      users: [mkUser("s1")],
      ledger: [
        { id: "l1", userId: "s1", points: 100, reason: "TASK_COMPLETED", sourceId: "t1", at: Date.now() },
      ],
    });
    expect(checkMentorEligibility(db, "s1")).toBe(false);
  });

  it("недостаточно заданий → false", () => {
    const db = mkDB({
      users: [mkUser("s1")],
      ledger: [
        { id: "l1", userId: "s1", points: 50, reason: "TASK_COMPLETED", sourceId: "t1", at: Date.now() },
        { id: "l2", userId: "s1", points: 50, reason: "TASK_COMPLETED", sourceId: "t2", at: Date.now() },
      ],
      peerReviews: Array.from({ length: 10 }, (_, i) => ({
        id: `pr${i}`,
        taskSubmissionId: `sub${i}`,
        reviewerId: "s1",
        rubricScores: [],
        comment: "",
        createdAt: Date.now(),
      })),
    });
    // Добавим баллов через другие источники
    for (let i = 3; i <= 10; i++) {
      db.ledger.push({ id: `l${i}`, userId: "s1", points: 50, reason: "QUEST_COMPLETED", sourceId: `q${i}`, at: Date.now() });
    }
    expect(checkMentorEligibility(db, "s1")).toBe(false);
  });

  it("недостаточно peer-review → false", () => {
    const db = mkDB({
      users: [mkUser("s1")],
      ledger: Array.from({ length: 20 }, (_, i) => ({
        id: `l${i}`,
        userId: "s1",
        points: 30,
        reason: "TASK_COMPLETED",
        sourceId: `t${i}`,
        at: Date.now(),
      })),
      peerReviews: Array.from({ length: 5 }, (_, i) => ({
        id: `pr${i}`,
        taskSubmissionId: `sub${i}`,
        reviewerId: "s1",
        rubricScores: [],
        comment: "",
        createdAt: Date.now(),
      })),
    });
    expect(checkMentorEligibility(db, "s1")).toBe(false);
  });

  it("все критерии выполнены → true", () => {
    const db = mkDB({
      users: [mkUser("s1")],
      ledger: Array.from({ length: 20 }, (_, i) => ({
        id: `l${i}`,
        userId: "s1",
        points: 30,
        reason: "TASK_COMPLETED",
        sourceId: `t${i}`,
        at: Date.now(),
      })),
      peerReviews: Array.from({ length: 10 }, (_, i) => ({
        id: `pr${i}`,
        taskSubmissionId: `sub${i}`,
        reviewerId: "s1",
        rubricScores: [],
        comment: "",
        createdAt: Date.now(),
      })),
    });
    // Сумма баллов: 20 * 30 = 600 >= 500 ✓
    expect(checkMentorEligibility(db, "s1")).toBe(true);
  });

  it("ровно на пороге → true", () => {
    const db = mkDB({
      users: [mkUser("s1")],
      ledger: Array.from({ length: 20 }, (_, i) => ({
        id: `l${i}`,
        userId: "s1",
        points: 25,
        reason: "TASK_COMPLETED",
        sourceId: `t${i}`,
        at: Date.now(),
      })),
      peerReviews: Array.from({ length: 10 }, (_, i) => ({
        id: `pr${i}`,
        taskSubmissionId: `sub${i}`,
        reviewerId: "s1",
        rubricScores: [],
        comment: "",
        createdAt: Date.now(),
      })),
    });
    // Сумма баллов: 20 * 25 = 500 >= 500 ✓
    expect(checkMentorEligibility(db, "s1")).toBe(true);
  });
});

describe("checkAndAwardBadges — автоматическое начисление бейджей", () => {
  it("10 заданий → бейдж FIRST_10_TASKS", () => {
    const db = mkDB({
      users: [mkUser("s1")],
      ledger: Array.from({ length: 10 }, (_, i) => ({
        id: `l${i}`,
        userId: "s1",
        points: 10,
        reason: "TASK_COMPLETED",
        sourceId: `t${i}`,
        at: Date.now(),
      })),
    });
    const earned = checkAndAwardBadges(db, "s1");
    expect(earned).toContain("FIRST_10_TASKS");
    expect(db.studentBadges).toHaveLength(1);
    expect(db.studentBadges[0].badgeId).toBe("b1");
  });

  it("5 peer-review → бейдж PEER_REVIEW_5", () => {
    const db = mkDB({
      users: [mkUser("s1")],
      peerReviews: Array.from({ length: 5 }, (_, i) => ({
        id: `pr${i}`,
        taskSubmissionId: `sub${i}`,
        reviewerId: "s1",
        rubricScores: [],
        comment: "",
        createdAt: Date.now(),
      })),
    });
    const earned = checkAndAwardBadges(db, "s1");
    expect(earned).toContain("PEER_REVIEW_5");
  });

  it("повторный вызов не начисляет дубликаты", () => {
    const db = mkDB({
      users: [mkUser("s1")],
      ledger: Array.from({ length: 10 }, (_, i) => ({
        id: `l${i}`,
        userId: "s1",
        points: 10,
        reason: "TASK_COMPLETED",
        sourceId: `t${i}`,
        at: Date.now(),
      })),
    });
    checkAndAwardBadges(db, "s1");
    const earned2 = checkAndAwardBadges(db, "s1");
    expect(earned2).toHaveLength(0); // Уже получен
    expect(db.studentBadges).toHaveLength(1); // Не дублируется
  });

  it("недостаточно активности → бейджи не начисляются", () => {
    const db = mkDB({
      users: [mkUser("s1")],
      ledger: Array.from({ length: 5 }, (_, i) => ({
        id: `l${i}`,
        userId: "s1",
        points: 10,
        reason: "TASK_COMPLETED",
        sourceId: `t${i}`,
        at: Date.now(),
      })),
    });
    const earned = checkAndAwardBadges(db, "s1");
    expect(earned).toHaveLength(0);
    expect(db.studentBadges).toHaveLength(0);
  });
});
