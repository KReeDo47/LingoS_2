import { useState } from "react";
import { useApp } from "../../lib/store";
import { Button, Icon, INPUT_CLS } from "../../components/ui";

type Nav = (r: string) => void;

export function FeedbackNoteForm({ taskSubmissionId, onClose }: { taskSubmissionId: string; onClose: () => void }) {
  const { addFeedbackNote, toast } = useApp();
  const [whatWentWell, setWhatWentWell] = useState("");
  const [whatToImprove, setWhatToImprove] = useState("");

  const handleSubmit = () => {
    if (!whatWentWell.trim() || !whatToImprove.trim()) {
      toast("Заполните оба поля", "warn");
      return;
    }

    addFeedbackNote(taskSubmissionId, whatWentWell.trim(), whatToImprove.trim());
    toast("Обратная связь отправлена");
    onClose();
  };

  return (
    <div className="rounded-xl border-2 border-pine/30 bg-card p-5">
      <h3 className="mb-4 flex items-center gap-2 font-display text-lg font-bold text-ink">
        <Icon name="pen" size={20} className="text-pine" />
        Структурированная обратная связь
      </h3>

      <div className="flex flex-col gap-4">
        <div>
          <label className="mb-2 flex items-center gap-2 text-[13px] font-semibold text-ink">
            <span className="text-lg">✅</span>
            Что получилось хорошо?
          </label>
          <textarea
            className={`${INPUT_CLS} min-h-[80px]`}
            placeholder="Отметьте сильные стороны работы ученика..."
            value={whatWentWell}
            onChange={(e) => setWhatWentWell(e.target.value)}
          />
        </div>

        <div>
          <label className="mb-2 flex items-center gap-2 text-[13px] font-semibold text-ink">
            <span className="text-lg">🎯</span>
            Что можно улучшить?
          </label>
          <textarea
            className={`${INPUT_CLS} min-h-[80px]`}
            placeholder="Дайте конкретные рекомендации по улучшению..."
            value={whatToImprove}
            onChange={(e) => setWhatToImprove(e.target.value)}
          />
        </div>

        <div className="flex items-center justify-between rounded-lg bg-paper-2/50 p-3">
          <p className="text-[12px] text-ink-3">
            💡 Структурированная обратная связь помогает ученику понять свои сильные стороны и зоны роста
          </p>
        </div>

        <div className="flex gap-2">
          <Button variant="ghost" onClick={onClose}>
            Отмена
          </Button>
          <Button onClick={handleSubmit}>
            <Icon name="send" size={14} /> Отправить обратную связь
          </Button>
        </div>
      </div>
    </div>
  );
}
