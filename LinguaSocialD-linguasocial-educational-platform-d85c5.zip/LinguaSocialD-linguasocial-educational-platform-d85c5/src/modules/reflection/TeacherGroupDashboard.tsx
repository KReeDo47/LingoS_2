import { useApp } from "../../lib/store";
import { pointsOf, timeAgo, weekPoints } from "../../lib/logic";
import { Avatar, Button, Chip, Icon, Reveal, SectionTitle, Toggle } from "../../components/ui";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from "recharts";

type Nav = (r: string) => void;

export function TeacherGroupDashboard({ groupId, navigate }: { groupId: string; navigate: Nav }) {
  const { db, me, toggleDiaryVisibility, toast } = useApp();

  const group = db.groups.find((g) => g.id === groupId);
  if (!me || !group) {
    return (
      <div className="py-16 text-center">
        <Icon name="alert" size={48} className="mx-auto text-ink-3" />
        <p className="mt-4 font-display text-lg font-bold text-ink">Группа не найдена</p>
        <Button className="mt-4" onClick={() => navigate("teacher/dashboard")}>К дашборду</Button>
      </div>
    );
  }

  const students = db.users.filter((u) => u.classGroupId === groupId && u.role === "STUDENT");

  // Агрегированная статистика
  const totalPoints = students.reduce((sum, s) => sum + pointsOf(db, s.id), 0);
  const avgPoints = students.length > 0 ? Math.round(totalPoints / students.length) : 0;

  // Ученики с падением активности (0 заданий за 7 дней)
  const inactiveStudents = students.filter((s) => {
    const weekPointsForStudent = weekPoints(db, s.id, 0);
    return weekPointsForStudent === 0;
  });

  // Статистика по дневникам
  const diaryStats = students.map((s) => {
    const entries = db.diaryEntries.filter((e) => e.studentId === s.id);
    const thisWeek = entries.filter((e) => {
      const entryDate = new Date(e.createdAt);
      const weekAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
      return entryDate >= weekAgo;
    }).length;
    return { student: s, total: entries.length, thisWeek };
  });

  // Данные для графика
  const chartData = students.map((s) => ({
    name: s.displayName,
    points: pointsOf(db, s.id),
    weekPoints: weekPoints(db, s.id, 0),
  }));

  const handleToggleDiaryVisibility = () => {
    toggleDiaryVisibility(groupId);
    toast(group.diaryVisibleToTeacher ? "Содержимое дневников скрыто" : "Содержимое дневников доступно");
  };

  return (
    <div className="flex flex-col gap-6">
      <SectionTitle
        kicker="модуль reflection · дашборд учителя"
        title={`Группа: ${group.name}`}
        right={
          <Button variant="ghost" size="sm" onClick={() => navigate("teacher/dashboard")}>
            <Icon name="arrowRight" size={13} className="rotate-180" /> Назад
          </Button>
        }
      />

      {/* Общая статистика */}
      <div className="grid gap-4 md:grid-cols-3">
        <Reveal>
          <div className="rounded-xl border border-line bg-card p-5">
            <div className="mb-2 flex items-center gap-2">
              <Icon name="users" size={20} className="text-pine" />
              <span className="font-display text-lg font-bold text-ink">Учеников</span>
            </div>
            <p className="text-3xl font-black text-pine">{students.length}</p>
            <p className="text-[12px] text-ink-3">в группе</p>
          </div>
        </Reveal>

        <Reveal delay={50}>
          <div className="rounded-xl border border-line bg-card p-5">
            <div className="mb-2 flex items-center gap-2">
              <Icon name="trophy" size={20} className="text-amber" />
              <span className="font-display text-lg font-bold text-ink">Средний балл</span>
            </div>
            <p className="text-3xl font-black text-amber">{avgPoints}</p>
            <p className="text-[12px] text-ink-3">баллов на ученика</p>
          </div>
        </Reveal>

        <Reveal delay={100}>
          <div className="rounded-xl border border-line bg-card p-5">
            <div className="mb-2 flex items-center gap-2">
              <Icon name="alert" size={20} className="text-coral" />
              <span className="font-display text-lg font-bold text-ink">Требуют внимания</span>
            </div>
            <p className="text-3xl font-black text-coral">{inactiveStudents.length}</p>
            <p className="text-[12px] text-ink-3">учеников без активности</p>
          </div>
        </Reveal>
      </div>

      {/* График баллов учеников */}
      {chartData.length > 0 && (
        <Reveal delay={150}>
          <div className="rounded-xl border border-line bg-card p-5">
            <h3 className="mb-4 font-display text-[15px] font-bold text-ink">
              Баллы учеников
            </h3>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e2e8df" />
                <XAxis dataKey="name" stroke="#748a94" fontSize={12} />
                <YAxis stroke="#748a94" fontSize={12} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "#fbfcf9",
                    border: "1px solid #d8e0d4",
                    borderRadius: "8px",
                  }}
                />
                <Legend />
                <Bar dataKey="points" fill="#0c7a5f" name="Всего баллов" />
                <Bar dataKey="weekPoints" fill="#eda12f" name="За неделю" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </Reveal>
      )}

      {/* Ученики с падением активности */}
      {inactiveStudents.length > 0 && (
        <Reveal delay={200}>
          <div className="rounded-xl border-2 border-coral/30 bg-coral-soft/40 p-5">
            <h3 className="mb-3 flex items-center gap-2 font-display text-[15px] font-bold text-[#8f341a]">
              <Icon name="alert" size={18} />
              Требуют внимания (0 баллов за неделю)
            </h3>
            <div className="flex flex-col gap-2">
              {inactiveStudents.map((s) => (
                <div key={s.id} className="flex items-center gap-3 rounded-lg bg-card p-3">
                  <Avatar user={s} size={36} />
                  <div className="flex-1">
                    <p className="text-[13px] font-bold text-ink">{s.displayName}</p>
                    <p className="text-[11px] text-ink-3">Последняя активность: {timeAgo(s.lastActiveAt)}</p>
                  </div>
                  <Chip tone="coral">Нет активности</Chip>
                </div>
              ))}
            </div>
          </div>
        </Reveal>
      )}

      {/* Статистика дневников */}
      <Reveal delay={250}>
        <div className="rounded-xl border border-line bg-card p-5">
          <div className="mb-4 flex items-center justify-between">
            <h3 className="font-display text-[15px] font-bold text-ink">Дневники учеников</h3>
            <div className="flex items-center gap-2">
              <span className="text-[12px] text-ink-3">Видеть содержимое:</span>
              <Toggle
                checked={group.diaryVisibleToTeacher}
                onChange={handleToggleDiaryVisibility}
              />
            </div>
          </div>
          <div className="flex flex-col gap-3">
            {diaryStats.map(({ student, total, thisWeek }) => (
              <div key={student.id} className="flex items-center gap-3 rounded-lg border border-line bg-paper p-3">
                <Avatar user={student} size={32} />
                <div className="flex-1">
                  <p className="text-[13px] font-bold text-ink">{student.displayName}</p>
                  <p className="text-[11px] text-ink-3">
                    {total} записей всего · {thisWeek} за неделю
                  </p>
                </div>
                <Chip tone={thisWeek > 0 ? "green" : "ink"}>
                  {thisWeek > 0 ? `${thisWeek} на этой неделе` : "Нет записей"}
                </Chip>
              </div>
            ))}
          </div>
          {group.diaryVisibleToTeacher && (
            <div className="mt-4 rounded-lg border border-sky/30 bg-sky-soft/50 p-3">
              <p className="text-[12px] leading-relaxed text-[#275d7e]">
                <Icon name="eye" size={14} className="mr-1 inline" />
                Вы можете видеть содержимое дневников учеников. Переключатель выше позволяет скрыть содержимое.
              </p>
            </div>
          )}
        </div>
      </Reveal>

      {/* Список всех учеников */}
      <Reveal delay={300}>
        <div className="rounded-xl border border-line bg-card p-5">
          <h3 className="mb-4 font-display text-[15px] font-bold text-ink">Все ученики группы</h3>
          <div className="flex flex-col gap-2">
            {students
              .sort((a, b) => pointsOf(db, b.id) - pointsOf(db, a.id))
              .map((s) => {
                const points = pointsOf(db, s.id);
                const week = weekPoints(db, s.id, 0);
                const isActive = week > 0;
                return (
                  <div key={s.id} className="flex items-center gap-3 rounded-lg border border-line bg-paper p-3">
                    <Avatar user={s} size={36} />
                    <div className="flex-1">
                      <p className="text-[13px] font-bold text-ink">{s.displayName}</p>
                      <p className="text-[11px] text-ink-3">
                        Последняя активность: {timeAgo(s.lastActiveAt)}
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="text-[14px] font-black text-pine">{points}</p>
                      <p className="text-[11px] text-ink-3">
                        {week > 0 ? `+${week} за неделю` : "нет активности"}
                      </p>
                    </div>
                    {!isActive && <Chip tone="coral">⚠️</Chip>}
                  </div>
                );
              })}
          </div>
        </div>
      </Reveal>
    </div>
  );
}
