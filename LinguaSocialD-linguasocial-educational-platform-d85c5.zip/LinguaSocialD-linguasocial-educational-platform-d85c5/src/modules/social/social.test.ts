/* ============================================================
   Модуль social · unit-тест suggestTandems(classGroupId)
   Запуск: npx vitest run
   Алгоритм QWEN.md: пары «сильный + слабый» (ZPD_MENTOR)
   по СРЕДНЕМУ score из StudentProgress.
   ============================================================ */
import { describe, expect, it } from "vitest";
import { suggestTandems, avgScoreFromProgress } from "../../lib/logic";
import type { StudentProgress, User } from "../../lib/types";

const mkUser = (id: string, classGroupId: string | null, role: User["role"] = "STUDENT"): User => ({
  id,
  role,
  email: `${id}@test.io`,
  passwordHash: "x",
  fullName: `Полное Имя ${id}`,
  displayName: id.toUpperCase(),
  showAvatar: true,
  mustChangePassword: false,
  hue: 100,
  classGroupId,
  cefr: "A2",
  lastActiveAt: Date.now(),
  createdAt: Date.now(),
});

const prog = (studentId: string, scores: (number | null)[]): StudentProgress[] =>
  scores.map((score, i) => ({
    studentId,
    taskId: `t-${studentId}-${i}`,
    status: score === null ? ("IN_PROGRESS" as const) : ("COMPLETED" as const),
    score,
    completedAt: score === null ? null : Date.now(),
  }));

describe("suggestTandems — автоподбор «сильный + слабый» по среднему score", () => {
  it("4 ученика → 2 пары: крайние по среднему score", () => {
    const users = [mkUser("a", "g1"), mkUser("b", "g1"), mkUser("c", "g1"), mkUser("d", "g1")];
    const progress = [
      ...prog("a", [90, 80]), // avg 85
      ...prog("b", [70, 60]), // avg 65
      ...prog("c", [50, 40]), // avg 45
      ...prog("d", [30, 20]), // avg 25
    ];
    const pairs = suggestTandems({ users, progress }, "g1");
    expect(pairs).toHaveLength(2);
    expect(pairs[0].a.id).toBe("a"); // сильнейший
    expect(pairs[0].b.id).toBe("d"); // слабейший
    expect(pairs[1].a.id).toBe("b");
    expect(pairs[1].b.id).toBe("c");
    expect(pairs.every((p) => p.pairedReason === "ZPD_MENTOR")).toBe(true);
    expect(pairs[0].diff).toBe(60); // 85 - 25
  });

  it("нечётное число учеников: средний остаётся без пары", () => {
    const users = [mkUser("a", "g1"), mkUser("b", "g1"), mkUser("c", "g1")];
    const progress = [...prog("a", [90]), ...prog("b", [60]), ...prog("c", [30])];
    const pairs = suggestTandems({ users, progress }, "g1");
    expect(pairs).toHaveLength(1);
    expect(pairs[0].a.id).toBe("a");
    expect(pairs[0].b.id).toBe("c");
  });

  it("пустая группа → нет пар", () => {
    expect(suggestTandems({ users: [], progress: [] }, "g1")).toHaveLength(0);
  });

  it("ученики других групп не попадают в пары", () => {
    const users = [mkUser("a", "g1"), mkUser("x", "g2"), mkUser("y", "g2")];
    const progress = [...prog("a", [90]), ...prog("x", [40]), ...prog("y", [30])];
    expect(suggestTandems({ users, progress }, "g1")).toHaveLength(0);
    expect(suggestTandems({ users, progress }, "g2")).toHaveLength(1);
  });

  it("учителя не участвуют в подборе", () => {
    const users = [mkUser("a", "g1"), mkUser("t", "g1", "TEACHER"), mkUser("b", "g1")];
    const progress = [...prog("a", [90]), ...prog("b", [30])];
    const pairs = suggestTandems({ users, progress }, "g1");
    expect(pairs).toHaveLength(1);
    expect(pairs[0].b.id).toBe("b");
  });

  it("незавершённые задания (score=null) не учитываются в среднем", () => {
    expect(avgScoreFromProgress(prog("a", [80, null, 60]), "a")).toBe(70);
    expect(avgScoreFromProgress(prog("a", [null, null]), "a")).toBe(0);
  });

  it("детерминированность: одинаковый вход → одинаковые пары", () => {
    const users = [mkUser("a", "g1"), mkUser("b", "g1"), mkUser("c", "g1"), mkUser("d", "g1")];
    const progress = [...prog("a", [88]), ...prog("b", [72]), ...prog("c", [55]), ...prog("d", [31])];
    const p1 = suggestTandems({ users, progress }, "g1").map((p) => `${p.a.id}-${p.b.id}`);
    const p2 = suggestTandems({ users, progress }, "g1").map((p) => `${p.a.id}-${p.b.id}`);
    expect(p1).toEqual(p2);
  });
});
