// @ts-nocheck — файл боевого Next.js 14 стека (App Router + NextAuth).
// В клиентской демо-сборке (Vite SPA) он не компилируется: тот же контроль ролей
// выполняет guard в src/App.tsx (неаутентифицированные → /login, /teacher/* →
// TEACHER|ADMIN, /admin/* → ADMIN, /dashboard → редирект по роли из сессии).

import { withAuth } from "next-auth/middleware";
import { NextResponse } from "next/server";

export default withAuth(
  function middleware(req) {
    const role = req.nextauth.token?.role as string | undefined;
    const { pathname } = req.nextUrl;

    if (pathname.startsWith("/teacher") && role !== "TEACHER" && role !== "ADMIN") {
      return NextResponse.redirect(new URL("/login", req.url));
    }
    if (pathname.startsWith("/admin") && role !== "ADMIN") {
      return NextResponse.redirect(new URL("/login", req.url));
    }

    // /dashboard — редирект по роли из сессии
    if (pathname === "/dashboard") {
      if (role === "STUDENT") return NextResponse.redirect(new URL("/student/dashboard", req.url));
      if (role === "TEACHER") return NextResponse.redirect(new URL("/teacher/dashboard", req.url));
      if (role === "ADMIN") return NextResponse.redirect(new URL("/admin/dashboard", req.url));
    }
    return NextResponse.next();
  },
  { callbacks: { authorized: ({ token }) => !!token } },
);

export const config = {
  matcher: ["/dashboard", "/student/:path*", "/teacher/:path*", "/admin/:path*"],
};
