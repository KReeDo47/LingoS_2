import { useState } from "react";
import { useApp } from "../../lib/store";
import { Button, Chip, Icon, Reveal, SectionTitle } from "../../components/ui";

type Nav = (r: string) => void;

export function SelfAssessmentPage({ unitId, navigate }: { unitId: string; navigate: Nav }) {
  const { db, me, submitSelfAssessment, toast } = useApp();
  const checklist = db.selfAssessmentChecklists.find((c) => c.unitId === unitId);
  const unit = db.courses[0]?.units.find((u) => u.id === unitId);

  const [responses, setResponses] = useState<Record<number, boolean>>({});

  if (!me || !checklist || !unit) {
    return (
      <div className="py-16 text-center">
        <Icon name="alert" size={48} className="mx-auto text-ink-3" />
        <p className="mt-4 font-display text-lg font-bold text-ink">Самооценка для этого юнита недоступна</p>
        <Button className="mt-4" onClick={() => navigate("student/courses")}>К курсам</Button>
      </div>
    );
  }

  const existingResponses = db.selfAssessmentResponses.filter(
    (r) => r.studentId === me.id && r.checklistId === checklist.id
  );

  const handleSubmit = () => {
    const responsesArray = checklist.items.map((_, index) => ({
      itemIndex: index,
      checked: responses[index] ?? false,
    }));
    submitSelfAssessment(checklist.id, responsesArray);
    toast("Самооценка сохранена");
    navigate(`student/courses/${db.courses[0].id}`);
  };

  const toggleItem = (index: number) => {
    setResponses((prev) => ({ ...prev, [index]: !prev[index] }));
  };

  const answeredCount = Object.values(responses).filter(Boolean).length;
  const totalCount = checklist.items.length;

  return (
    <div className="flex flex-col gap-6">
      <SectionTitle
        kicker="модуль reflection · самооценка"
        title={`Самооценка: ${unit.title}`}
        right={<Chip tone="sky">{unit.cefrLevel}</Chip>}
      />

      <Reveal>
        <div className="rounded-xl border border-line bg-card p-5">
          <div className="mb-4 flex items-center gap-3">
            <span className="grid h-12 w-12 place-items-center rounded-xl bg-pine-soft text-pine">
              <Icon name="check" size={24} />
            </span>
            <div>
              <h3 className="font-display text-lg font-bold text-ink">Что я умею после этого юнита?</h3>
              <p className="text-[12px] text-ink-3">Отметьте утверждения, с которыми вы согласны</p>
            </div>
          </div>

          <div className="flex flex-col gap-3">
            {checklist.items.map((item, index) => (
              <button
                key={index}
                onClick={() => toggleItem(index)}
                className={`flex items-center gap-3 rounded-xl border-2 p-4 text-left transition ${
                  responses[index]
                    ? "border-pine bg-pine-soft/30"
                    : "border-line hover:border-pine/50 hover:bg-paper-2/50"
                }`}
              >
                <span
                  className={`grid h-6 w-6 shrink-0 place-items-center rounded-md border-2 transition ${
                    responses[index]
                      ? "border-pine bg-pine text-white"
                      : "border-line bg-card"
                  }`}
                >
                  {responses[index] && <Icon name="check" size={14} strokeWidth={3} />}
                </span>
                <span className="text-[14px] font-semibold text-ink">{item}</span>
              </button>
            ))}
          </div>

          <div className="mt-5 flex items-center justify-between">
            <span className="text-[12px] text-ink-3">
              Отмечено: {answeredCount} из {totalCount}
            </span>
            <div className="flex gap-2">
              <Button variant="ghost" onClick={() => navigate(`student/courses/${db.courses[0].id}`)}>
                Отмена
              </Button>
              <Button onClick={handleSubmit}>
                <Icon name="check" size={14} /> Сохранить самооценку
              </Button>
            </div>
          </div>
        </div>
      </Reveal>

      {existingResponses.length > 0 && (
        <Reveal delay={100}>
          <div className="rounded-xl border border-amber/30 bg-amber-soft/40 p-4">
            <p className="flex items-center gap-2 text-[13px] font-semibold text-[#8a5a10]">
              <Icon name="alert" size={16} />
              Вы уже проходили самооценку для этого юнита. Новая оценка заменит предыдущую.
            </p>
          </div>
        </Reveal>
      )}
    </div>
  );
}
