import { Button, Chip, Icon, Reveal, SectionTitle } from "../components/ui";

type Nav = (r: string) => void;

export function LegalPage({ navigate }: { navigate: Nav }) {
  return (
    <div className="mx-auto max-w-4xl">
      <SectionTitle
        kicker="правовая информация"
        title="Обработка персональных данных"
        right={
          <Button variant="ghost" size="sm" onClick={() => navigate("dashboard")}>
            <Icon name="arrowRight" size={13} className="rotate-180" /> Назад
          </Button>
        }
      />

      <Reveal>
        <div className="rounded-xl border border-line bg-card p-6">
          <div className="mb-6 flex items-center gap-3">
            <span className="grid h-12 w-12 place-items-center rounded-xl bg-pine-soft text-pine">
              <Icon name="shield" size={24} />
            </span>
            <div>
              <h3 className="font-display text-lg font-bold text-ink">Защита данных несовершеннолетних</h3>
              <p className="text-[12px] text-ink-3">LinguaSocial · образовательная платформа</p>
            </div>
          </div>

          <div className="space-y-5 text-[13.5px] leading-relaxed text-ink-2">
            <section>
              <h4 className="mb-2 font-display text-[15px] font-bold text-ink">Какие данные собираются</h4>
              <ul className="list-inside list-disc space-y-1.5">
                <li>
                  <b>Для учеников (5–9 класс, 10–15 лет):</b> displayName (публичный ник), аватар
                  (опционально), учебный прогресс (баллы, выполненные задания, самооценки), записи в
                  дневнике рефлексии, сообщения в чате учебной группы.
                </li>
                <li>
                  <b>Для учителей:</b> fullName, email, displayName, список курируемых групп,
                  действия модерации.
                </li>
                <li>
                  <b>Для администраторов:</b> fullName, email, displayName, полный доступ к журналу
                  безопасности (SafetyLog).
                </li>
              </ul>
            </section>

            <section>
              <h4 className="mb-2 font-display text-[15px] font-bold text-ink">Цели обработки данных</h4>
              <ul className="list-inside list-disc space-y-1.5">
                <li>Организация учебного процесса в рамках образовательной платформы</li>
                <li>Отслеживание прогресса учеников и адаптация учебного контента</li>
                <li>Обеспечение безопасности несовершеннолетних пользователей (модерация контента)</li>
                <li>Педагогический контроль и обратная связь от учителей</li>
              </ul>
            </section>

            <section>
              <h4 className="mb-2 font-display text-[15px] font-bold text-ink">Согласие законных представителей</h4>
              <p className="mb-2">
                Создание учётной записи ученика возможно <b>только</b> при наличии согласия законного
                представителя (родителя или опекуна). Учитель фиксирует ФИО представителя и дату
                согласия при создании аккаунта.
              </p>
              <p>
                Открытая регистрация учеников <b>отключена</b> — это предотвращает несанкционированный
                доступ несовершеннолетних к платформе без ведома родителей.
              </p>
            </section>

            <section>
              <h4 className="mb-2 font-display text-[15px] font-bold text-ink">Приватность и видимость данных</h4>
              <ul className="list-inside list-disc space-y-1.5">
                <li>
                  <b>Ученики видят друг друга:</b> только displayName и аватар (если включён в
                  настройках приватности). fullName недоступен.
                </li>
                <li>
                  <b>Учителя видят:</b> fullName всех учеников своих групп, учебный прогресс, записи в
                  дневнике (опционально, настраивается флагом diaryVisibleToTeacher).
                </li>
                <li>
                  <b>Администраторы видят:</b> все данные платформы, включая журнал безопасности
                  (SafetyLog).
                </li>
                <li>
                  <b>Чат:</b> сообщения существуют только в рамках учебной группы. Личные сообщения
                  между произвольными пользователями отключены конструктивно.
                </li>
              </ul>
            </section>

            <section>
              <h4 className="mb-2 font-display text-[15px] font-bold text-ink">Модерация и безопасность</h4>
              <ul className="list-inside list-disc space-y-1.5">
                <li>
                  Автоматический фильтр запрещённых слов (BannedWordList) с двумя уровнями: WARN
                  (предупреждение) и AUTO_HIDE (автоматическое скрытие).
                </li>
                <li>
                  Все действия модерации записываются в append-only журнал SafetyLog, который никогда
                  не удаляется.
                </li>
                <li>
                  Учителя могут просматривать и обрабатывать флаги контента (ContentFlag) для своих
                  групп.
                </li>
              </ul>
            </section>

            <section className="rounded-xl border border-amber/30 bg-amber-soft/40 p-4">
              <h4 className="mb-2 flex items-center gap-2 font-display text-[15px] font-bold text-[#7a4d0d]">
                <Icon name="alert" size={18} />
                Правовая основа
              </h4>
              <p className="mb-2 text-[13px] leading-relaxed text-[#8a5a10]">
                Обработка персональных данных несовершеннолетних осуществляется в соответствии с:
              </p>
              <ul className="list-inside list-disc space-y-1 text-[13px] text-[#8a5a10]">
                <li>
                  <b>Федеральный закон от 27.07.2006 № 152-ФЗ</b> «О персональных данных»
                </li>
                <li>
                  <b>Федеральный закон от 29.12.2010 № 436-ФЗ</b> «О защите детей от информации,
                  причиняющей вред их здоровью и развитию»
                </li>
              </ul>
              <p className="mt-3 text-[12px] italic text-[#8a5a10]">
                TODO: согласовать с юристом школы/организации. Данный текст является заглушкой и не
                является юридически значимой формулировкой.
              </p>
            </section>

            <section>
              <h4 className="mb-2 font-display text-[15px] font-bold text-ink">Контакты</h4>
              <p>
                По вопросам обработки персональных данных обращайтесь к администрации образовательной
                организации или к учителю, курирующему учебную группу.
              </p>
            </section>
          </div>
        </div>
      </Reveal>

      <Reveal delay={100}>
        <div className="mt-6 flex items-center justify-center gap-3">
          <Button variant="ghost" onClick={() => navigate("dashboard")}>
            <Icon name="home" size={14} /> На главную
          </Button>
        </div>
      </Reveal>
    </div>
  );
}
