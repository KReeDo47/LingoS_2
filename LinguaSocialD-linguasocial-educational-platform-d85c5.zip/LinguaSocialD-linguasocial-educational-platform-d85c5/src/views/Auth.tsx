import { useState } from "react";
import type { ReactNode } from "react";
import { useApp } from "../lib/store";
import type { FieldErrors } from "../lib/validation";
import { Button, Chip, Icon, INPUT_CLS } from "../components/ui";

const PHRASES = ["Hello!", "Bonjour!", "¡Hola!", "Hallo!", "Ciao!", "こんにちは!", "你好!", "Merhaba!", "Olá!", "Γειά σου!", "Hej!", "Ahoj!", "Здравствуйте!", "Hi there!"];

const DEMO = [
  { label: "Ученик · Аня", email: "anya@lingua.school" },
  { label: "Учитель · Мария Викторовна", email: "marina@lingua.school" },
  { label: "Админ", email: "root@lingua.school" },
];

function FieldError({ errors, field }: { errors: FieldErrors; field: string }) {
  const msg = errors[field]?.[0];
  return msg ? <p className="mt-1 flex items-center gap-1 text-[12px] font-semibold text-coral"><Icon name="alert" size={12} /> {msg}</p> : null;
}

export function AuthPage({ navigate }: { navigate: (r: string) => void }) {
  const { login, register, toast } = useApp();
  const [tab, setTab] = useState<"login" | "register">("login");
  const [errors, setErrors] = useState<FieldErrors>({});
  const [formError, setFormError] = useState("");

  /* login */
  const [lEmail, setLEmail] = useState("");
  const [lPw, setLPw] = useState("");
  /* register */
  const [role, setRole] = useState<"TEACHER" | "ADMIN">("TEACHER");
  const [rFull, setRFull] = useState("");
  const [rNick, setRNick] = useState("");
  const [rEmail, setREmail] = useState("");
  const [rPw, setRPw] = useState("");
  const [rPw2, setRPw2] = useState("");
  const [rGroup, setRGroup] = useState("");
  const [rOrg, setROrg] = useState("");

  const doLogin = (email = lEmail, pw = lPw) => {
    setFormError("");
    const res = login(email, pw);
    if (!res.ok) {
      setErrors(res.errors ?? {});
      if (res.error) setFormError(res.error);
      return;
    }
    setErrors({});
    toast(`Добро пожаловать, ${res.user.displayName}!`);
    navigate("dashboard");
  };

  const doRegister = () => {
    setFormError("");
    const res = register({ fullName: rFull, displayName: rNick, email: rEmail, password: rPw, confirm: rPw2, role, groupName: rGroup, organizationName: rOrg });
    if (!res.ok) {
      setErrors(res.errors ?? {});
      if (res.error) setFormError(res.error);
      return;
    }
    setErrors({});
    toast("Аккаунт создан — вы вошли");
    navigate("dashboard");
  };

  const input = (label: string, node: ReactNode, field?: string) => (
    <div>
      <label className="mb-1 block text-[12px] font-semibold text-ink-2">{label}</label>
      {node}
      {field && <FieldError errors={errors} field={field} />}
    </div>
  );

  return (
    <div className="flex min-h-screen flex-col lg:flex-row">
      {/* -------- левая панель -------- */}
      <section className="relative flex flex-col justify-between overflow-hidden bg-night px-6 py-8 text-paper sm:px-10 lg:min-h-screen lg:w-[52%] lg:px-14 lg:py-12">
        <div className="pointer-events-none absolute inset-0 opacity-[0.16]" style={{ backgroundImage: "radial-gradient(rgba(237,161,47,0.25) 1px, transparent 1.4px)", backgroundSize: "26px 26px" }} />
        <div className="relative flex items-center gap-3">
          <span className="grid h-11 w-11 place-items-center rounded-xl bg-pine font-display text-base font-black text-white">Aa</span>
          <div className="font-display leading-tight">
            <p className="text-lg font-bold">Lingua<span className="text-amber">Social</span></p>
            <p className="text-[11px] text-paper/50">цифровая среда · 5–9 класс · CEFR A1–B2</p>
          </div>
        </div>

        <div className="relative my-10 lg:my-0">
          <p className="mb-3 inline-flex items-center gap-2 rounded-full border border-night-3 bg-night-2 px-3 py-1 text-[12px] font-semibold text-paper/70">
            <span className="blink-dot h-1.5 w-1.5 rounded-full bg-pine" /> модуль users · безопасные аккаунты
          </p>
          <h1 className="font-display text-[30px] font-black leading-[1.12] sm:text-[40px] lg:text-[44px]">
            Детей приводит<br />
            <span className="text-pine">учитель</span>, не <span className="text-amber">форма</span>
          </h1>
          <ul className="mt-5 max-w-md space-y-2.5 text-[14px] leading-relaxed text-paper/70">
            {([
              ["lock", "Открытая регистрация учеников отключена — аккаунт создаёт учитель внутри ClassGroup."],
              ["key", "Временный пароль показывается учителю один раз; при первом входе ученик меняет его."],
              ["shield", "Согласие законного представителя — обязательное поле, фиксируется с датой."],
              ["eye", "Сверстники видят только ник и аватар. fullName доступен лишь учителю и админу."],
            ] as const).map(([ic, text]) => (
              <li key={ic} className="flex gap-2.5">
                <Icon name={ic} size={16} className="mt-1 shrink-0 text-amber" />
                <span>{text}</span>
              </li>
            ))}
          </ul>
        </div>

        <div className="relative">
          <div className="overflow-hidden [mask-image:linear-gradient(90deg,transparent,black_12%,black_88%,transparent)]">
            <div className="anim-marquee flex w-max gap-3">
              {[...PHRASES, ...PHRASES].map((p, i) => (
                <span key={i} className="whitespace-nowrap rounded-full border border-night-3 bg-night-2 px-4 py-1.5 font-display text-[13px] font-medium text-paper/75">{p}</span>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* -------- правая панель -------- */}
      <section className="flex flex-1 items-center justify-center px-4 py-10 sm:px-8">
        <div className="anim-fade-up w-full max-w-md">
          <div className="mb-5 flex rounded-xl border border-line bg-card p-1.5">
            {([["login", "Вход"], ["register", "Регистрация учителя / админа"]] as const).map(([id, label]) => (
              <button key={id} onClick={() => { setTab(id); setErrors({}); setFormError(""); }} className={`flex-1 cursor-pointer rounded-lg px-3 py-2 text-[13.5px] font-bold transition-all ${tab === id ? "bg-night text-paper shadow" : "text-ink-2 hover:bg-paper-2"}`}>
                {label}
              </button>
            ))}
          </div>

          <div className="rounded-2xl border border-line bg-card p-5 shadow-[0_24px_60px_-36px_rgba(23,38,46,0.45)]">
            {tab === "login" ? (
              <>
                <h2 className="font-display text-xl font-black text-ink">Вход (Credentials)</h2>
                <p className="mt-1 text-[13px] text-ink-2">Сессия хранит роль: STUDENT, TEACHER или ADMIN.</p>
                <div className="mt-4 flex flex-col gap-3">
                  {input("Email", <input className={INPUT_CLS} placeholder="anya@lingua.school" value={lEmail} onChange={(e) => setLEmail(e.target.value)} />, "email")}
                  {input("Пароль", <input type="password" className={INPUT_CLS} placeholder="••••••••" value={lPw} onChange={(e) => setLPw(e.target.value)} onKeyDown={(e) => e.key === "Enter" && doLogin()} />, "password")}
                </div>
                {formError && <p className="mt-2.5 flex items-center gap-1.5 rounded-lg bg-coral-soft px-3 py-2 text-[12.5px] font-bold text-[#8f341a]"><Icon name="alert" size={14} /> {formError}</p>}
                <Button size="lg" className="mt-4 w-full" onClick={() => doLogin()}>Войти <Icon name="arrowRight" size={16} /></Button>

                <div className="mt-4 border-t border-line pt-3.5">
                  <p className="mb-2 text-[11px] font-bold uppercase tracking-[0.14em] text-ink-3">Демо-доступ (пароль: demo123)</p>
                  <div className="flex flex-wrap gap-1.5">
                    {DEMO.map((d) => (
                      <button key={d.email} onClick={() => { setLEmail(d.email); setLPw("demo123"); doLogin(d.email, "demo123"); }} className="cursor-pointer rounded-full border border-line bg-paper px-3 py-1.5 text-[12px] font-semibold text-ink-2 transition hover:border-pine hover:text-pine-deep">
                        {d.label}
                      </button>
                    ))}
                  </div>
                </div>
              </>
            ) : (
              <>
                <h2 className="font-display text-xl font-black text-ink">Регистрация</h2>
                <p className="mt-1 text-[13px] leading-relaxed text-ink-2">
                  Только <b>TEACHER</b> и <b>ADMIN</b>. Ученики получают аккаунт и временный пароль от учителя.
                </p>
                <div className="mt-4 grid grid-cols-2 gap-2">
                  {([["TEACHER", "Учитель"], ["ADMIN", "Администратор"]] as const).map(([r, label]) => (
                    <button key={r} onClick={() => setRole(r)} className={`cursor-pointer rounded-xl border-2 px-3 py-2.5 text-[13px] font-bold transition ${role === r ? "border-pine bg-pine-soft/60 text-pine-deep" : "border-line text-ink-2 hover:border-ink-3/40"}`}>
                      {label}
                    </button>
                  ))}
                </div>
                <div className="mt-3 flex flex-col gap-3">
                  {input("ФИО", <input className={INPUT_CLS} placeholder="Соколова Мария Викторовна" value={rFull} onChange={(e) => setRFull(e.target.value)} />, "fullName")}
                  {input("displayName (ник)", <input className={INPUT_CLS} placeholder="Мария Викторовна" value={rNick} onChange={(e) => setRNick(e.target.value)} />, "displayName")}
                  {input("Email", <input className={INPUT_CLS} placeholder="marina@school.ru" value={rEmail} onChange={(e) => setREmail(e.target.value)} />, "email")}
                  <div className="grid grid-cols-2 gap-3">
                    {input("Пароль", <input type="password" className={INPUT_CLS} value={rPw} onChange={(e) => setRPw(e.target.value)} />, "password")}
                    {input("Ещё раз", <input type="password" className={INPUT_CLS} value={rPw2} onChange={(e) => setRPw2(e.target.value)} />, "confirm")}
                  </div>
                  {role === "TEACHER" && (
                    <>
                      {input("Название учебной группы (ClassGroup)", <input className={INPUT_CLS} placeholder="7 «А»" value={rGroup} onChange={(e) => setRGroup(e.target.value)} />)}
                      {input("Школа / организация", <input className={INPUT_CLS} placeholder="Школа № 17" value={rOrg} onChange={(e) => setROrg(e.target.value)} />)}
                    </>
                  )}
                </div>
                {formError && <p className="mt-2.5 flex items-center gap-1.5 rounded-lg bg-coral-soft px-3 py-2 text-[12.5px] font-bold text-[#8f341a]"><Icon name="alert" size={14} /> {formError}</p>}
                <Button size="lg" className="mt-4 w-full" onClick={doRegister}>Создать аккаунт <Icon name="arrowRight" size={16} /></Button>
              </>
            )}

            <div className="mt-4 flex flex-wrap items-center justify-center gap-1.5 border-t border-line pt-3.5 text-[11px] text-ink-3">
              <Chip tone="green">NextAuth-сессия с role</Chip>
              <Chip tone="amber">middleware: /teacher/*, /admin/*</Chip>
              <Chip tone="sky">Zod-валидация</Chip>
            </div>
          </div>

          <p className="mt-4 text-center text-[12px] text-ink-3">Данные демо-среды живут в вашем браузере. Сброс — в панели администратора.</p>
        </div>
      </section>
    </div>
  );
}
