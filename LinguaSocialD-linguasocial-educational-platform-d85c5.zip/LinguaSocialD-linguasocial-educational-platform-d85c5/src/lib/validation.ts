/* ============================================================
   Модуль users + content · Zod-схемы (QWEN.md)
   Единый источник валидации: и в клиентских действиях стора,
   и в API route handlers боевого Next.js-стека.
   ============================================================ */
import { z } from "zod";

/** Прямая регистрация учителей и админов (email + пароль). Роль STUDENT недоступна. */
export const registerSchema = z
  .object({
    fullName: z.string().trim().min(5, "Укажите фамилию и имя полностью"),
    displayName: z.string().trim().min(2, "Ник — минимум 2 символа").max(20, "Ник — максимум 20 символов"),
    email: z.string().trim().toLowerCase().email("Некорректный email"),
    password: z.string().min(6, "Пароль — минимум 6 символов").max(64, "Слишком длинный пароль"),
    confirm: z.string(),
    role: z.enum(["TEACHER", "ADMIN"]),
    groupName: z.string().trim().optional(),
    organizationName: z.string().trim().optional(),
  })
  .refine((d) => d.password === d.confirm, { message: "Пароли не совпадают", path: ["confirm"] });

export const loginSchema = z.object({
  email: z.string().trim().toLowerCase().email("Некорректный email"),
  password: z.string().min(1, "Введите пароль"),
});

/**
 * Создание ученика — только учитель/админ.
 * КЛЮЧЕВОЕ ПРАВИЛО: без согласия законного представителя создать
 * учётную запись ученика НЕВОЗМОЖНО (consentGiven обязан быть true,
 * consentGivenBy — заполнен).
 */
export const createStudentSchema = z.object({
  displayName: z.string().trim().min(2, "Ник — минимум 2 символа").max(20, "Ник — максимум 20 символов"),
  fullName: z.string().trim().min(5, "Укажите фамилию и имя полностью"),
  email: z.string().trim().toLowerCase().email("Некорректный email"),
  classGroupId: z.string().min(1, "Выберите учебную группу"),
  cefr: z.enum(["A1", "A2", "B1", "B2"]),
  consentGiven: z
    .boolean({ message: "Отметьте согласие законного представителя" })
    .refine((v) => v === true, { message: "Без согласия законного представителя создать ученика нельзя" }),
  consentGivenBy: z.string().trim().min(2, "Укажите ФИО законного представителя, давшего согласие"),
});

export const changePasswordSchema = z
  .object({
    password: z.string().min(6, "Новый пароль — минимум 6 символов").max(64),
    confirm: z.string(),
  })
  .refine((d) => d.password === d.confirm, { message: "Пароли не совпадают", path: ["confirm"] });

/** CRUD курса (модуль content): верхнеуровневые поля + непустые юниты/задания */
export const courseSchema = z.object({
  id: z.string(),
  title: z.string().trim().min(2, "Название курса — минимум 2 символа"),
  languageCode: z.string().trim().min(2, "Укажите код языка (en, de, fr…)"),
  levelFrom: z.enum(["A1", "A2", "B1", "B2"]),
  levelTo: z.enum(["A1", "A2", "B1", "B2"]),
  description: z.string().optional(),
  units: z
    .array(
      z.object({
        id: z.string(),
        title: z.string().trim().min(2, "Название юнита — минимум 2 символа"),
        order: z.number(),
        cefrLevel: z.enum(["A1", "A2", "B1", "B2"]),
        tasks: z.array(z.any()).min(1, "В юните должно быть хотя бы одно задание"),
      }),
    )
    .min(1, "Добавьте хотя бы один юнит"),
});

export type RegisterInput = z.input<typeof registerSchema>;
export type CreateStudentInput = z.input<typeof createStudentSchema>;
export type FieldErrors = Record<string, string[] | undefined>;

export function parseWith<S extends z.ZodTypeAny>(schema: S, raw: unknown) {
  const r = schema.safeParse(raw);
  return r.success
    ? ({ ok: true, data: r.data } as const)
    : ({ ok: false, errors: r.error.flatten().fieldErrors as FieldErrors } as const);
}

/* ---------- временный пароль для ученика ---------- */
const TEMP_ALPHABET = "abcdefghjkmnpqrstuvwxyz23456789"; // без l/1/o/0

/** Детерминирован при передаче rand — удобно для тестов */
export function generateTempPassword(rand: () => number = Math.random): string {
  let body = "";
  for (let i = 0; i < 6; i++) body += TEMP_ALPHABET[Math.floor(rand() * TEMP_ALPHABET.length)];
  return `ling-${body}`;
}

/* ---------- хэш пароля (в боевом стеке — bcrypt/argon2) ---------- */
export function hashPassword(pw: string): string {
  let h = 5381;
  for (let i = 0; i < pw.length; i++) h = ((h << 5) + h + pw.charCodeAt(i)) | 0;
  return `djb2:${(h >>> 0).toString(16)}`;
}
