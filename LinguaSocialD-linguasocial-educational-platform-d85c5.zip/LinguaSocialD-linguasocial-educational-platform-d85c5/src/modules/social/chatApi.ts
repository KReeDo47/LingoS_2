/* ============================================================
   Модуль social (QWEN.md, модуль 3, п.5–6) · REST-эмуляция чата
   ------------------------------------------------------------
   Чат существует ТОЛЬКО в рамках classGroupId — API отклоняет
   отправку в группу, к которой пользователь не привязан.
   Скрытые сообщения (hidden) НЕ возвращаются обычным
   пользователям — только TEACHER/ADMIN (для модуля moderation).
   Клиент поллит GET /api/groups/:id/messages раз в 5 секунд
   (см. ChatTab в SocialView); websocket — на следующем этапе.
   ============================================================ */
import type { DB, ModeratedMessage, Role } from "../../lib/types";

/** Снимок «серверной БД»: стор синхронизирует его при каждом изменении */
let snapshot: DB | null = null;

export function syncApiSnapshot(db: DB) {
  snapshot = db;
}

/**
 * GET /api/groups/:classGroupId/messages
 * hidden-сообщения видят только TEACHER/ADMIN.
 */
export function fetchGroupMessages(classGroupId: string, viewerRole: Role): ModeratedMessage[] {
  if (!snapshot) return [];
  return snapshot.messages
    .filter((m) => m.classGroupId === classGroupId)
    .filter((m) => !m.hidden || viewerRole === "TEACHER" || viewerRole === "ADMIN")
    .sort((a, b) => a.createdAt - b.createdAt);
}

/** Проверка привязки пользователя к группе — как на сервере */
export function isGroupMember(db: DB, userId: string, classGroupId: string): boolean {
  const user = db.users.find((u) => u.id === userId);
  if (!user) return false;
  if (user.role === "STUDENT") return user.classGroupId === classGroupId;
  if (user.role === "TEACHER") return db.groups.some((g) => g.id === classGroupId && g.teacherId === user.id);
  return true; // ADMIN
}

/**
 * POST /api/groups/:classGroupId/messages
 * Серверная проверка: отправить сообщение в чужую группу нельзя.
 */
export function postGroupMessage(
  db: DB,
  classGroupId: string,
  authorId: string,
): { ok: boolean; error?: string } {
  if (!isGroupMember(db, authorId, classGroupId)) {
    return { ok: false, error: "API отклонил запрос: вы не участник этой учебной группы" };
  }
  if (!db.groups.some((g) => g.id === classGroupId)) {
    return { ok: false, error: "Группа не найдена" };
  }
  return { ok: true };
}
