/* ============================================================
   МОДУЛЬ content (QWEN.md, модуль 2) · чистые функции
   Адаптивное ветвление + прогресс. Без React — покрыто тестами:
   npx vitest run src/modules/content/suggest.test.ts
   ============================================================ */
import type { Course, StudentProgress, Task, TaskType, Unit } from "../../lib/types";

/** Порог адаптивного ветвления: score < 60% считается низким */
export const LOW_SCORE = 60;
/** Сколько последних заданий юнита анализируем */
export const WINDOW = 3;

/** Минимальная структура БД — удобно и в приложении, и в тестах */
export interface ProgressSource {
  courses: Course[];
  progress: StudentProgress[];
}

export const TASK_TYPE_META: Record<TaskType, { label: string; icon: string; hue: number }> = {
  VOCAB: { label: "Словарь", icon: "book", hue: 152 },
  GRAMMAR: { label: "Грамматика", icon: "sliders", hue: 208 },
  LISTENING: { label: "Аудирование", icon: "volume", hue: 268 },
  WRITING: { label: "Письмо", icon: "pen", hue: 24 },
  SPEAKING_PROMPT: { label: "Говорение", icon: "mic", hue: 320 },
};

export const CEFR_ORDER = ["A1", "A2", "B1", "B2"] as const;

/* ---------------- прогресс ---------------- */

export function getProgress(list: StudentProgress[], studentId: string, taskId: string): StudentProgress | undefined {
  return list.find((p) => p.studentId === studentId && p.taskId === taskId);
}

export interface UnitProgress {
  done: number;
  total: number;
  requiredDone: number;
  requiredTotal: number;
  /** юнит пройден, если завершены все requiredForCompletion-задания */
  complete: boolean;
  pct: number;
}

export function unitProgress(list: StudentProgress[], studentId: string, unit: Unit): UnitProgress {
  const required = unit.tasks.filter((t) => t.requiredForCompletion);
  const done = unit.tasks.filter((t) => getProgress(list, studentId, t.id)?.status === "COMPLETED").length;
  const requiredDone = required.filter((t) => getProgress(list, studentId, t.id)?.status === "COMPLETED").length;
  const complete = required.every((t) => getProgress(list, studentId, t.id)?.status === "COMPLETED");
  return {
    done,
    total: unit.tasks.length,
    requiredDone,
    requiredTotal: required.length,
    complete,
    pct: unit.tasks.length ? Math.round((done / unit.tasks.length) * 100) : 0,
  };
}

export function courseProgress(list: StudentProgress[], studentId: string, course: Course) {
  const units = sortedUnits(course);
  const total = units.reduce((s, u) => s + u.tasks.length, 0);
  const done = units.reduce((s, u) => s + unitProgress(list, studentId, u).done, 0);
  return { done, total, pct: total ? Math.round((done / total) * 100) : 0 };
}

export function sortedUnits(course: Course): Unit[] {
  return [...course.units].sort((a, b) => a.order - b.order);
}

export function sortedTasks(unit: Unit): Task[] {
  return [...unit.tasks].sort((a, b) => a.order - b.order);
}

export function findTask(db: ProgressSource, taskId: string): { course: Course; unit: Unit; task: Task } | null {
  for (const course of db.courses) {
    for (const unit of course.units) {
      const task = unit.tasks.find((t) => t.id === taskId);
      if (task) return { course, unit, task };
    }
  }
  return null;
}

/* ---------------- адаптивное ветвление ---------------- */

export type UnitSuggestion =
  | {
      kind: "REVIEW";
      course: Course;
      /** upstream-юнит того же уровня, который рекомендуется повторить */
      unit: Unit;
      /** юнит, переход к которому заблокирован до повтора */
      blockedUnit: Unit;
      lowScores: number[];
      reason: string;
    }
  | { kind: "NEXT"; course: Course; unit: Unit }
  | { kind: "COURSE_DONE"; course: Course };

/**
 * Адаптивное ветвление (QWEN.md, модуль 2, п.1).
 *
 * Если StudentProgress показывает СТАБИЛЬНО низкий score (<60%) по последним
 * WINDOW(3) оценённым заданиям юнита — рекомендуем повторный (upstream) юнит
 * того же уровня CEFR перед переходом дальше; следующий юнит блокируется.
 *
 * Проверяются два кандидата: только что пройденный юнит (перед переходом
 * дальше) и текущий «фронтовый» юнит (если ученик застрял внутри него).
 */
export function suggestNextUnit(db: ProgressSource, studentId: string): UnitSuggestion | null {
  const course = db.courses[0];
  if (!course) return null;
  const units = sortedUnits(course);
  if (units.length === 0) return null;

  const scoreOf = (taskId: string): number | null => {
    const p = getProgress(db.progress, studentId, taskId);
    return p && p.status === "COMPLETED" ? p.score : null;
  };

  const frontierIdx = units.findIndex((u) => !unitProgress(db.progress, studentId, u).complete);

  // Все обязательные задания всех юнитов выполнены — курс завершён
  if (frontierIdx === -1) return { kind: "COURSE_DONE", course };

  const frontier = units[frontierIdx];
  const prevUnit = frontierIdx > 0 ? units[frontierIdx - 1] : null;

  // Кандидаты на проверку «стабильно низких» результатов:
  // 1) пройденный юнит перед фронтовым (сценарий «перед переходом дальше»);
  // 2) сам фронтовый юнит (сценарий «застрял внутри юнита»).
  const candidates: Unit[] = prevUnit ? [prevUnit, frontier] : [frontier];

  for (const candidate of candidates) {
    const scored = sortedTasks(candidate).filter((t) => scoreOf(t.id) !== null);
    const last = scored.slice(-WINDOW);
    const lowScores = last.map((t) => scoreOf(t.id) as number);
    if (last.length >= WINDOW && lowScores.every((s) => s < LOW_SCORE)) {
      // upstream-юнит того же уровня: идём назад от кандидата, ищем юнит того же
      // cefrLevel с незакрытыми заданиями (или сам кандидат — повтор материала).
      const idx = units.indexOf(candidate);
      const upstream =
        [...units.slice(0, idx)]
          .reverse()
          .find((u) => u.cefrLevel === candidate.cefrLevel && !unitProgress(db.progress, studentId, u).complete) ??
        [...units.slice(0, idx)].reverse().find((u) => u.cefrLevel === candidate.cefrLevel) ??
        candidate;
      return {
        kind: "REVIEW",
        course,
        unit: upstream,
        blockedUnit: frontier,
        lowScores,
        reason: "Последние " + WINDOW + " задания юнита «" + candidate.title + "» — " + lowScores.join("%, ") + "% (ниже " + LOW_SCORE + "%). Перед переходом к «" + frontier.title + "» повторите материал.",
      };
    }
  }

  return { kind: "NEXT", course, unit: frontier };
}
