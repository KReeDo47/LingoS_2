import { useEffect, useRef, useState } from "react";
import type { ButtonHTMLAttributes, CSSProperties, ReactNode } from "react";
import type { User } from "../lib/types";
import { initials } from "../lib/logic";
import { useApp } from "../lib/store";

/* ================= иконки (inline SVG) ================= */

export const ICONS = {
  book: "M4 19.5A2.5 2.5 0 0 1 6.5 17H20V4a2 2 0 0 0-2-2H6.5A2.5 2.5 0 0 0 4 4.5v15zM4 19.5A2.5 2.5 0 0 0 6.5 22H20v-5",
  users: "M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2M9 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8zM23 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75",
  trophy: "M6 9H4.5a2.5 2.5 0 0 1 0-5H6m12 5h1.5a2.5 2.5 0 0 0 0-5H18M6 2h12v7a6 6 0 0 1-12 0V2zm6 13v3m-4 4h8m-8 0v-2a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2",
  pen: "M12 20h9M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z",
  chart: "M18 20V10M12 20V4M6 20v-6",
  shield: "M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z",
  sliders: "M4 21v-7m0-4V3m8 18v-9m0-4V3m8 18v-5m0-4V3M1 14h6m2-6h6m2 8h6",
  logout: "M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4M16 17l5-5-5-5M21 12H9",
  check: "M20 6L9 17l-5-5",
  x: "M18 6L6 18M6 6l12 12",
  alert: "M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0zM12 9v4m0 4h.01",
  star: "M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z",
  crown: "M2 8l4 4 6-8 6 8 4-4v10a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V8z",
  medal: "M7.21 15L2.66 7.14a2 2 0 0 1 .13-2.2L4.4 2.8A2 2 0 0 1 6 2h12a2 2 0 0 1 1.6.8l1.6 2.14a2 2 0 0 1 .14 2.2L16.79 15M12 15a7 7 0 1 0 0 14 7 7 0 0 0 0-14z",
  refresh: "M23 4v6h-6M1 20v-6h6M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15",
  lock: "M5 11h14v10H5zM7 11V7a5 5 0 0 1 10 0v4",
  arrowRight: "M5 12h14m-7-7l7 7-7 7",
  doc: "M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8l-6-6zM14 2v6h6M16 13H8m8 4H8m2-8H8",
  flag: "M4 15s1-1 4-1 5 2 8 2 4-1 4-1V3s-1 1-4 1-5-2-8-2-4 1-4 1zM4 22v-7",
  chat: "M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z",
  plus: "M12 5v14M5 12h14",
  sparkle: "M12 3l1.9 5.7L19.6 10.6l-5.7 1.9L12 18.2l-1.9-5.7L4.4 10.6l5.7-1.9L12 3z",
  target: "M12 22a10 10 0 1 0 0-20 10 10 0 0 0 0 20zm0-6a4 4 0 1 0 0-8 4 4 0 0 0 0 8zm0-3.5a.5.5 0 1 0 0-1 .5.5 0 0 0 0 1z",
  trash: "M3 6h18m-2 0v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2",
  eye: "M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8zm11 3a3 3 0 1 0 0-6 3 3 0 0 0 0 6z",
  clock: "M12 22a10 10 0 1 0 0-20 10 10 0 0 0 0 20zm0-16v6l4 2",
  send: "M22 2L11 13M22 2l-7 20-4-9-9-4 20-7z",
  home: "M3 9.5L12 3l9 6.5V21a1 1 0 0 1-1 1h-5v-7h-6v7H4a1 1 0 0 1-1-1z",
  key: "M21 2l-2 2m-7.61 7.61a5.5 5.5 0 1 1-7.778 7.778 5.5 5.5 0 0 1 7.777-7.777zm0 0L15.5 7.5m0 0l3 3L22 7l-3-3m-3.5 3.5L19 4",
  volume: "M11 5L6 9H2v6h4l5 4V5zm4.54 1.46a5 5 0 0 1 0 7.07M19.07 4.93a10 10 0 0 1 0 14.14",
  mic: "M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3zm7 11a7 7 0 0 1-14 0m7 7v4m-4 0h8",
} as const;

export type IconName = keyof typeof ICONS;

export function Icon({ name, size = 16, className = "", strokeWidth = 2 }: { name: IconName; size?: number; className?: string; strokeWidth?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={strokeWidth} strokeLinecap="round" strokeLinejoin="round" className={`inline-block shrink-0 ${className}`} aria-hidden="true">
      <path d={ICONS[name]} />
    </svg>
  );
}

/* ================= базовые примитивы ================= */

const BTN: Record<string, string> = {
  primary: "bg-pine text-white hover:bg-pine-deep shadow-sm",
  amber: "bg-amber text-night hover:bg-[#d18d24] shadow-sm",
  soft: "bg-pine-soft text-pine-deep hover:bg-[#cbe6da]",
  ghost: "bg-transparent text-ink-2 hover:bg-paper-2 border border-line",
  danger: "bg-coral text-white hover:bg-[#c2431f] shadow-sm",
  night: "bg-night text-paper hover:bg-night-3",
};
const BTN_SIZE: Record<string, string> = {
  sm: "px-3 py-1.5 text-[12.5px] rounded-lg gap-1.5",
  md: "px-4 py-2.5 text-[13.5px] rounded-xl gap-2",
  lg: "px-5 py-3 text-[14.5px] rounded-xl gap-2",
};

export function Button({
  variant = "primary",
  size = "md",
  className = "",
  children,
  ...rest
}: { variant?: keyof typeof BTN; size?: keyof typeof BTN_SIZE; className?: string; children: ReactNode } & ButtonHTMLAttributes<HTMLButtonElement>) {
  return (
    <button
      className={`inline-flex cursor-pointer items-center justify-center font-bold transition-all duration-200 active:scale-[0.97] disabled:pointer-events-none disabled:opacity-45 ${BTN[variant]} ${BTN_SIZE[size]} ${className}`}
      {...rest}
    >
      {children}
    </button>
  );
}

const CHIP: Record<string, string> = {
  green: "bg-pine-soft text-pine-deep",
  amber: "bg-amber-soft text-[#8a5a10]",
  coral: "bg-coral-soft text-[#8f341a]",
  sky: "bg-sky-soft text-[#275d7e]",
  ink: "bg-paper-2 text-ink-2",
  night: "bg-night text-paper",
};

export function Chip({ tone = "ink", className = "", children }: { tone?: keyof typeof CHIP; className?: string; children: ReactNode }) {
  return (
    <span className={`inline-flex items-center gap-1 rounded-full px-2.5 py-0.5 text-[11.5px] font-bold whitespace-nowrap ${CHIP[tone]} ${className}`}>
      {children}
    </span>
  );
}

export function Modal({ open, onClose, title, children, wide = false }: { open: boolean; onClose: () => void; title: string; children: ReactNode; wide?: boolean }) {
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 grid place-items-center p-4" role="dialog" aria-modal>
      <div className="absolute inset-0 bg-night/55 backdrop-blur-[2px]" onClick={onClose} />
      <div className={`anim-pop relative max-h-[88vh] w-full overflow-y-auto rounded-2xl border border-line bg-card p-5 shadow-2xl sm:p-6 ${wide ? "max-w-2xl" : "max-w-md"}`}>
        <div className="mb-4 flex items-center justify-between gap-3">
          <h3 className="font-display text-[16px] font-bold text-ink">{title}</h3>
          <button onClick={onClose} className="grid h-8 w-8 cursor-pointer place-items-center rounded-lg text-ink-3 transition hover:bg-paper-2 hover:text-ink" aria-label="Закрыть">
            <Icon name="x" size={16} />
          </button>
        </div>
        {children}
      </div>
    </div>
  );
}

export function Avatar({ user, size = 40, className = "", mentor = false }: { user: User; size?: number; className?: string; mentor?: boolean }) {
  const { me } = useApp();
  // Настройка приватности ученика: аватар скрыт от других учеников
  // (учитель/админ и сам владелец видят его всегда).
  const hiddenFromViewer =
    user.role === "STUDENT" &&
    user.showAvatar === false &&
    (!me || (me.role === "STUDENT" && me.id !== user.id));

  if (hiddenFromViewer) {
    return (
      <span
        title="Аватар скрыт настройками приватности ученика"
        className={`relative inline-flex shrink-0 items-center justify-center rounded-full border border-dashed border-line bg-paper-2 text-ink-3 ${className}`}
        style={{ width: size, height: size }}
      >
        <Icon name="users" size={size * 0.44} />
      </span>
    );
  }

  if (user.avatarUrl) {
    return (
      <span className={`relative inline-flex shrink-0 overflow-hidden rounded-full ${mentor ? "ring-2 ring-amber ring-offset-2 ring-offset-paper" : ""} ${className}`} style={{ width: size, height: size }} title={user.displayName}>
        <img src={user.avatarUrl} alt={user.displayName} className="h-full w-full object-cover" />
      </span>
    );
  }

  return (
    <span
      className={`relative inline-flex shrink-0 items-center justify-center rounded-full font-bold select-none ${mentor ? "ring-2 ring-amber ring-offset-2 ring-offset-paper" : ""} ${className}`}
      style={{
        width: size,
        height: size,
        fontSize: size * 0.36,
        background: `linear-gradient(135deg, hsl(${user.hue} 55% 86%), hsl(${user.hue} 48% 76%))`,
        color: `hsl(${user.hue} 45% 26%)`,
      }}
      title={user.displayName}
    >
      {initials(user.displayName)}
      {mentor && (
        <span className="absolute -right-1 -top-1 grid place-items-center rounded-full bg-amber text-night" style={{ width: size * 0.42, height: size * 0.42 }}>
          <Icon name="crown" size={size * 0.26} strokeWidth={2.4} />
        </span>
      )}
    </span>
  );
}

export function Toggle({ checked, onChange, disabled = false }: { checked: boolean; onChange: (v: boolean) => void; disabled?: boolean }) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      disabled={disabled}
      onClick={() => onChange(!checked)}
      className={`relative h-6 w-11 shrink-0 cursor-pointer rounded-full transition-colors duration-200 ${checked ? "bg-pine" : "bg-line"} ${disabled ? "pointer-events-none opacity-50" : ""}`}
    >
      <span className={`absolute left-0.5 top-0.5 grid h-5 w-5 place-items-center rounded-full bg-white shadow transition-transform duration-200 ${checked ? "translate-x-5" : ""}`}>
        {checked && <Icon name="check" size={11} strokeWidth={3} className="text-pine" />}
      </span>
    </button>
  );
}

/* ================= данные: кольца, спарклайны, счётчики ================= */

export function Ring({ value, size = 96, stroke = 9, color = "var(--color-pine)", track = "#e2e8df", children }: { value: number; size?: number; stroke?: number; color?: string; track?: string; children?: ReactNode }) {
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  const off = c * (1 - Math.min(1, Math.max(0, value)));
  return (
    <span className="relative inline-grid place-items-center" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90">
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke={track} strokeWidth={stroke} />
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke={color} strokeWidth={stroke} strokeLinecap="round" strokeDasharray={c} strokeDashoffset={off} style={{ transition: "stroke-dashoffset 0.9s cubic-bezier(0.22,0.9,0.3,1)" }} />
      </svg>
      <span className="absolute inset-0 grid place-items-center">{children}</span>
    </span>
  );
}

export function Sparkline({ values, width = 120, height = 36, stroke = "var(--color-pine)" }: { values: number[]; width?: number; height?: number; stroke?: string }) {
  if (!values.length) return null;
  const max = Math.max(...values, 1);
  const pts = values.map((v, i) => `${(i / Math.max(1, values.length - 1)) * (width - 6) + 3},${height - 4 - (v / max) * (height - 8)}`).join(" ");
  return (
    <svg width={width} height={height} className="overflow-visible">
      <polyline points={pts} fill="none" stroke={stroke} strokeWidth={2.2} strokeLinecap="round" strokeLinejoin="round" />
      {values.map((v, i) => (
        <circle key={i} cx={(i / Math.max(1, values.length - 1)) * (width - 6) + 3} cy={height - 4 - (v / max) * (height - 8)} r={2.2} fill={stroke} />
      ))}
    </svg>
  );
}

export function CountUp({ value, duration = 900 }: { value: number; duration?: number }) {
  const [shown, setShown] = useState(0);
  const prev = useRef(0);
  useEffect(() => {
    const from = prev.current;
    const start = performance.now();
    let raf = 0;
    const tick = (t: number) => {
      const k = Math.min(1, (t - start) / duration);
      const e = 1 - Math.pow(1 - k, 3);
      setShown(Math.round(from + (value - from) * e));
      if (k < 1) raf = requestAnimationFrame(tick);
      else prev.current = value;
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [value, duration]);
  return <>{shown}</>;
}

/* ================= scroll reveal ================= */

export function Reveal({ children, delay = 0, className = "" }: { children: ReactNode; delay?: number; className?: string }) {
  const ref = useRef<HTMLDivElement>(null);
  const [inView, setInView] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const io = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting) {
          setInView(true);
          io.disconnect();
        }
      },
      { threshold: 0.08 },
    );
    io.observe(el);
    return () => io.disconnect();
  }, []);
  return (
    <div ref={ref} className={`reveal ${inView ? "is-in" : ""} ${className}`} style={{ transitionDelay: `${delay}ms` } as CSSProperties}>
      {children}
    </div>
  );
}

export function SectionTitle({ kicker, title, right }: { kicker?: string; title: string; right?: ReactNode }) {
  return (
    <div className="mb-4 flex flex-wrap items-end justify-between gap-2">
      <div>
        {kicker && <p className="mb-0.5 text-[11px] font-bold uppercase tracking-[0.16em] text-pine">{kicker}</p>}
        <h2 className="font-display text-[19px] font-black text-ink sm:text-[21px]">{title}</h2>
      </div>
      {right}
    </div>
  );
}

export const INPUT_CLS =
  "w-full rounded-xl border-2 border-line bg-card px-3.5 py-2.5 text-[13.5px] font-medium text-ink outline-none transition placeholder:text-ink-3/70 focus:border-pine disabled:opacity-50";
