/* ============================================================
   Модуль content · unit-тесты адаптивного ветвления
   suggestNextUnit(studentId) на разные сценарии score (QWEN.md, п.1)
   ============================================================ */
import { describe, expect, it } from "vitest";
import { suggestNextUnit, unitProgress, WINDOW } from "./suggest";
import type { Course, StudentProgress, Unit } from "../../lib/types";

const mkTask = (unitId: string, n: number, required = true) => ({
  id: `${unitId}t${n}`,
  unitId,
  type: "VOCAB" as const,
  content: { items: [] },
  order: n,
  requiredForCompletion: required,
});

const mkUnit = (id: string, order: number, cefrLevel: "A1" | "A2", taskCount = 3): Unit => ({
  id,
  courseId: "c1",
  title: `Юнит ${order}`,
  order,
  cefrLevel,
  tasks: Array.from({ length: taskCount }, (_, i) => mkTask(id, i + 1)),
});

const course: Course = {
  id: "c1",
  title: "Test Course",
  languageCode: "en",
  levelFrom: "A1",
  levelTo: "A2",
  units: [mkUnit("u1", 1, "A1"), mkUnit("u2", 2, "A1"), mkUnit("u3", 3, "A2"), mkUnit("u4", 4, "A2")],
};

const done = (taskId: string, score: number | null): StudentProgress => ({
  studentId: "st1",
  taskId,
  status: "COMPLETED",
  score,
  completedAt: Date.now(),
});

const db = (progress: StudentProgress[]) => ({ courses: [course], progress });

describe("suggestNextUnit — адаптивное ветвление (score < 60% по последним 3)", () => {
  it("ничего не пройдено → первый юнит (NEXT)", () => {
    const r = suggestNextUnit(db([]), "st1");
    expect(r?.kind).toBe("NEXT");
    if (r?.kind === "NEXT") expect(r.unit.id).toBe("u1");
  });

  it("стабильно низкие score по последним 3 заданиям юнита → REVIEW того же уровня", () => {
    // u1 пройден целиком, последние 3 задания — 40/50/55 (< 60)
    const r = suggestNextUnit(db([done("u1t1", 40), done("u1t2", 50), done("u1t3", 55)]), "st1");
    expect(r?.kind).toBe("REVIEW");
    if (r?.kind === "REVIEW") {
      expect(r.unit.cefrLevel).toBe("A1"); // upstream того же уровня
      expect(r.blockedUnit.id).toBe("u2"); // переход дальше заблокирован
      expect(r.lowScores.every((s) => s < 60)).toBe(true);
    }
  });

  it("низкие только 2 из 3 последних → без блокировки (NEXT)", () => {
    const r = suggestNextUnit(db([done("u1t1", 40), done("u1t2", 55), done("u1t3", 70)]), "st1");
    expect(r?.kind).toBe("NEXT");
  });

  it("высокие score → следующий юнит", () => {
    const r = suggestNextUnit(db([done("u1t1", 90), done("u1t2", 85), done("u1t3", 95)]), "st1");
    expect(r?.kind).toBe("NEXT");
    if (r?.kind === "NEXT") expect(r.unit.id).toBe("u2");
  });

  it("граница: ровно 60% НЕ считается низким", () => {
    const r = suggestNextUnit(db([done("u1t1", 60), done("u1t2", 59), done("u1t3", 60)]), "st1");
    expect(r?.kind).toBe("NEXT");
  });

  it("застрял внутри юнита с низкими результатами → повтор текущего юнита", () => {
    const r = suggestNextUnit(
      db([done("u1t1", 90), done("u1t2", 95), done("u1t3", 88), done("u2t1", 45), done("u2t2", 50), done("u2t3", 40)]),
      "st1",
    );
    expect(r?.kind).toBe("REVIEW");
    if (r?.kind === "REVIEW") {
      expect(r.unit.id).toBe("u2"); // повтор материала текущего юнита
      expect(r.blockedUnit.id).toBe("u2");
    }
  });

  it("низкие score в незавершённом юните, но оценок меньше 3 → NEXT", () => {
    const r = suggestNextUnit(db([done("u1t1", 90), done("u1t2", 95), done("u1t3", 88), done("u2t1", 45), done("u2t2", 50)]), "st1");
    expect(r?.kind).toBe("NEXT");
    if (r?.kind === "NEXT") expect(r.unit.id).toBe("u2");
  });

  it("незавершённые (IN_PROGRESS / без score) задания не попадают в окно", () => {
    const inProgress: StudentProgress = { studentId: "st1", taskId: "u1t3", status: "IN_PROGRESS", score: null, completedAt: null };
    const r = suggestNextUnit(db([done("u1t1", 30), done("u1t2", 35), inProgress]), "st1");
    // оценённых заданий только 2 → правило «последние 3» не срабатывает
    expect(r?.kind).toBe("NEXT");
  });

  it("весь курс завершён → COURSE_DONE", () => {
    const all = course.units.flatMap((u) => u.tasks.filter((t) => t.requiredForCompletion).map((t) => done(t.id, 90)));
    const r = suggestNextUnit(db(all), "st1");
    expect(r?.kind).toBe("COURSE_DONE");
  });

  it("юнит считается пройденным по requiredForCompletion-заданиям", () => {
    const unit = course.units[0];
    const requiredOnly = unit.tasks.filter((t) => t.requiredForCompletion).map((t) => done(t.id, 80));
    expect(unitProgress(requiredOnly, "st1", unit).complete).toBe(true);
    expect(unitProgress(requiredOnly.slice(0, 1), "st1", unit).complete).toBe(false);
  });

  it("WINDOW — последние 3 задания", () => {
    expect(WINDOW).toBe(3);
  });
});
