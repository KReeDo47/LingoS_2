import { useApp } from "../../lib/store";
import { isMentor, pointsOf, timeAgo } from "../../lib/logic";
import { getLevel, checkMentorEligibility } from "./mechanics";
import { Avatar, Button, Chip, Icon, Reveal, Ring, SectionTitle } from "../../components/ui";

type Nav = (r: string) => void;

/* ================= /student/achievements — достижения ученика ================= */
export function AchievementsPage({ navigate }: { navigate: Nav }) {
  const { db, me } = useApp();
  if (!me) return null;

  const total = pointsOf(db, me.id);
  const lvl = getLevel(total);
  const mentor = isMentor(db, me.id);
  const mentorEligible = checkMentorEligibility(db, me.id);
  
  // Получаем бейджи ученика
  const studentBadges = db.studentBadges.filter((sb) => sb.studentId === me.id);
  const earnedBadges = studentBadges.map((sb) => {
    const badge = db.badges.find((b) => b.id === sb.badgeId);
    return badge ? { ...badge, earnedAt: sb.earnedAt } : null;
  }).filter(Boolean);
  
  // История баллов
  const myLedger = db.ledger.filter((e) => e.userId === me.id).sort((a, b) => b.at - a.at);

  return (
    <div className="flex flex-col gap-6">
      {/* -------- уровень и прогресс -------- */}
      <Reveal>
        <div className="grid gap-5 rounded-xl border border-line bg-night p-6 text-paper sm:grid-cols-[auto_1fr] sm:items-center">
          <Ring value={lvl.progress} size={120} stroke={11} color="var(--color-amber)" track="#243b45">
            <span className="text-center leading-none">
              <span className="block font-display text-[28px] font-black text-amber">{lvl.level}</span>
              <span className="block text-[10px] font-semibold text-paper/50">уровень</span>
            </span>
          </Ring>
          <div>
            <div className="flex flex-wrap items-center gap-2">
              <h2 className="font-display text-2xl font-black sm:text-3xl">{lvl.icon} {lvl.name}</h2>
              {mentor && <Chip tone="amber"><Icon name="crown" size={12} /> языковой наставник</Chip>}
            </div>
            <p className="mt-1 text-[13px] text-paper/60">
              {total} баллов · {lvl.nextThreshold ? `до следующего уровня: ${lvl.nextThreshold - total}` : "максимальный уровень достигнут"}
            </p>
            <div className="mt-3 flex flex-wrap gap-2">
              <Button size="sm" variant="ghost" className="!border-night-3 !text-paper/80 hover:!bg-night-3" onClick={() => navigate("progress")}>
                <Icon name="chart" size={13} /> Рейтинги
              </Button>
              <Button size="sm" variant="ghost" className="!border-night-3 !text-paper/80 hover:!bg-night-3" onClick={() => navigate("student/courses")}>
                <Icon name="book" size={13} /> Курсы
              </Button>
            </div>
          </div>
        </div>
      </Reveal>

      {/* -------- баннер наставника -------- */}
      {mentorEligible && !mentor && (
        <Reveal>
          <div className="flex items-center gap-3 rounded-xl border-2 border-amber bg-amber-soft/50 px-5 py-4">
            <span className="grid h-12 w-12 place-items-center rounded-full bg-amber text-night">
              <Icon name="crown" size={24} />
            </span>
            <div className="flex-1">
              <p className="font-display text-[15px] font-black text-[#7a4d0d]">Тебе доступна роль наставника!</p>
              <p className="text-[12.5px] text-[#8a5a10]">Ты можешь помогать другим ученикам в тандемах ZPD_MENTOR.</p>
            </div>
          </div>
        </Reveal>
      )}

      {/* -------- бейджи -------- */}
      <section>
        <SectionTitle kicker="автоматическое начисление" title="Бейджи" right={<Chip tone="ink">{earnedBadges.length} получено</Chip>} />
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5">
          {db.badges.map((badge, i) => {
            const earned = studentBadges.some((sb) => sb.badgeId === badge.id);
            const earnedAt = studentBadges.find((sb) => sb.badgeId === badge.id)?.earnedAt;
            return (
              <Reveal key={badge.id} delay={i * 50}>
                <div className={`card-hover flex h-full flex-col items-center rounded-xl border-2 p-4 text-center transition ${earned ? "border-transparent bg-card shadow-sm" : "border-dashed border-line bg-paper-2/40"}`}>
                  <span className="grid h-12 w-12 place-items-center rounded-full text-2xl" style={{ background: earned ? "var(--color-amber-soft)" : "#e4e9e1" }}>
                    {badge.iconUrl}
                  </span>
                  <p className={`mt-2 font-display text-[12px] font-bold leading-tight ${earned ? "text-ink" : "text-ink-3"}`}>{badge.title}</p>
                  <p className="mt-1 text-[11px] leading-snug text-ink-3">{badge.description}</p>
                  {earned && earnedAt && (
                    <p className="mt-auto pt-1.5 text-[11px] font-bold text-pine">получен {timeAgo(earnedAt)}</p>
                  )}
                </div>
              </Reveal>
            );
          })}
        </div>
      </section>

      {/* -------- история баллов -------- */}
      <section>
        <SectionTitle kicker="append-only" title="История баллов" right={<Chip tone="ink"><Icon name="lock" size={11} /> неизменяем</Chip>} />
        <div className="max-h-[400px] overflow-y-auto rounded-xl border border-line bg-card">
          {myLedger.length === 0 && (
            <p className="px-4 py-8 text-center text-[13px] text-ink-3">
              Записей пока нет — пройдите первое задание!
            </p>
          )}
          {myLedger.map((e) => (
            <div key={e.id} className="flex items-center gap-3 border-b border-line/60 px-4 py-2.5 text-[13px] last:border-0">
              <span className="grid h-7 w-7 shrink-0 place-items-center rounded-full bg-pine-soft font-bold text-pine-deep">
                +{e.points}
              </span>
              <div className="min-w-0 flex-1">
                <p className="truncate font-semibold text-ink">{e.reason}</p>
                <p className="text-[11px] text-ink-3">источник: {e.sourceId}</p>
              </div>
              <span className="shrink-0 text-[11.5px] text-ink-3">{timeAgo(e.at)}</span>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
