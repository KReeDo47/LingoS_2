import { useEffect, useState } from "react";
import { useApp } from "../lib/store";
import { activeDaysStreak, groupById, isMentor, levelFromPoints, pointsOf, weekPoints } from "../lib/logic";
import { suggestNextUnit } from "../modules/content/suggest";
import { TeacherGroupDashboard } from "../modules/reflection/TeacherGroupDashboard";
import { Avatar, Button, Chip, Icon, INPUT_CLS, Reveal, Ring, SectionTitle, Toggle } from "../components/ui";
import type { IconName } from "../components/ui";
import type { FieldErrors } from "../lib/validation";

/* ================= смена временного пароля (обязательна при первом входе) ================= */
export function ChangePasswordView({ navigate }: { navigate: (r: string) => void }) {
  const { me, changePassword, toast } = useApp();
  const [pw, setPw] = useState("");
  const [pw2, setPw2] = useState("");
  const [errors, setErrors] = useState<FieldErrors>({});
  if (!me) return null;

  const submit = () => {
    const res = changePassword({ password: pw, confirm: pw2 });
    if (!res.ok) {
      setErrors(res.errors ?? {});
      return;
    }
    toast("Пароль обновлён — добро пожаловать!");
    navigate("student/dashboard");
  };

  return (
    <div className="grid min-h-screen place-items-center px-4">
      <div className="anim-fade-up w-full max-w-md rounded-2xl border border-line bg-card p-6 shadow-xl">
        <span className="grid h-12 w-12 place-items-center rounded-xl bg-amber-soft text-amber"><Icon name="key" size={22} /></span>
        <h1 className="mt-3 font-display text-xl font-black text-ink">Смените временный пароль</h1>
        <p className="mt-1.5 text-[13.5px] leading-relaxed text-ink-2">
          Учитель выдал вам временный пароль, {me.displayName}. В целях безопасности придумайте свой —
          его будете знать только вы.
        </p>
        <label className="mb-1 mt-4 block text-[12px] font-semibold text-ink-2">Новый пароль</label>
        <input type="password" className={INPUT_CLS} value={pw} onChange={(e) => setPw(e.target.value)} />
        {errors.password && <p className="mt-1 text-[12px] font-semibold text-coral">{errors.password[0]}</p>}
        <label className="mb-1 mt-3 block text-[12px] font-semibold text-ink-2">Повторите пароль</label>
        <input type="password" className={INPUT_CLS} value={pw2} onChange={(e) => setPw2(e.target.value)} />
        {errors.confirm && <p className="mt-1 text-[12px] font-semibold text-coral">{errors.confirm[0]}</p>}
        <Button size="lg" className="mt-5 w-full" onClick={submit}><Icon name="check" size={16} /> Сохранить и войти</Button>
      </div>
    </div>
  );
}

/* ================= дашборд ученика ================= */
function StudentDashboard({ navigate }: { navigate: (r: string) => void }) {
  const { db, me, setAvatarVisibility, changePassword, toast } = useApp();
  const [pwOpen, setPwOpen] = useState(false);
  const [pw, setPw] = useState("");
  const [pw2, setPw2] = useState("");
  const [errors, setErrors] = useState<FieldErrors>({});
  if (!me) return null;

  const total = pointsOf(db, me.id);
  const lvl = levelFromPoints(total);
  const week = weekPoints(db, me.id, 0);
  const streak = activeDaysStreak(db, me.id);
  const mentor = isMentor(db, me.id);
  const group = groupById(db, me.classGroupId);
  const suggestion = suggestNextUnit(db, me.id);

  const stats: { icon: IconName; label: string; value: string; tone: string }[] = [
    { icon: "trophy", label: "Баллов всего", value: String(total), tone: "text-pine" },
    { icon: "chart", label: "За 7 дней", value: `+${week}`, tone: "text-sky" },
    { icon: "clock", label: "Дней подряд", value: String(streak), tone: "text-amber" },
    { icon: "star", label: "Уровень", value: lvl.short, tone: "text-berry" },
  ];

  const submitPw = () => {
    const res = changePassword({ password: pw, confirm: pw2 });
    if (!res.ok) {
      setErrors(res.errors ?? {});
      return;
    }
    setErrors({});
    setPw("");
    setPw2("");
    setPwOpen(false);
    toast("Пароль обновлён");
  };

  return (
    <div className="flex flex-col gap-6">
      {/* -------- приветствие + следующий шаг -------- */}
      <Reveal>
        <div className="grid gap-5 rounded-xl border border-line bg-night p-6 text-paper lg:grid-cols-[auto_1fr_auto] lg:items-center">
          <Ring value={lvl.progress} size={104} stroke={10} color="var(--color-amber)" track="#243b45">
            <span className="text-center leading-none">
              <span className="block font-display text-[22px] font-black text-amber">{lvl.levelNo}</span>
              <span className="block text-[9.5px] font-semibold text-paper/50">уровень</span>
            </span>
          </Ring>
          <div>
            <p className="text-[12px] text-paper/55">{new Date().toLocaleDateString("ru-RU", { weekday: "long", day: "numeric", month: "long" })} · {group?.name}</p>
            <h2 className="mt-0.5 font-display text-[22px] font-black sm:text-2xl">Привет, {me.displayName}!</h2>
            <p className="mt-1 text-[13px] text-paper/70">
              {suggestion?.kind === "REVIEW"
                ? `Платформа советует повторить «${suggestion.unit.title}» — и тогда откроется «${suggestion.blockedUnit.title}».`
                : suggestion?.kind === "NEXT"
                  ? `Следующая остановка — юнит «${suggestion.unit.title}».`
                  : "Курс полностью пройден — загляните в сообщество!"}
            </p>
            <div className="mt-3 flex flex-wrap gap-2">
              {suggestion?.kind === "REVIEW" && (
                <Button variant="amber" size="sm" onClick={() => navigate("student/courses/c1")}><Icon name="refresh" size={13} /> Повторить юнит</Button>
              )}
              {suggestion?.kind === "NEXT" && (
                <Button variant="amber" size="sm" onClick={() => navigate("student/courses/c1")}><Icon name="arrowRight" size={13} /> Продолжить курс</Button>
              )}
              <Button variant="ghost" size="sm" className="!border-night-3 !text-paper/80 hover:!bg-night-3" onClick={() => navigate("social")}><Icon name="users" size={13} /> Сообщество</Button>
            </div>
          </div>
          <div className="flex flex-col items-start gap-1.5 lg:items-end">
            {mentor && <Chip tone="amber"><Icon name="crown" size={12} /> языковой наставник</Chip>}
            <Chip tone="night"><Icon name="shield" size={11} /> роль: {me.role}</Chip>
          </div>
        </div>
      </Reveal>

      {/* -------- показатели -------- */}
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        {stats.map((s, i) => (
          <Reveal key={s.label} delay={i * 50}>
            <div className="card-hover flex items-center gap-3.5 rounded-xl border border-line bg-card p-4">
              <span className="grid h-11 w-11 place-items-center rounded-xl bg-paper-2 text-ink-2"><Icon name={s.icon} size={19} /></span>
              <div className="leading-tight">
                <p className={`font-display text-xl font-black ${s.tone}`}>{s.value}</p>
                <p className="text-[11.5px] font-semibold text-ink-3">{s.label}</p>
              </div>
            </div>
          </Reveal>
        ))}
      </div>

      {/* -------- приватность + пароль -------- */}
      <div className="grid gap-4 lg:grid-cols-2">
        <Reveal>
          <div className="rounded-xl border border-line bg-card p-5">
            <SectionTitle kicker="настройки приватности" title="Видимость в группе" />
            <div className="flex items-center justify-between gap-3 rounded-xl border border-line bg-paper px-4 py-3">
              <div className="flex items-center gap-3">
                <Avatar user={me} size={38} />
                <div className="leading-tight">
                  <p className="text-[13.5px] font-bold text-ink">Показывать аватар другим ученикам группы</p>
                  <p className="text-[11.5px] text-ink-3">Ник виден всегда; fullName сверстникам не показывается никогда</p>
                </div>
              </div>
              <Toggle checked={me.showAvatar} onChange={(v) => { setAvatarVisibility(v); toast(v ? "Аватар снова виден группе" : "Аватар скрыт от одноклассников", "warn"); }} />
            </div>
          </div>
        </Reveal>
        <Reveal delay={70}>
          <div className="rounded-xl border border-line bg-card p-5">
            <SectionTitle kicker="безопасность" title="Пароль" />
            {!pwOpen ? (
              <Button variant="ghost" onClick={() => setPwOpen(true)}><Icon name="key" size={15} /> Сменить пароль</Button>
            ) : (
              <div>
                <input type="password" placeholder="Новый пароль" className={INPUT_CLS} value={pw} onChange={(e) => setPw(e.target.value)} />
                {errors.password && <p className="mt-1 text-[12px] font-semibold text-coral">{errors.password[0]}</p>}
                <input type="password" placeholder="Ещё раз" className={`${INPUT_CLS} mt-2`} value={pw2} onChange={(e) => setPw2(e.target.value)} />
                {errors.confirm && <p className="mt-1 text-[12px] font-semibold text-coral">{errors.confirm[0]}</p>}
                <div className="mt-3 flex gap-2">
                  <Button size="sm" onClick={submitPw}><Icon name="check" size={13} /> Сохранить</Button>
                  <Button size="sm" variant="ghost" onClick={() => setPwOpen(false)}>Отмена</Button>
                </div>
              </div>
            )}
          </div>
        </Reveal>
      </div>
    </div>
  );
}

/* ================= дашборд админа (заглушка по QWEN.md + быстрые ссылки) ================= */
function AdminDashboard({ navigate }: { navigate: (r: string) => void }) {
  const { db, me } = useApp();
  if (!me) return null;
  const students = db.users.filter((u) => u.role === "STUDENT");
  const teachers = db.users.filter((u) => u.role === "TEACHER");
  const links: { icon: IconName; label: string; route: string }[] = [
    { icon: "sliders", label: "Панель платформы", route: "admin/panel" },
    { icon: "users", label: "Ученики и согласие", route: "teacher/students" },
    { icon: "book", label: "Курсы (CRUD)", route: "teacher/courses" },
    { icon: "shield", label: "Модерация", route: "teacher/moderation" },
  ];
  return (
    <div className="flex flex-col gap-6">
      <Reveal>
        <div className="rounded-xl border border-line bg-night p-6 text-paper">
          <p className="text-[12px] text-paper/55">Панель администратора</p>
          <h2 className="mt-0.5 font-display text-2xl font-black">Здравствуйте, {me.displayName}!</h2>
          <p className="mt-1 text-[13px] text-paper/70">{students.length} учеников · {teachers.length} учителей · {db.groups.length} групп · {db.ledger.length} записей в PointsLedger</p>
        </div>
      </Reveal>
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        {links.map((l, i) => (
          <Reveal key={l.route} delay={i * 60}>
            <button onClick={() => navigate(l.route)} className="card-hover flex h-full w-full cursor-pointer flex-col items-start gap-3 rounded-xl border border-line bg-card p-5 text-left">
              <span className="grid h-11 w-11 place-items-center rounded-xl bg-pine-soft text-pine-deep"><Icon name={l.icon} size={19} /></span>
              <span className="font-display text-[14px] font-bold text-ink">{l.label}</span>
              <span className="flex items-center gap-1 text-[12px] font-bold text-pine">открыть <Icon name="arrowRight" size={12} /></span>
            </button>
          </Reveal>
        ))}
      </div>
    </div>
  );
}

/* ================= редирект /dashboard по роли из сессии ================= */
function RoleRedirect({ target, navigate }: { target: string; navigate: (r: string) => void }) {
  useEffect(() => {
    const t = window.setTimeout(() => navigate(target), 350);
    return () => window.clearTimeout(t);
  }, [target, navigate]);
  return (
    <div className="grid place-items-center py-24 text-center">
      <div className="anim-pop">
        <span className="anim-pulse-ring mx-auto grid h-14 w-14 place-items-center rounded-2xl bg-pine text-white"><Icon name="arrowRight" size={24} /></span>
        <p className="mt-4 font-display text-[15px] font-bold text-ink">Перенаправляем по вашей роли…</p>
        <p className="mt-1 text-[12.5px] text-ink-3">middleware → {target}</p>
      </div>
    </div>
  );
}

export function DashboardRouter({ route, navigate }: { route: string; navigate: (r: string) => void }) {
  const { me } = useApp();
  if (!me) return null;
  if (route === "dashboard") {
    const target = me.role === "STUDENT" ? "student/dashboard" : me.role === "TEACHER" ? "teacher/dashboard" : "admin/dashboard";
    return <RoleRedirect target={target} navigate={navigate} />;
  }
  if (route === "student/dashboard") return <StudentDashboard navigate={navigate} />;
  if (route === "admin/dashboard") return <AdminDashboard navigate={navigate} />;
  // teacher/dashboard — полный агрегат группы из модуля reflection
  return <TeacherDashboardWrapper navigate={navigate} />;
}

function TeacherDashboardWrapper({ navigate }: { navigate: (r: string) => void }) {
  const { db, me } = useApp();
  if (!me) return null;
  
  // Находим первую группу, где учитель является куратором
  const teacherGroup = db.groups.find((g) => g.teacherId === me.id);
  if (!teacherGroup) {
    return (
      <div className="py-16 text-center">
        <Icon name="alert" size={48} className="mx-auto text-ink-3" />
        <p className="mt-4 font-display text-lg font-bold text-ink">У вас нет назначенных групп</p>
        <Button className="mt-4" onClick={() => navigate("teacher/students")}>К ученикам</Button>
      </div>
    );
  }
  
  return <TeacherGroupDashboard groupId={teacherGroup.id} navigate={navigate} />;
}
