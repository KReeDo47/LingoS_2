import { useMemo } from "react";
import { useApp } from "../../lib/store";
import { DAY, isMentor, pointsOf, personalRating, teamRating, timeAgo } from "../../lib/logic";
import { getLevel, checkAndAwardBadges, checkMentorEligibility } from "./mechanics";
import { Avatar, Chip, CountUp, Icon, Reveal, Ring, SectionTitle, Sparkline } from "../../components/ui";

function last7Days(db: ReturnType<typeof useApp>["db"], userId: string): number[] {
  const days: number[] = [];
  for (let i = 6; i >= 0; i--) {
    const from = Date.now() - (i + 1) * DAY;
    const to = Date.now() - i * DAY;
    days.push(db.ledger.filter((e) => e.userId === userId && e.at > from && e.at <= to).reduce((s, e) => s + e.points, 0));
  }
  return days;
}

export function MechanicsView() {
  const { db, me } = useApp();
  if (!me) return null;
  const total = pointsOf(db, me.id);
  const lvl = getLevel(total);
  const mentor = isMentor(db, me.id);
  const mentorEligible = checkMentorEligibility(db, me.id);
  const spark = useMemo(() => last7Days(db, me.id), [db, me.id]);
  const rating = personalRating(db);
  const myPlace = rating.findIndex((r) => r.user.id === me.id) + 1;
  const teams = teamRating(db);
  const myLedger = db.ledger.filter((e) => e.userId === me.id).sort((a, b) => b.at - a.at);
  
  // Получаем бейджи ученика
  const studentBadges = db.studentBadges.filter((sb) => sb.studentId === me.id);
  const earnedBadges = studentBadges.map((sb) => db.badges.find((b) => b.id === sb.badgeId)).filter(Boolean);

  return (
    <div className="flex flex-col gap-6">
      {/* -------- профиль прогресса -------- */}
      <Reveal>
        <div className="grid gap-5 rounded-xl border border-line bg-night p-6 text-paper sm:grid-cols-[auto_1fr] sm:items-center">
          <Ring value={lvl.progress} size={118} stroke={11} color="var(--color-amber)" track="#243b45">
            <span className="text-center leading-none">
              <span className="block font-display text-[26px] font-black text-amber">{lvl.level}</span>
              <span className="block text-[10px] font-semibold text-paper/50">уровень</span>
            </span>
          </Ring>
          <div>
            <div className="flex flex-wrap items-center gap-2">
              <h2 className="font-display text-xl font-black sm:text-2xl">{lvl.icon} {lvl.name}</h2>
              {mentor && <Chip tone="amber"><Icon name="crown" size={12} /> языковой наставник</Chip>}
            </div>
            <p className="mt-1 text-[13px] text-paper/60">
              Расчётный уровень — чистая функция от суммы баллов PointsLedger. Журнал append-only: записи не изменяются.
            </p>
            <div className="mt-4 flex flex-wrap items-end gap-x-8 gap-y-3">
              <div>
                <p className="text-[10px] font-bold uppercase tracking-[0.16em] text-paper/45">Баллы всего</p>
                <p className="font-display text-3xl font-black text-white"><CountUp value={total} /></p>
              </div>
              <div>
                <p className="text-[10px] font-bold uppercase tracking-[0.16em] text-paper/45">До следующего</p>
                <p className="font-display text-xl font-bold text-amber">{lvl.nextThreshold ? lvl.nextThreshold - total : "—"}</p>
              </div>
              <div className="hidden sm:block">
                <p className="mb-1 text-[10px] font-bold uppercase tracking-[0.16em] text-paper/45">Неделя по дням</p>
                <Sparkline values={spark} width={120} height={34} stroke="var(--color-amber)" />
              </div>
            </div>
          </div>
        </div>
      </Reveal>

      {/* -------- баннер наставника -------- */}
      {mentorEligible && !mentor && (
        <Reveal>
          <div className="flex items-center gap-3 rounded-xl border-2 border-amber bg-amber-soft/50 px-5 py-4">
            <span className="grid h-12 w-12 place-items-center rounded-full bg-amber text-night">
              <Icon name="crown" size={24} />
            </span>
            <div className="flex-1">
              <p className="font-display text-[15px] font-black text-[#7a4d0d]">Тебе доступна роль наставника!</p>
              <p className="text-[12.5px] text-[#8a5a10]">Ты можешь помогать другим ученикам в тандемах ZPD_MENTOR.</p>
            </div>
          </div>
        </Reveal>
      )}

      {/* -------- два рейтинга -------- */}
      <div className="grid gap-6 lg:grid-cols-2">
        <Reveal>
          <section>
            <SectionTitle
              kicker="основной рейтинг"
              title="Личный прогресс"
              right={<Chip tone="green">сравнение со своим прошлым</Chip>}
            />
            <div className="overflow-hidden rounded-xl border border-line bg-card">
              {rating.slice(0, 8).map((r, i) => {
                const me0 = r.user.id === me.id;
                return (
                  <div key={r.user.id} className={`flex items-center gap-3 border-b border-line/60 px-4 py-2.5 transition last:border-0 ${me0 ? "bg-pine-soft/50" : "hover:bg-paper-2/50"}`}>
                    <span className={`w-6 text-center font-display text-[13px] font-black ${i === 0 ? "text-amber" : "text-ink-3"}`}>{i + 1}</span>
                    <Avatar user={r.user} size={34} mentor={isMentor(db, r.user.id)} />
                    <div className="min-w-0 flex-1 leading-tight">
                      <p className="truncate text-[13.5px] font-bold text-ink">{r.user.displayName}{me0 && <span className="ml-1.5 text-[11px] font-bold text-pine">· это вы</span>}</p>
                      <p className="text-[11.5px] text-ink-3">неделя: {r.cur} б. · прошлая: {r.prev} б.</p>
                    </div>
                    <Chip tone={r.pct > 0 ? "green" : r.pct < 0 ? "coral" : "ink"}>
                      {r.pct > 0 && <Icon name="arrowRight" size={11} className="-rotate-45" />}
                      {r.pct > 0 ? `+${r.pct}%` : `${r.pct}%`}
                    </Chip>
                  </div>
                );
              })}
            </div>
            <p className="mt-2.5 text-[12px] leading-relaxed text-ink-2">
              Здесь нет «кто умнее» — только «кто вырос сильнее относительно себя». Ваше место: <b className="text-ink">#{myPlace}</b>.
            </p>
          </section>
        </Reveal>

        <Reveal delay={90}>
          <section>
            <SectionTitle kicker="командный зачёт" title="Рейтинг групп" right={<Chip tone="sky">в среднем на участника</Chip>} />
            <div className="flex flex-col gap-3">
              {teams.map((t, i) => {
                const myTeam = me.classGroupId === t.group.id;
                const max = teams[0]?.avg || 1;
                return (
                  <div key={t.group.id} className={`card-hover rounded-xl border-2 bg-card p-4 ${myTeam ? "border-pine" : "border-line"}`}>
                    <div className="flex items-center gap-3">
                      <span className={`grid h-10 w-10 place-items-center rounded-xl font-display text-[15px] font-black ${i === 0 ? "bg-amber text-night" : "bg-paper-2 text-ink-2"}`}>{i + 1}</span>
                      <div className="flex-1 leading-tight">
                        <p className="font-display text-[15px] font-bold text-ink">{t.group.name} {myTeam && <span className="text-[11px] font-bold text-pine">· ваша команда</span>}</p>
                        <p className="text-[12px] text-ink-3">{t.members} учеников · {t.week} б. за неделю</p>
                      </div>
                      <p className="font-display text-xl font-black text-ink">{t.avg}</p>
                    </div>
                    <div className="mt-2.5 h-2 overflow-hidden rounded-full bg-paper-2">
                      <div className="anim-bar h-full rounded-full bg-pine" style={{ width: `${Math.max(8, (t.avg / max) * 100)}%` }} />
                    </div>
                  </div>
                );
              })}
            </div>
            <p className="mt-2.5 text-[12px] leading-relaxed text-ink-2">
              Единого публичного топа по классу нет намеренно: он демотивирует слабых учеников.
              Командный зачёт делает вклад каждого заметным — очки наставника работают на группу.
            </p>
          </section>
        </Reveal>
      </div>

      {/* -------- бейджи -------- */}
      <section>
        <SectionTitle kicker="автоматическое начисление" title="Бейджи" right={<Chip tone="ink">{earnedBadges.length} получено</Chip>} />
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5">
          {db.badges.map((badge, i) => {
            const earned = studentBadges.some((sb) => sb.badgeId === badge.id);
            const earnedAt = studentBadges.find((sb) => sb.badgeId === badge.id)?.earnedAt;
            return (
              <Reveal key={badge.id} delay={i * 50}>
                <div className={`card-hover flex h-full flex-col items-center rounded-xl border-2 p-4 text-center transition ${earned ? "border-transparent bg-card shadow-sm" : "border-dashed border-line bg-paper-2/40"}`}>
                  <span className="grid h-12 w-12 place-items-center rounded-full text-2xl" style={{ background: earned ? "var(--color-amber-soft)" : "#e4e9e1" }}>
                    {badge.iconUrl}
                  </span>
                  <p className={`mt-2 font-display text-[12px] font-bold leading-tight ${earned ? "text-ink" : "text-ink-3"}`}>{badge.title}</p>
                  <p className="mt-1 text-[11px] leading-snug text-ink-3">{badge.description}</p>
                  {earned && earnedAt && (
                    <p className="mt-auto pt-1.5 text-[11px] font-bold text-pine">получен {timeAgo(earnedAt)}</p>
                  )}
                </div>
              </Reveal>
            );
          })}
        </div>
      </section>

      {/* -------- наставник + журнал -------- */}
      <div className="grid gap-6 lg:grid-cols-[320px_1fr]">
        <Reveal>
          <div className={`rounded-xl border-2 p-5 ${mentor ? "border-amber bg-amber-soft/50" : "border-line bg-card"}`}>
            <p className="flex items-center gap-2 font-display text-[15px] font-bold text-ink"><Icon name="crown" size={18} className="text-amber" /> Языковой наставник</p>
            <p className="mt-2 text-[13px] leading-relaxed text-ink-2">
              Статусная роль за устойчивый прогресс: минимум 500 баллов, 20 заданий, 10 peer-review.
              Наставник ведёт партнёра тандема — и это видно всей группе.
            </p>
            {mentor ? (
              <Chip tone="amber" className="mt-3"><Icon name="check" size={12} /> роль активна</Chip>
            ) : (
              <p className="mt-3 text-[12px] font-bold text-ink-3">
                {mentorEligible ? "Критерии выполнены — роль доступна!" : "До роли: нужно больше баллов и активности."}
              </p>
            )}
          </div>
        </Reveal>

        <Reveal delay={80}>
          <div>
            <SectionTitle kicker="append-only" title="Журнал баллов" right={<Chip tone="ink"><Icon name="lock" size={11} /> неизменяем</Chip>} />
            <div className="max-h-[340px] overflow-y-auto rounded-xl border border-line bg-card">
              {myLedger.length === 0 && <p className="px-4 py-6 text-center text-[13px] text-ink-3">Записей пока нет — пройдите первое задание!</p>}
              {myLedger.map((e) => (
                <div key={e.id} className="flex items-center gap-3 border-b border-line/60 px-4 py-2.5 text-[13px] last:border-0">
                  <span className="grid h-7 w-7 shrink-0 place-items-center rounded-full bg-pine-soft font-bold text-pine-deep">+{e.points}</span>
                  <p className="min-w-0 flex-1 truncate font-semibold text-ink">{e.reason}</p>
                  <span className="shrink-0 text-[11.5px] text-ink-3">{timeAgo(e.at)}</span>
                </div>
              ))}
            </div>
          </div>
        </Reveal>
      </div>
    </div>
  );
}
