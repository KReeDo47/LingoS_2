import { createContext, useCallback, useContext, useEffect, useState } from "react";
import type { ReactNode } from "react";
import { buildSeed } from "./seed";
import {
  canWriteReflection,
  checkBannedWords,
  createContentFlag,
  createSafetyLogEntry,
  DAY,
  now,
  sameDay,
  suggestTandems,
  uid,
} from "./logic";
import { findTask, TASK_TYPE_META } from "../modules/content/suggest";
import { postGroupMessage, syncApiSnapshot } from "../modules/social/chatApi";
import {
  changePasswordSchema,
  courseSchema,
  createStudentSchema,
  generateTempPassword,
  hashPassword,
  parseWith,
  registerSchema,
} from "./validation";
import type { FieldErrors } from "./validation";
import type {
  BannedWord,
  BannedWordSeverity,
  ClassGroup,
  ContentFlag,
  ContentType,
  Course,
  DB,
  DiaryPromptType,
  FlagStatus,
  GroupQuest,
  LedgerReason,
  PairedReason,
  ReflectionType,
  RubricScore,
  SafetyActionType,
  StudentProgress,
  User,
} from "./types";

const LS_KEY = "linguasocial-db-v6";

function loadDB(): DB {
  try {
    const raw = localStorage.getItem(LS_KEY);
    if (raw) {
      const parsed = JSON.parse(raw) as DB;
      // Проверяем наличие всех необходимых полей для v6
      if (
        parsed.version === 6 &&
        Array.isArray(parsed.badges) &&
        Array.isArray(parsed.studentBadges) &&
        Array.isArray(parsed.challenges) &&
        Array.isArray(parsed.challengeResults) &&
        Array.isArray(parsed.mentorRoles) &&
        Array.isArray(parsed.diaryEntries) &&
        Array.isArray(parsed.selfAssessmentChecklists) &&
        Array.isArray(parsed.selfAssessmentResponses) &&
        Array.isArray(parsed.feedbackNotes) &&
        Array.isArray(parsed.contentFlags) &&
        Array.isArray(parsed.bannedWords)
      ) {
        return parsed;
      }
    }
  } catch {
    /* повреждённое хранилище — пересеваем */
  }
  return buildSeed();
}

export interface Toast {
  id: string;
  text: string;
  tone: "ok" | "warn" | "err";
}

type AuthResult =
  | { ok: true; user: User; error?: undefined; errors?: undefined }
  | { ok: false; user?: undefined; error?: string; errors?: FieldErrors };
type AddStudentResult =
  | { ok: true; user: User; tempPassword: string; error?: undefined; errors?: undefined }
  | { ok: false; user?: undefined; tempPassword?: undefined; error?: string; errors?: FieldErrors };

interface AppCtx {
  db: DB;
  me: User | null;
  toasts: Toast[];
  toast: (text: string, tone?: Toast["tone"]) => void;
  /* ---- users (модуль 1) ---- */
  login: (email: string, password: string) => AuthResult;
  logout: () => void;
  register: (input: unknown) => AuthResult;
  addStudent: (input: unknown) => AddStudentResult;
  changePassword: (input: unknown) => { ok: boolean; errors?: FieldErrors };
  setAvatarVisibility: (show: boolean) => void;
  /* ---- content (модуль 2) ---- */
  startTask: (taskId: string) => void;
  completeTask: (taskId: string, score: number | null) => void;
  saveCourse: (course: Course) => { ok: boolean; errors?: FieldErrors };
  deleteCourse: (courseId: string) => void;
  /* ---- social (модуль 3) ---- */
  createTandem: (studentAId: string, studentBId: string, pairedReason: PairedReason) => { ok: boolean; error?: string };
  autoPairTandems: (classGroupId: string) => number;
  createQuest: (classGroupId: string, title: string, description: string, deadlineDays: number) => void;
  assignQuestRole: (questId: string, roleName: string, studentId: string | null) => void;
  completeRole: (questId: string, roleName: string) => void;
  createDoc: (title: string, groupQuestId?: string, tandemId?: string) => string;
  saveDocRevision: (docId: string, content: string, note?: string) => void;
  submitForReview: (title: string, content: string, taskId?: string | null) => { ok: boolean; hits: string[] };
  giveReview: (taskSubmissionId: string, rubricScores: RubricScore[], comment: string) => { ok: boolean; hits: string[] };
  sendMessage: (classGroupId: string, text: string) => { hidden: boolean; hits: string[]; error?: string };
  peerReply: (classGroupId: string, excludeId?: string) => void;
  /* ---- moderation ---- */
  moderate: (queueId: string, decision: "approved" | "removed") => void;
  reviewFlag: (flagId: string, status: FlagStatus) => void;
  addBannedWord: (word: string, severity: BannedWordSeverity) => void;
  removeBannedWord: (wordId: string) => void;
  /* ---- reflection ---- */
  writeReflection: (type: ReflectionType, text: string) => { ok: boolean };
  setChecklist: (itemId: string, value: number) => void;
  addDiaryEntry: (promptType: DiaryPromptType, content: string) => void;
  submitSelfAssessment: (checklistId: string, responses: { itemIndex: number; checked: boolean }[]) => void;
  addFeedbackNote: (taskSubmissionId: string, whatWentWell: string, whatToImprove: string) => void;
  toggleDiaryVisibility: (groupId: string) => void;
  /* ---- admin ---- */
  addStopword: (word: string) => void;
  removeStopword: (word: string) => void;
  resetDemo: () => void;
}

const Ctx = createContext<AppCtx | null>(null);

const CANNED_REPLIES = [
  "Good idea! Let's do it 💪",
  "Кто потренирует со мной в тандеме сегодня?",
  "Nice! За такое и баллы не жалко 😄",
  "А можно после уроков созвониться на 10 минут?",
  "I agree! Записываю в наш план квеста.",
  "Спасибо! Now everything is clear ✨",
];

function upsertProgress(list: StudentProgress[], rec: StudentProgress): StudentProgress[] {
  return list.some((r) => r.studentId === rec.studentId && r.taskId === rec.taskId)
    ? list.map((r) => (r.studentId === rec.studentId && r.taskId === rec.taskId ? rec : r))
    : [...list, rec];
}

export function AppProvider({ children }: { children: ReactNode }) {
  const [db, setDb] = useState<DB>(loadDB);
  const [toasts, setToasts] = useState<Toast[]>([]);

  useEffect(() => {
    try {
      localStorage.setItem(LS_KEY, JSON.stringify(db));
    } catch {
      /* квота — игнорируем */
    }
    syncApiSnapshot(db);
  }, [db]);

  const toast = useCallback((text: string, tone: Toast["tone"] = "ok") => {
    const id = uid("t");
    setToasts((ts) => [...ts, { id, text, tone }]);
    window.setTimeout(() => setToasts((ts) => ts.filter((t) => t.id !== id)), 3800);
  }, []);

  const me = db.users.find((u) => u.id === db.sessionId) ?? null;
  const meId = me?.id ?? "system";

  const touch = (list: User[], userId: string): User[] =>
    list.map((u) => (u.id === userId ? { ...u, lastActiveAt: now() } : u));

  /* ================= users (модуль 1) ================= */

  const login = useCallback(
    (email: string, password: string): AuthResult => {
      const user = db.users.find((u) => u.email.toLowerCase() === email.trim().toLowerCase());
      if (!user || user.passwordHash !== hashPassword(password)) {
        return { ok: false, error: "Неверный email или пароль" };
      }
      setDb((p) => ({ ...p, sessionId: user.id, users: touch(p.users, user.id) }));
      return { ok: true, user };
    },
    [db.users],
  );

  const logout = useCallback(() => setDb((p) => ({ ...p, sessionId: null })), []);

  const register = useCallback(
    (input: unknown): AuthResult => {
      const res = parseWith(registerSchema, input);
      if (!res.ok) return { ok: false, errors: res.errors };
      const data = res.data as {
        fullName: string;
        displayName: string;
        email: string;
        password: string;
        role: "TEACHER" | "ADMIN";
        groupName?: string;
        organizationName?: string;
      };
      if (db.users.some((u) => u.email.toLowerCase() === data.email)) {
        return { ok: false, error: "Этот email уже зарегистрирован" };
      }
      if (db.users.some((u) => u.displayName.toLowerCase() === data.displayName.toLowerCase())) {
        return { ok: false, errors: { displayName: ["displayName уже занят — сверстники видят только его"] } };
      }
      const nu: User = {
        id: uid("u"),
        role: data.role,
        email: data.email,
        passwordHash: hashPassword(data.password),
        fullName: data.fullName,
        displayName: data.displayName,
        showAvatar: true,
        mustChangePassword: false,
        hue: Math.floor(Math.random() * 360),
        classGroupId: null,
        cefr: "B2",
        lastActiveAt: now(),
        createdAt: now(),
      };
      let group: ClassGroup | null = null;
      if (data.role === "TEACHER" && data.groupName) {
        group = {
          id: uid("g"),
          name: data.groupName,
          teacherId: nu.id,
          organizationName: data.organizationName || "—",
          diaryVisibleToTeacher: false,
        };
      }
      setDb((p) => ({
        ...p,
        users: [...p.users, nu],
        groups: group ? [...p.groups, group] : p.groups,
        sessionId: nu.id,
      }));
      return { ok: true, user: nu };
    },
    [db.users],
  );

  const addStudent = useCallback(
    (input: unknown): AddStudentResult => {
      const res = parseWith(createStudentSchema, input);
      if (!res.ok) return { ok: false, errors: res.errors };
      const data = res.data as {
        fullName: string;
        displayName: string;
        email: string;
        classGroupId: string;
        cefr: User["cefr"];
        consentGivenBy: string;
      };
      if (db.users.some((u) => u.email.toLowerCase() === data.email.toLowerCase())) {
        return { ok: false, error: "Этот email уже зарегистрирован" };
      }
      if (db.users.some((u) => u.displayName.toLowerCase() === data.displayName.toLowerCase())) {
        return { ok: false, errors: { displayName: ["displayName уже занят — сверстники видят только его"] } };
      }
      const tempPassword = generateTempPassword();
      const nu: User = {
        id: uid("s"),
        role: "STUDENT",
        email: data.email,
        passwordHash: hashPassword(tempPassword),
        fullName: data.fullName,
        displayName: data.displayName,
        showAvatar: true,
        mustChangePassword: true,
        hue: Math.floor(Math.random() * 360),
        classGroupId: data.classGroupId,
        cefr: data.cefr,
        lastActiveAt: now(),
        createdAt: now(),
      };
      setDb((p) => ({
        ...p,
        users: [...p.users, nu],
        consents: [...p.consents, { userId: nu.id, consentGivenBy: data.consentGivenBy, consentDate: now() }],
        safetyLog: [
          ...p.safetyLog,
          createSafetyLogEntry(
            meId,
            "CONTENT_FLAGGED",
            "USER",
            nu.id,
            "Создан аккаунт ученика; согласие законного представителя: " + data.consentGivenBy,
          ),
        ],
      }));
      return { ok: true, user: nu, tempPassword };
    },
    [db.users, meId],
  );

  const changePassword = useCallback(
    (input: unknown): { ok: boolean; errors?: FieldErrors } => {
      const res = parseWith(changePasswordSchema, input);
      if (!res.ok) return { ok: false, errors: res.errors };
      const { password } = res.data as { password: string };
      setDb((p) => ({
        ...p,
        users: p.users.map((u) => (u.id === meId ? { ...u, passwordHash: hashPassword(password), mustChangePassword: false } : u)),
        safetyLog: [
          ...p.safetyLog,
          createSafetyLogEntry(meId, "CONTENT_FLAGGED", "USER", meId, "Пароль изменён (смена временного пароля)"),
        ],
      }));
      return { ok: true };
    },
    [meId],
  );

  const setAvatarVisibility = useCallback(
    (show: boolean) => {
      setDb((p) => ({ ...p, users: p.users.map((u) => (u.id === meId ? { ...u, showAvatar: show } : u)) }));
    },
    [meId],
  );

  /* ================= content (модуль 2) ================= */

  const startTask = useCallback(
    (taskId: string) => {
      setDb((p) => ({
        ...p,
        progress: upsertProgress(p.progress, { studentId: meId, taskId, status: "IN_PROGRESS", score: null, completedAt: null }),
      }));
    },
    [meId],
  );

  const completeTask = useCallback(
    (taskId: string, score: number | null) => {
      setDb((p) => {
        const prev = p.progress.find((r) => r.studentId === meId && r.taskId === taskId);
        const best = prev?.score != null && score != null ? Math.max(prev.score, score) : score ?? prev?.score ?? null;
        return {
          ...p,
          users: touch(p.users, meId),
          progress: upsertProgress(p.progress, { studentId: meId, taskId, status: "COMPLETED", score: best, completedAt: now() }),
        };
      });

      void findTask(db, taskId);
    },
    [db, meId],
  );

  const saveCourse = useCallback(
    (course: Course): { ok: boolean; errors?: FieldErrors } => {
      const res = parseWith(courseSchema, course);
      if (!res.ok) return { ok: false, errors: res.errors };
      const data = res.data as unknown as Course;
      setDb((p) => {
        const exists = p.courses.some((c) => c.id === data.id);
        return {
          ...p,
          courses: exists ? p.courses.map((c) => (c.id === data.id ? data : c)) : [...p.courses, data],
          safetyLog: [
            ...p.safetyLog,
            createSafetyLogEntry(
              meId,
              "CONTENT_FLAGGED",
              "COURSE",
              data.id,
              exists ? "Курс обновлён учителем/админом" : "Создан новый курс",
            ),
          ],
        };
      });
      return { ok: true };
    },
    [meId],
  );

  const deleteCourse = useCallback(
    (courseId: string) => {
      setDb((p) => {
        const course = p.courses.find((c) => c.id === courseId);
        const taskIds = new Set(course?.units.flatMap((u) => u.tasks.map((t) => t.id)) ?? []);
        return {
          ...p,
          courses: p.courses.filter((c) => c.id !== courseId),
          progress: p.progress.filter((pr) => !taskIds.has(pr.taskId)),
          safetyLog: [
            ...p.safetyLog,
            createSafetyLogEntry(meId, "CONTENT_FLAGGED", "COURSE", courseId, "Курс удалён учителем/админом"),
          ],
        };
      });
    },
    [meId],
  );

  /* ================= social (модуль 3) ================= */

  const createTandem = useCallback(
    (studentAId: string, studentBId: string, pairedReason: PairedReason): { ok: boolean; error?: string } => {
      if (studentAId === studentBId) return { ok: false, error: "Выберите двух разных учеников" };
      const a = db.users.find((u) => u.id === studentAId);
      const b = db.users.find((u) => u.id === studentBId);
      if (!a || !b) return { ok: false, error: "Ученик не найден" };
      if (a.classGroupId !== b.classGroupId || !a.classGroupId) return { ok: false, error: "Оба ученика должны быть в одной учебной группе" };
      const dup = db.tandems.some(
        (t) =>
          t.active &&
          t.classGroupId === a.classGroupId &&
          ((t.studentAId === studentAId && t.studentBId === studentBId) ||
            (t.studentAId === studentBId && t.studentBId === studentAId)),
      );
      if (dup) return { ok: false, error: "Эта пара уже активна" };
      setDb((p) => ({
        ...p,
        tandems: [
          ...p.tandems,
          { id: uid("t"), studentAId, studentBId, classGroupId: a.classGroupId as string, pairedReason, createdAt: now(), active: true },
        ],
        safetyLog: [
          ...p.safetyLog,
          createSafetyLogEntry(meId, "CONTENT_FLAGGED", "TANDEM", studentAId + "+" + studentBId, "Тандем создан вручную (" + pairedReason + ")"),
        ],
      }));
      return { ok: true };
    },
    [db.users, db.tandems, meId],
  );

  const autoPairTandems = useCallback(
    (classGroupId: string): number => {
      const pairs = suggestTandems(db, classGroupId);
      if (!pairs.length) return 0;
      setDb((p) => {
        const gname = p.groups.find((g) => g.id === classGroupId)?.name ?? classGroupId;
        return {
          ...p,
          tandems: [
            ...p.tandems.map((t) => (t.classGroupId === classGroupId ? { ...t, active: false } : t)),
            ...pairs.map((pr) => ({
              id: uid("t"),
              studentAId: pr.a.id,
              studentBId: pr.b.id,
              classGroupId,
              pairedReason: pr.pairedReason,
              createdAt: now(),
              active: true,
            })),
          ],
          safetyLog: [
            ...p.safetyLog,
            createSafetyLogEntry(
              meId,
              "CONTENT_FLAGGED",
              "TANDEM",
              classGroupId,
              "Автоподбор " + pairs.length + " пар «сильный + слабый» по среднему score (ZPD)",
            ),
          ],
        };
      });
      return pairs.length;
    },
    [db, meId],
  );

  const createQuest = useCallback((classGroupId: string, title: string, description: string, deadlineDays: number) => {
    setDb((p) => ({
      ...p,
      quests: [
        ...p.quests,
        {
          id: uid("q"),
          classGroupId,
          title: title.trim(),
          description: description.trim() || "Групповое задание: распределите роли и выполните квест вместе.",
          roles: ["Ведущий", "Исследователь", "Спикер", "Оформитель"].map((name) => ({ name, assignedTo: null, done: false })),
          deadline: now() + Math.max(1, deadlineDays) * DAY,
          bonus: 25,
          status: "active" as const,
          contributions: [],
        },
      ],
    }));
  }, []);

  const assignQuestRole = useCallback((questId: string, roleName: string, studentId: string | null) => {
    setDb((p) => ({
      ...p,
      quests: p.quests.map((q) =>
        q.id === questId ? { ...q, roles: q.roles.map((r) => (r.name === roleName ? { ...r, assignedTo: studentId } : r)) } : q,
      ),
    }));
  }, []);

  const completeRole = useCallback(
    (questId: string, roleName: string) => {
      setDb((p) => {
        const quest = p.quests.find((q) => q.id === questId) as GroupQuest | undefined;
        if (!quest) return p;
        const roles = quest.roles.map((r) => (r.name === roleName ? { ...r, done: true } : r));
        const allDone = roles.every((r) => r.done);
        const contributions = [...new Set([...quest.contributions, meId])];
        const bonusLedger = allDone
          ? contributions.flatMap((uidv) => [
              { id: uid("l"), userId: uidv, points: quest.bonus, reason: "QUEST_COMPLETED" as LedgerReason, sourceId: quest.id, at: now() },
            ])
          : [];
        return {
          ...p,
          users: touch(p.users, meId),
          quests: p.quests.map((q) => (q.id === questId ? { ...q, roles, status: allDone ? ("done" as const) : q.status, contributions } : q)),
          ledger: [
            ...p.ledger,
            { id: uid("l"), userId: meId, points: 10, reason: "QUEST_COMPLETED" as LedgerReason, sourceId: quest.id, at: now() },
            ...bonusLedger,
          ],
        };
      });
    },
    [meId],
  );

  const createDoc = useCallback(
    (title: string, groupQuestId?: string, tandemId?: string): string => {
      const gid = me?.classGroupId;
      const id = uid("doc");
      if (gid) {
        setDb((p) => ({
          ...p,
          docs: [...p.docs, { id, classGroupId: gid, groupQuestId, tandemId, title: title.trim(), content: "", updatedAt: now() }],
        }));
      }
      return id;
    },
    [me?.classGroupId],
  );

  const saveDocRevision = useCallback(
    (docId: string, content: string, note?: string) => {
      if (!content.trim()) return;
      setDb((p) => {
        const doc = p.docs.find((d0) => d0.id === docId);
        if (!doc) return p;
        return {
          ...p,
          users: touch(p.users, meId),
          docs: p.docs.map((d0) => (d0.id === docId ? { ...d0, content: content.trim(), updatedAt: now() } : d0)),
          docRevisions: [...p.docRevisions, { id: uid("dr"), docId, authorId: meId, contentSnapshot: content.trim(), createdAt: now() }],
          ledger: [
            ...p.ledger,
            { id: uid("l"), userId: meId, points: 3, reason: "TASK_COMPLETED" as LedgerReason, sourceId: doc.id, at: now() },
          ],
        };
      });
    },
    [meId],
  );

  const submitForReview = useCallback(
    (title: string, content: string, taskId?: string | null) => {
      const violations = checkBannedWords(title + " " + content, db.bannedWords);
      if (violations.length > 0) {
        const hitsText = violations.map((v) => "«" + v.word + "»").join(", ");
        setDb((p) => ({
          ...p,
          safetyLog: [
            ...p.safetyLog,
            createSafetyLogEntry("AUTO", "CONTENT_FLAGGED", "SUBMISSION", title, "Запрещённые слова: " + hitsText),
          ],
        }));
        return { ok: false, hits: violations.map((v) => v.word) };
      }
      setDb((p) => ({
        ...p,
        users: touch(p.users, meId),
        submissions: [
          { id: uid("sub"), taskId: taskId ?? null, studentId: meId, title: title.trim(), content: content.trim(), at: now() },
          ...p.submissions,
        ],
        ledger: [...p.ledger, { id: uid("l"), userId: meId, points: 5, reason: "TASK_COMPLETED" as LedgerReason, sourceId: uid("sub"), at: now() }],
      }));
      return { ok: true, hits: [] };
    },
    [db.bannedWords, meId],
  );

  const giveReview = useCallback(
    (taskSubmissionId: string, rubricScores: RubricScore[], comment: string) => {
      const violations = checkBannedWords(comment, db.bannedWords);
      if (violations.length > 0) {
        const hitsText = violations.map((v) => "«" + v.word + "»").join(", ");
        setDb((p) => ({
          ...p,
          safetyLog: [
            ...p.safetyLog,
            createSafetyLogEntry("AUTO", "CONTENT_FLAGGED", "REVIEW", taskSubmissionId, "Запрещённые слова: " + hitsText),
          ],
        }));
        return { ok: false, hits: violations.map((v) => v.word) };
      }
      setDb((p) => ({
        ...p,
        users: touch(p.users, meId),
        peerReviews: [
          ...p.peerReviews,
          { id: uid("pr"), taskSubmissionId, reviewerId: meId, rubricScores, comment: comment.trim(), createdAt: now() },
        ],
        ledger: [...p.ledger, { id: uid("l"), userId: meId, points: 5, reason: "PEER_REVIEW_GIVEN" as LedgerReason, sourceId: taskSubmissionId, at: now() }],
      }));
      return { ok: true, hits: [] };
    },
    [db.bannedWords, meId],
  );

  const sendMessage = useCallback(
    (classGroupId: string, text: string): { hidden: boolean; hits: string[]; error?: string } => {
      if (!text.trim()) return { hidden: false, hits: [] };
      const guard = postGroupMessage(db, classGroupId, meId);
      if (!guard.ok) return { hidden: false, hits: [], error: guard.error };
      
      const violations = checkBannedWords(text, db.bannedWords);
      const autoHideViolations = violations.filter((v) => v.severity === "AUTO_HIDE");
      const warnViolations = violations.filter((v) => v.severity === "WARN");
      
      const msgId = uid("m");
      const shouldHide = autoHideViolations.length > 0;
      const hideReason = shouldHide
        ? "Запрещённые слова (AUTO_HIDE): " + autoHideViolations.map((v) => "«" + v.word + "»").join(", ")
        : null;

      setDb((p) => {
        const newFlags: ContentFlag[] = [];
        const newLogEntries = [];

        if (shouldHide) {
          newFlags.push(
            createContentFlag(
              "MESSAGE",
              msgId,
              "AUTO",
              "Запрещённые слова (AUTO_HIDE): " + autoHideViolations.map((v) => "«" + v.word + "»").join(", "),
            ),
          );
          newLogEntries.push(
            createSafetyLogEntry(
              "AUTO",
              "MESSAGE_HIDDEN",
              "MESSAGE",
              msgId,
              "Автоматическое скрытие: " + autoHideViolations.map((v) => "«" + v.word + "»").join(", "),
            ),
          );
        }

        if (warnViolations.length > 0) {
          newFlags.push(
            createContentFlag(
              "MESSAGE",
              msgId,
              "AUTO",
              "Запрещённые слова (WARN): " + warnViolations.map((v) => "«" + v.word + "»").join(", "),
            ),
          );
          newLogEntries.push(
            createSafetyLogEntry(
              "AUTO",
              "CONTENT_FLAGGED",
              "MESSAGE",
              msgId,
              "Предупреждение: " + warnViolations.map((v) => "«" + v.word + "»").join(", "),
            ),
          );
        }

        return {
          ...p,
          users: touch(p.users, meId),
          messages: [
            ...p.messages,
            {
              id: msgId,
              classGroupId,
              authorId: meId,
              content: text.trim(),
              createdAt: now(),
              hidden: shouldHide,
              hiddenReason: hideReason,
            },
          ],
          contentFlags: [...p.contentFlags, ...newFlags],
          safetyLog: [...p.safetyLog, ...newLogEntries],
        };
      });

      return { hidden: shouldHide, hits: violations.map((v) => v.word) };
    },
    [db, meId],
  );

  const peerReply = useCallback(
    (classGroupId: string, excludeId?: string) => {
      const guard = postGroupMessage(db, classGroupId, meId);
      if (!guard.ok) return;
      const peers = db.users.filter((u) => u.role === "STUDENT" && u.classGroupId === classGroupId && u.id !== (excludeId ?? meId));
      if (!peers.length) return;
      const author = peers[Math.floor(Math.random() * peers.length)];
      const text = CANNED_REPLIES[Math.floor(Math.random() * CANNED_REPLIES.length)];
      setDb((p) => ({
        ...p,
        users: touch(p.users, author.id),
        messages: [
          ...p.messages,
          { id: uid("m"), classGroupId, authorId: author.id, content: text, createdAt: now(), hidden: false, hiddenReason: null },
        ],
      }));
    },
    [db, meId],
  );

  /* ================= moderation ================= */

  const moderate = useCallback(
    (queueId: string, decision: "approved" | "removed") => {
      setDb((p) => {
        const item = p.queue.find((q) => q.id === queueId);
        if (!item) return p;
        const msg = p.messages.find((m) => m.id === item.messageId);
        return {
          ...p,
          queue: p.queue.map((q) => (q.id === queueId ? { ...q, status: decision } : q)),
          messages: decision === "approved" ? p.messages.map((m) => (m.id === item.messageId ? { ...m, hidden: false, hiddenReason: null } : m)) : p.messages,
          safetyLog: [
            ...p.safetyLog,
            createSafetyLogEntry(
              meId,
              decision === "approved" ? "CONTENT_FLAGGED" : "MESSAGE_DELETED",
              "MESSAGE",
              msg ? msg.id : item.messageId,
              decision === "approved" ? "Модератор одобрил скрытое сообщение" : "Сообщение удалено модератором (скрыто навсегда)",
            ),
          ],
        };
      });
    },
    [meId],
  );

  const reviewFlag = useCallback(
    (flagId: string, status: FlagStatus) => {
      setDb((p) => ({
        ...p,
        contentFlags: p.contentFlags.map((f) =>
          f.id === flagId ? { ...f, status, reviewedBy: meId, reviewedAt: now() } : f,
        ),
        safetyLog: [
          ...p.safetyLog,
          createSafetyLogEntry(
            meId,
            status === "REVIEWED_OK" ? "CONTENT_FLAGGED" : "MESSAGE_DELETED",
            p.contentFlags.find((f) => f.id === flagId)?.contentType ?? "UNKNOWN",
            flagId,
            status === "REVIEWED_OK" ? "Флаг проверен и одобрен" : "Флаг проверен и контент удалён",
          ),
        ],
      }));
    },
    [meId],
  );

  const addBannedWord = useCallback(
    (word: string, severity: BannedWordSeverity) => {
      const w = word.trim().toLowerCase();
      if (!w) return;
      setDb((p) => {
        if (p.bannedWords.some((bw) => bw.word === w)) return p;
        return {
          ...p,
          bannedWords: [...p.bannedWords, { id: uid("bw"), word: w, severity }],
          safetyLog: [
            ...p.safetyLog,
            createSafetyLogEntry(meId, "CONTENT_FLAGGED", "BANNED_WORD", w, "Добавлено запрещённое слово: «" + w + "» (" + severity + ")"),
          ],
        };
      });
    },
    [meId],
  );

  const removeBannedWord = useCallback(
    (wordId: string) => {
      setDb((p) => {
        const word = p.bannedWords.find((bw) => bw.id === wordId);
        if (!word) return p;
        return {
          ...p,
          bannedWords: p.bannedWords.filter((bw) => bw.id !== wordId),
          safetyLog: [
            ...p.safetyLog,
            createSafetyLogEntry(meId, "CONTENT_FLAGGED", "BANNED_WORD", word.word, "Удалено запрещённое слово: «" + word.word + "»"),
          ],
        };
      });
    },
    [meId],
  );

  /* ================= reflection ================= */

  const writeReflection = useCallback(
    (type: ReflectionType, text: string) => {
      if (!canWriteReflection(db, meId, type)) return { ok: false };
      setDb((p) => ({
        ...p,
        users: touch(p.users, meId),
        reflections: [...p.reflections, { id: uid("rf"), userId: meId, type, text: text.trim(), at: now() }],
        ledger: [...p.ledger, { id: uid("l"), userId: meId, points: 5, reason: "TASK_COMPLETED" as LedgerReason, sourceId: uid("rf"), at: now() }],
      }));
      return { ok: true };
    },
    [db, meId],
  );

  const setChecklist = useCallback(
    (itemId: string, value: number) => {
      setDb((p) => {
        const existing = p.checklists.find((c) => c.userId === meId);
        const items = { ...(existing?.items ?? {}), [itemId]: value };
        return {
          ...p,
          checklists: existing
            ? p.checklists.map((c) => (c.userId === meId ? { ...c, items, updatedAt: now() } : c))
            : [...p.checklists, { userId: meId, items, updatedAt: now() }],
        };
      });
    },
    [meId],
  );

  const addDiaryEntry = useCallback(
    (promptType: DiaryPromptType, content: string) => {
      const today = new Date().toISOString().split("T")[0];
      setDb((p) => ({
        ...p,
        diaryEntries: [
          ...p.diaryEntries,
          {
            id: uid("de"),
            studentId: meId,
            date: today,
            promptType,
            content,
            createdAt: now(),
          },
        ],
      }));
    },
    [meId],
  );

  const submitSelfAssessment = useCallback(
    (checklistId: string, responses: { itemIndex: number; checked: boolean }[]) => {
      setDb((p) => ({
        ...p,
        selfAssessmentResponses: [
          ...p.selfAssessmentResponses.filter((r) => !(r.studentId === meId && r.checklistId === checklistId)),
          ...responses.map((r) => ({
            studentId: meId,
            checklistId,
            itemIndex: r.itemIndex,
            checked: r.checked,
            respondedAt: now(),
          })),
        ],
      }));
    },
    [meId],
  );

  const addFeedbackNote = useCallback(
    (taskSubmissionId: string, whatWentWell: string, whatToImprove: string) => {
      setDb((p) => ({
        ...p,
        feedbackNotes: [
          ...p.feedbackNotes,
          {
            id: uid("fn"),
            taskSubmissionId,
            authorId: meId,
            whatWentWell,
            whatToImprove,
            createdAt: now(),
          },
        ],
      }));
    },
    [meId],
  );

  const toggleDiaryVisibility = useCallback(
    (groupId: string) => {
      setDb((p) => ({
        ...p,
        groups: p.groups.map((g) => (g.id === groupId ? { ...g, diaryVisibleToTeacher: !g.diaryVisibleToTeacher } : g)),
      }));
    },
    [],
  );

  /* ================= admin (legacy) ================= */

  const addStopword = useCallback(
    (word: string) => {
      addBannedWord(word, "WARN");
    },
    [addBannedWord],
  );

  const removeStopword = useCallback(
    (word: string) => {
      setDb((p) => {
        const bw = p.bannedWords.find((b) => b.word === word);
        if (!bw) return p;
        return {
          ...p,
          bannedWords: p.bannedWords.filter((b) => b.id !== bw.id),
          safetyLog: [
            ...p.safetyLog,
            createSafetyLogEntry(meId, "CONTENT_FLAGGED", "BANNED_WORD", word, "Удалено запрещённое слово: «" + word + "»"),
          ],
        };
      });
    },
    [meId],
  );

  const resetDemo = useCallback(() => {
    localStorage.removeItem(LS_KEY);
    setDb(buildSeed());
  }, []);

  void TASK_TYPE_META;

  const value: AppCtx = {
    db,
    me,
    toasts,
    toast,
    login,
    logout,
    register,
    addStudent,
    changePassword,
    setAvatarVisibility,
    startTask,
    completeTask,
    saveCourse,
    deleteCourse,
    createTandem,
    autoPairTandems,
    createQuest,
    assignQuestRole,
    completeRole,
    createDoc,
    saveDocRevision,
    submitForReview,
    giveReview,
    sendMessage,
    peerReply,
    moderate,
    reviewFlag,
    addBannedWord,
    removeBannedWord,
    writeReflection,
    setChecklist,
    addDiaryEntry,
    submitSelfAssessment,
    addFeedbackNote,
    toggleDiaryVisibility,
    addStopword,
    removeStopword,
    resetDemo,
  };

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useApp(): AppCtx {
  const ctx = useContext(Ctx);
  if (!ctx) throw new Error("useApp вне AppProvider");
  return ctx;
}

export { sameDay };
