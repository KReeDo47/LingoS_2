import { useApp } from "../../lib/store";
import { sortedTasks, sortedUnits, suggestNextUnit, TASK_TYPE_META, unitProgress, courseProgress, getProgress } from "./suggest";
import { Button, Chip, Icon, Reveal, Ring, SectionTitle } from "../../components/ui";
import type { IconName } from "../../components/ui";
import type { Unit } from "../../lib/types";

type Nav = (r: string) => void;

/* ================= /student/courses — список ================= */
export function CoursesPage({ navigate }: { navigate: Nav }) {
  const { db, me } = useApp();
  if (!me) return null;
  return (
    <div>
      <SectionTitle kicker="модуль content · CEFR A1–B2" title="Мои курсы" right={<Chip tone="green">{db.courses.length} курс(а)</Chip>} />
      <div className="grid gap-4 md:grid-cols-2">
        {db.courses.map((c, i) => {
          const prog = courseProgress(db.progress, me.id, c);
          const units = sortedUnits(c);
          return (
            <Reveal key={c.id} delay={i * 70}>
              <button onClick={() => navigate(`student/courses/${c.id}`)} className="card-hover group flex h-full w-full cursor-pointer flex-col rounded-xl border border-line bg-card p-5 text-left">
                <div className="flex items-start justify-between gap-3">
                  <span className="grid h-12 w-12 place-items-center rounded-xl bg-night font-display text-[15px] font-black uppercase text-amber">{c.languageCode}</span>
                  <Chip tone="sky">{c.levelFrom} → {c.levelTo}</Chip>
                </div>
                <h3 className="mt-3 font-display text-[18px] font-black text-ink group-hover:text-pine">{c.title}</h3>
                <p className="mt-1 text-[12.5px] leading-relaxed text-ink-2">{c.description}</p>
                <p className="mt-1.5 text-[11.5px] font-semibold text-ink-3">{units.length} юнитов · {units.reduce((s, u) => s + u.tasks.length, 0)} заданий</p>
                <div className="mt-4 flex items-center gap-3">
                  <div className="h-2 flex-1 overflow-hidden rounded-full bg-paper-2">
                    <div className="anim-bar h-full rounded-full bg-pine" style={{ width: `${prog.pct}%` }} />
                  </div>
                  <span className="font-display text-[13px] font-black text-pine">{prog.pct}%</span>
                </div>
                <span className="mt-3 flex items-center gap-1 text-[12.5px] font-bold text-pine">Открыть курс <Icon name="arrowRight" size={13} className="transition-transform group-hover:translate-x-1" /></span>
              </button>
            </Reveal>
          );
        })}
      </div>
    </div>
  );
}

/* ================= /student/courses/[id] — юниты + прогресс + ветвление ================= */
export function CourseDetailPage({ courseId, navigate }: { courseId: string; navigate: Nav }) {
  const { db, me } = useApp();
  if (!me) return null;
  const course = db.courses.find((c) => c.id === courseId);
  if (!course) {
    return (
      <div className="py-16 text-center">
        <p className="font-display text-lg font-bold text-ink">Курс не найден</p>
        <Button className="mt-4" onClick={() => navigate("student/courses")}>К списку курсов</Button>
      </div>
    );
  }

  const units = sortedUnits(course);
  const suggestion = suggestNextUnit(db, me.id);
  const reviewSuggestion = suggestion?.kind === "REVIEW" ? suggestion : null;
  const prog = courseProgress(db.progress, me.id, course);

  // причина блокировки каждого юнита: незавершённый предыдущий или адаптивная рекомендация
  const lockReason = (idx: number): string | null => {
    if (idx === 0) return null;
    const prev = units[idx - 1];
    if (!unitProgress(db.progress, me.id, prev).complete) return `Сначала завершите обязательные задания «${prev.title}»`;
    return null;
  };
  const blockedByReview = reviewSuggestion?.blockedUnit.id ?? null;

  const unitStatus = (u: Unit, idx: number): { locked: boolean; reason: string | null; review: boolean } => {
    if (blockedByReview === u.id && reviewSuggestion) return { locked: true, reason: reviewSuggestion.reason, review: true };
    const r = lockReason(idx);
    return { locked: !!r, reason: r, review: false };
  };

  return (
    <div className="flex flex-col gap-6">
      <button onClick={() => navigate("student/courses")} className="flex w-fit cursor-pointer items-center gap-1.5 text-[12.5px] font-bold text-ink-3 transition hover:text-pine">
        <Icon name="arrowRight" size={13} className="rotate-180" /> Все курсы
      </button>

      {/* шапка курса */}
      <Reveal>
        <div className="grid gap-5 rounded-xl border border-line bg-night p-6 text-paper sm:grid-cols-[auto_1fr] sm:items-center">
          <Ring value={prog.pct / 100} size={110} stroke={11} color="var(--color-amber)" track="#243b45">
            <span className="font-display text-[20px] font-black text-amber">{prog.pct}%</span>
          </Ring>
          <div>
            <div className="flex flex-wrap items-center gap-2">
              <h2 className="font-display text-[22px] font-black">{course.title}</h2>
              <Chip tone="night" className="!border !border-night-3">{course.languageCode.toUpperCase()} · {course.levelFrom}–{course.levelTo}</Chip>
            </div>
            <p className="mt-1 text-[13px] text-paper/70">{course.description}</p>
            <div className="mt-3 flex flex-wrap gap-x-6 gap-y-1 text-[12.5px] font-semibold text-paper/60">
              <span>{units.length} юнитов</span>
              <span>{prog.done} из {prog.total} заданий</span>
              <span className="flex items-center gap-1.5"><Icon name="target" size={13} className="text-amber" /> &lt;60% по последним 3 → повтор юнита</span>
            </div>
          </div>
        </div>
      </Reveal>

      {/* рекомендация адаптивного ветвления */}
      {suggestion?.kind === "REVIEW" && (
        <Reveal>
          <div className="anim-fade-up flex flex-wrap items-center gap-3 rounded-xl border-2 border-amber bg-amber-soft/60 px-5 py-4">
            <span className="grid h-10 w-10 shrink-0 place-items-center rounded-full bg-amber text-night anim-pulse-ring"><Icon name="refresh" size={19} /></span>
            <div className="min-w-0 flex-1">
              <p className="font-display text-[14px] font-black text-[#7a4d0d]">Адаптивное ветвление: рекомендуется повтор</p>
              <p className="text-[12.5px] leading-relaxed text-[#8a5a10]">{suggestion.reason}</p>
            </div>
            <Button variant="amber" size="sm" onClick={() => navigate(`student/courses/${course.id}`)}><Icon name="refresh" size={13} /> Повторить «{suggestion.unit.title}»</Button>
          </div>
        </Reveal>
      )}
      {suggestion?.kind === "COURSE_DONE" && (
        <Reveal>
          <div className="flex items-center gap-3 rounded-xl border-2 border-pine bg-pine-soft/60 px-5 py-4">
            <span className="grid h-10 w-10 place-items-center rounded-full bg-pine text-white"><Icon name="trophy" size={18} /></span>
            <p className="font-display text-[14px] font-black text-pine-deep">Курс завершён! Все обязательные задания выполнены.</p>
          </div>
        </Reveal>
      )}

      {/* путь юнитов */}
      <div className="flex flex-col gap-4">
        {units.map((unit, idx) => {
          const st = unitStatus(unit, idx);
          const up = unitProgress(db.progress, me.id, unit);
          const isFrontier = suggestion?.kind === "NEXT" && suggestion.unit.id === unit.id;
          return (
            <Reveal key={unit.id} delay={idx * 60}>
              <div className={`relative rounded-xl border-2 bg-card p-4 transition-all sm:p-5 ${idx < units.length - 1 ? "unit-connector" : ""} ${st.locked ? "border-line opacity-75" : isFrontier ? "border-pine/60 shadow-[0_10px_30px_-18px_rgba(12,122,95,0.5)]" : "border-line"}`}>
                <div className="flex items-start gap-3.5">
                  <span className={`relative z-10 grid h-12 w-12 shrink-0 place-items-center rounded-xl font-display text-[15px] font-black ${st.locked ? "bg-paper-2 text-ink-3" : up.complete ? "bg-pine text-white" : "bg-night text-paper"}`}>
                    {st.locked ? <Icon name="lock" size={18} /> : up.complete ? <Icon name="check" size={20} strokeWidth={2.6} /> : idx + 1}
                  </span>
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <h3 className="font-display text-[15.5px] font-bold text-ink">{unit.title}</h3>
                      <Chip tone="sky">{unit.cefrLevel}</Chip>
                      {isFrontier && !st.locked && <Chip tone="green"><span className="blink-dot h-1.5 w-1.5 rounded-full bg-pine" /> вы здесь</Chip>}
                    </div>
                    {st.locked ? (
                      <p className={`mt-1.5 flex items-start gap-1.5 text-[12.5px] font-semibold ${st.review ? "text-[#7a4d0d]" : "text-ink-2"}`}>
                        <Icon name={st.review ? "refresh" : "lock"} size={13} className="mt-0.5 shrink-0" /> {st.reason}
                      </p>
                    ) : (
                      <div className="mt-1.5 flex items-center gap-2.5">
                        <div className="h-1.5 w-32 overflow-hidden rounded-full bg-paper-2">
                          <div className="h-full rounded-full bg-pine transition-all" style={{ width: `${up.pct}%` }} />
                        </div>
                        <span className="text-[12px] font-bold text-ink-2">{up.done}/{up.total} · обязательных {up.requiredDone}/{up.requiredTotal}</span>
                      </div>
                    )}
                  </div>
                </div>

                {!st.locked && (
                  <div className="mt-3.5 grid gap-2 sm:pl-[62px]">
                    {sortedTasks(unit).map((task) => {
                      const p = getProgress(db.progress, me.id, task.id);
                      const meta = TASK_TYPE_META[task.type];
                      return (
                        <button
                          key={task.id}
                          onClick={() => navigate(`student/tasks/${task.id}`)}
                          className="group flex cursor-pointer items-center gap-3 rounded-lg border border-line bg-paper px-3.5 py-2.5 text-left transition hover:border-pine/50 hover:bg-pine-soft/30"
                        >
                          <span className={`grid h-8 w-8 shrink-0 place-items-center rounded-lg`} style={{ background: `hsl(${meta.hue} 50% 90%)`, color: `hsl(${meta.hue} 45% 30%)` }}>
                            <Icon name={meta.icon as IconName} size={15} />
                          </span>
                          <span className="min-w-0 flex-1">
                            <span className="block truncate text-[13.5px] font-bold text-ink">Задание {task.order} · {meta.label}</span>
                            <span className="block text-[11.5px] text-ink-3">
                              {task.requiredForCompletion ? "обязательное" : "по желанию"}
                              {p?.status === "COMPLETED" && p.score !== null ? ` · результат ${p.score}%` : p?.status === "IN_PROGRESS" ? " · в процессе" : ""}
                            </span>
                          </span>
                          {p?.status === "COMPLETED" ? (
                            <Chip tone={p.score! >= 60 ? "green" : "amber"}>{p.score}% · ещё раз</Chip>
                          ) : (
                            <span className="flex items-center gap-1 text-[12px] font-bold text-pine">{p?.status === "IN_PROGRESS" ? "Продолжить" : "Начать"} <Icon name="arrowRight" size={12} className="transition-transform group-hover:translate-x-0.5" /></span>
                          )}
                        </button>
                      );
                    })}
                  </div>
                )}
              </div>
            </Reveal>
          );
        })}
      </div>
    </div>
  );
}
