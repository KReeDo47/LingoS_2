import type { BannedWord, ContentFlag, DB, SafetyActionType, SafetyLogEntry } from "../../lib/types";
import { now, uid } from "../../lib/logic";

/**
 * Проверка текста на наличие запрещённых слов
 * Возвращает массив найденных слов с их severity
 */
export function checkBannedWords(
  text: string,
  bannedWords: BannedWord[]
): { word: string; severity: BannedWord["severity"] }[] {
  const lowerText = text.toLowerCase();
  return bannedWords
    .filter((bw) => lowerText.includes(bw.word.toLowerCase()))
    .map((bw) => ({ word: bw.word, severity: bw.severity }));
}

/**
 * Создание записи в SafetyLog
 */
export function createSafetyLogEntry(
  actorId: string,
  actionType: SafetyActionType,
  targetType: string,
  targetId: string,
  reason: string
): SafetyLogEntry {
  return {
    id: uid("sl"),
    actorId,
    actionType,
    targetType,
    targetId,
    reason,
    createdAt: now(),
  };
}

/**
 * Создание ContentFlag
 */
export function createContentFlag(
  contentType: ContentFlag["contentType"],
  contentId: string,
  flaggedBy: string,
  flagReason: string
): ContentFlag {
  return {
    id: uid("cf"),
    contentType,
    contentId,
    flaggedBy,
    flagReason,
    status: "PENDING",
    createdAt: now(),
  };
}

/**
 * Обработка сообщения при создании
 * Проверяет на запрещённые слова и создаёт соответствующие записи
 */
export function processMessage(
  db: DB,
  messageId: string,
  content: string,
  authorId: string
): {
  shouldHide: boolean;
  hideReason: string | null;
  newFlags: ContentFlag[];
  newLogEntries: SafetyLogEntry[];
} {
  const violations = checkBannedWords(content, db.bannedWords);
  
  if (violations.length === 0) {
    return {
      shouldHide: false,
      hideReason: null,
      newFlags: [],
      newLogEntries: [],
    };
  }

  const autoHideViolations = violations.filter((v) => v.severity === "AUTO_HIDE");
  const warnViolations = violations.filter((v) => v.severity === "WARN");

  const shouldHide = autoHideViolations.length > 0;
  const hideReason = shouldHide
    ? `Запрещённые слова (AUTO_HIDE): ${autoHideViolations.map((v) => `«${v.word}»`).join(", ")}`
    : null;

  const newFlags: ContentFlag[] = [];
  const newLogEntries: SafetyLogEntry[] = [];

  // Создаём флаги для AUTO_HIDE
  if (shouldHide) {
    newFlags.push(
      createContentFlag(
        "MESSAGE",
        messageId,
        "AUTO",
        `Запрещённые слова (AUTO_HIDE): ${autoHideViolations.map((v) => `«${v.word}»`).join(", ")}`
      )
    );
    newLogEntries.push(
      createSafetyLogEntry(
        "AUTO",
        "MESSAGE_HIDDEN",
        "MESSAGE",
        messageId,
        `Автоматическое скрытие: ${autoHideViolations.map((v) => `«${v.word}»`).join(", ")}`
      )
    );
  }

  // Создаём флаги для WARN
  if (warnViolations.length > 0) {
    newFlags.push(
      createContentFlag(
        "MESSAGE",
        messageId,
        "AUTO",
        `Запрещённые слова (WARN): ${warnViolations.map((v) => `«${v.word}»`).join(", ")}`
      )
    );
    newLogEntries.push(
      createSafetyLogEntry(
        "AUTO",
        "CONTENT_FLAGGED",
        "MESSAGE",
        messageId,
        `Предупреждение: ${warnViolations.map((v) => `«${v.word}»`).join(", ")}`
      )
    );
  }

  return {
    shouldHide,
    hideReason,
    newFlags,
    newLogEntries,
  };
}
