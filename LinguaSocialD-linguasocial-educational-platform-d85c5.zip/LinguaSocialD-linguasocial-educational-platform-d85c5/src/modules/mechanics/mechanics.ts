/* ============================================================
   Модуль mechanics (QWEN.md, модуль 4) · логика
   Соревновательные и статусные механики
   ============================================================ */
import type { Badge, Challenge, ChallengeResult, DB, LedgerEntry, LedgerReason, MentorRole, StudentBadge } from "../../lib/types";

/* ---------- Уровни (чистая функция) ---------- */

const LEVEL_CONFIG = [
  { threshold: 0, name: "Новичок", icon: "🌱" },
  { threshold: 100, name: "Ученик", icon: "📚" },
  { threshold: 300, name: "Практик", icon: "✏️" },
  { threshold: 700, name: "Знаток", icon: "🎓" },
  { threshold: 1500, name: "Мастер", icon: "🏆" },
  { threshold: 3000, name: "Эксперт", icon: "⭐" },
  { threshold: 5000, name: "Легенда", icon: "👑" },
];

export function getLevel(totalPoints: number): { level: number; name: string; icon: string; nextThreshold: number | null; progress: number } {
  let level = 0;
  for (let i = 0; i < LEVEL_CONFIG.length; i++) {
    if (totalPoints >= LEVEL_CONFIG[i].threshold) {
      level = i;
    } else {
      break;
    }
  }
  const current = LEVEL_CONFIG[level];
  const next = LEVEL_CONFIG[level + 1];
  const nextThreshold = next ? next.threshold : null;
  const progress = nextThreshold ? (totalPoints - current.threshold) / (nextThreshold - current.threshold) : 1;
  return { level, name: current.name, icon: current.icon, nextThreshold, progress };
}

/* ---------- Бейджи ---------- */

const BADGE_RULES = [
  { code: "FIRST_10_TASKS", title: "Первые шаги", description: "Выполнить 10 заданий", check: (db: DB, userId: string) => db.ledger.filter((l) => l.userId === userId && l.reason === "TASK_COMPLETED").length >= 10 },
  { code: "STREAK_7_DAYS", title: "Неделя без пропусков", description: "7 дней подряд с активностью", check: (db: DB, userId: string) => {
    const days = new Set(db.ledger.filter((l) => l.userId === userId).map((l) => new Date(l.at).toDateString()));
    if (days.size < 7) return false;
    const sorted = Array.from(days).sort((a, b) => new Date(b).getTime() - new Date(a).getTime());
    for (let i = 0; i < 6; i++) {
      const curr = new Date(sorted[i]);
      const next = new Date(sorted[i + 1]);
      const diff = (curr.getTime() - next.getTime()) / (1000 * 60 * 60 * 24);
      if (diff !== 1) return false;
    }
    return true;
  }},
  { code: "PEER_REVIEW_5", title: "Критик", description: "Дать 5 peer-review", check: (db: DB, userId: string) => db.ledger.filter((l) => l.userId === userId && l.reason === "PEER_REVIEW_GIVEN").length >= 5 },
  { code: "QUEST_COMPLETED_3", title: "Командный игрок", description: "Завершить 3 квеста", check: (db: DB, userId: string) => db.ledger.filter((l) => l.userId === userId && l.reason === "QUEST_COMPLETED").length >= 3 },
  { code: "CHALLENGE_WON_1", title: "Победитель", description: "Выиграть 1 челлендж", check: (db: DB, userId: string) => db.challengeResults.some((r) => r.studentId === userId && r.rank === 1) },
];

export function checkAndAwardBadges(db: DB, userId: string): string[] {
  const earned: string[] = [];
  for (const rule of BADGE_RULES) {
    const alreadyHas = db.studentBadges.some((sb) => sb.studentId === userId && db.badges.find((b) => b.id === sb.badgeId)?.code === rule.code);
    if (!alreadyHas && rule.check(db, userId)) {
      const badgeId = db.badges.find((b) => b.code === rule.code)?.id;
      if (badgeId) {
        db.studentBadges.push({ studentId: userId, badgeId, earnedAt: Date.now() });
        earned.push(rule.code);
      }
    }
  }
  return earned;
}

/* ---------- Языковой наставник ---------- */

export function checkMentorEligibility(db: DB, studentId: string): boolean {
  const totalPoints = db.ledger.filter((l) => l.userId === studentId).reduce((sum, l) => sum + l.points, 0);
  const taskCount = db.ledger.filter((l) => l.userId === studentId && l.reason === "TASK_COMPLETED").length;
  const peerReviewCount = db.ledger.filter((l) => l.userId === studentId && l.reason === "PEER_REVIEW_GIVEN").length;
  
  // Критерии: минимум 500 баллов, 20 заданий, 10 peer-review
  return totalPoints >= 500 && taskCount >= 20 && peerReviewCount >= 10;
}

export function updateMentorRole(db: DB, studentId: string): void {
  const eligible = checkMentorEligibility(db, studentId);
  const existing = db.mentorRoles.find((m) => m.studentId === studentId);
  
  if (eligible && !existing) {
    db.mentorRoles.push({ studentId, grantedAt: Date.now(), revokedAt: null });
  } else if (!eligible && existing && existing.revokedAt === null) {
    existing.revokedAt = Date.now();
  }
}

export function isMentor(db: DB, studentId: string): boolean {
  const role = db.mentorRoles.find((m) => m.studentId === studentId);
  return role !== undefined && role.revokedAt === null;
}

/* ---------- Начисление баллов ---------- */

export function awardPoints(db: DB, userId: string, points: number, reason: LedgerReason, sourceId: string): void {
  db.ledger.push({
    id: `ledger-${Date.now()}-${Math.random().toString(36).slice(2)}`,
    userId,
    points,
    reason,
    sourceId,
    at: Date.now(),
  });
  
  // Проверяем бейджи и наставничество
  checkAndAwardBadges(db, userId);
  updateMentorRole(db, userId);
}

/* ---------- Хуки из других модулей ---------- */

export function onTaskCompleted(db: DB, userId: string, taskId: string): void {
  // Базовые баллы за задание: 10 баллов
  awardPoints(db, userId, 10, "TASK_COMPLETED", taskId);
}

export function onPeerReviewGiven(db: DB, userId: string, submissionId: string): void {
  // 5 баллов за peer-review
  awardPoints(db, userId, 5, "PEER_REVIEW_GIVEN", submissionId);
}

export function onQuestCompleted(db: DB, userId: string, questId: string): void {
  // 50 баллов за квест
  awardPoints(db, userId, 50, "QUEST_COMPLETED", questId);
}

export function onChallengeWon(db: DB, userId: string, challengeId: string): void {
  // 100 баллов за победу в челлендже
  awardPoints(db, userId, 100, "CHALLENGE_WON", challengeId);
}

/* ---------- Челленджи ---------- */

export function calculateChallengeResults(db: DB, challengeId: string): void {
  const challenge = db.challenges.find((c) => c.id === challengeId);
  if (!challenge || Date.now() < challenge.endsAt) return;
  
  // Получаем результаты участников
  const results: { studentId: string; score: number }[] = [];
  
  // В реальной реализации здесь будет логика подсчёта очков за челлендж
  // Для демо просто берём топ учеников по баллам
  const students = db.users.filter((u) => u.role === "STUDENT" && u.classGroupId === challenge.classGroupId);
  for (const student of students) {
    const score = db.ledger.filter((l) => l.userId === student.id).reduce((sum, l) => sum + l.points, 0);
    results.push({ studentId: student.id, score });
  }
  
  // Сортируем по убыванию
  results.sort((a, b) => b.score - a.score);
  
  // Сохраняем результаты
  for (let i = 0; i < results.length; i++) {
    db.challengeResults.push({
      challengeId,
      studentId: results[i].studentId,
      teamId: null,
      score: results[i].score,
      rank: i + 1,
    });
    
    // Начисляем баллы победителю
    if (i === 0) {
      onChallengeWon(db, results[i].studentId, challengeId);
    }
  }
}

/* ---------- Рейтинги ---------- */

export function getPersonalProgressRanking(db: DB, userId: string): { rank: number; total: number; growth: number } {
  const user = db.users.find((u) => u.id === userId);
  if (!user || user.role !== "STUDENT") return { rank: 0, total: 0, growth: 0 };
  
  // Личный прогресс: сравниваем с собой прошлым
  const now = Date.now();
  const weekAgo = now - 7 * 24 * 60 * 60 * 1000;
  const currentPoints = db.ledger.filter((l) => l.userId === userId && l.at >= weekAgo).reduce((sum, l) => sum + l.points, 0);
  const prevWeekPoints = db.ledger.filter((l) => l.userId === userId && l.at < weekAgo && l.at >= weekAgo - 7 * 24 * 60 * 60 * 1000).reduce((sum, l) => sum + l.points, 0);
  const growth = currentPoints - prevWeekPoints;
  
  // Ранг среди всех учеников по текущему прогрессу
  const students = db.users.filter((u) => u.role === "STUDENT");
  const rankings = students.map((s) => ({
    id: s.id,
    points: db.ledger.filter((l) => l.userId === s.id && l.at >= weekAgo).reduce((sum, l) => sum + l.points, 0),
  }));
  rankings.sort((a, b) => b.points - a.points);
  const rank = rankings.findIndex((r) => r.id === userId) + 1;
  
  return { rank, total: currentPoints, growth };
}

export function getTeamRanking(db: DB, classGroupId: string): { rank: number; totalPoints: number; avgPoints: number } {
  const students = db.users.filter((u) => u.role === "STUDENT" && u.classGroupId === classGroupId);
  const totalPoints = students.reduce((sum, s) => sum + db.ledger.filter((l) => l.userId === s.id).reduce((s2, l) => s2 + l.points, 0), 0);
  const avgPoints = students.length > 0 ? totalPoints / students.length : 0;
  
  // Ранг среди всех групп
  const groups = db.groups;
  const groupRankings = groups.map((g) => {
    const groupStudents = db.users.filter((u) => u.role === "STUDENT" && u.classGroupId === g.id);
    const groupTotal = groupStudents.reduce((sum, s) => sum + db.ledger.filter((l) => l.userId === s.id).reduce((s2, l) => s2 + l.points, 0), 0);
    return { id: g.id, total: groupTotal };
  });
  groupRankings.sort((a, b) => b.total - a.total);
  const rank = groupRankings.findIndex((r) => r.id === classGroupId) + 1;
  
  return { rank, totalPoints, avgPoints };
}
