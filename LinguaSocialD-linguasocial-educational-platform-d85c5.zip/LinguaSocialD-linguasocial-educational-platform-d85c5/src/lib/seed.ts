/* ============================================================
   Демо-данные LinguaSocial (v5): модули users / content / social.
   2 группы, 12 учеников, 3 недели истории, живые тандемы, квесты,
   документы с ревизиями, работы на peer-review и чаты.
   ============================================================ */
import { DAY, now } from "./logic";
import { hashPassword } from "./validation";
import type {
  Course,
  DB,
  LedgerEntry,
  LedgerReason,
  StudentProgress,
  User,
} from "./types";

const d = (days: number, hours = 0) => now() - days * DAY - hours * 3_600_000;
const f = (days: number) => now() + days * DAY; // будущая дата (дедлайны)
const PW = hashPassword("demo123");

const stu = (id: string, email: string, fullName: string, displayName: string, classGroupId: string, hue: number, inactiveDays: number): User => ({
  id,
  role: "STUDENT",
  email,
  passwordHash: PW,
  fullName,
  displayName,
  showAvatar: true,
  mustChangePassword: false,
  hue,
  classGroupId,
  cefr: "A2",
  lastActiveAt: d(inactiveDays, 2),
  createdAt: d(60),
});

/* ---------------- курс English · A1→A2 (QWEN.md: Course→Unit→Task) ---------------- */
const course: Course = {
  id: "c1",
  title: "English Quest",
  languageCode: "en",
  levelFrom: "A1",
  levelTo: "A2",
  description: "Базовый курс английского для 5–7 классов: от первых фраз до связных текстов.",
  units: [
    {
      id: "u1", courseId: "c1", title: "Знакомство", order: 1, cefrLevel: "A1",
      tasks: [
        {
          id: "u1t1", unitId: "u1", type: "VOCAB", order: 1, requiredForCompletion: true,
          content: {
            items: [
              { prompt: "Как сказать «привет» по-английски?", answer: "Hello", options: ["Hello", "Goodbye", "Thanks", "Please"] },
              { prompt: "Выберите перевод: «меня зовут…»", answer: "My name is", options: ["My name is", "I am fine", "How old", "Nice day"] },
              { prompt: "What is «спасибо»?", answer: "Thank you", options: ["Thank you", "Sorry", "Good night", "Yes"] },
            ],
          },
        },
        {
          id: "u1t2", unitId: "u1", type: "GRAMMAR", order: 2, requiredForCompletion: true,
          content: {
            items: [
              { prompt: "I ___ a student.", answer: "am", hint: "Глагол to be для «I»" },
              { prompt: "She ___ from Russia.", answer: "is", hint: "he/she/it → is" },
              { prompt: "We ___ friends.", answer: "are", hint: "we/you/they → are" },
            ],
          },
        },
        {
          id: "u1t3", unitId: "u1", type: "SPEAKING_PROMPT", order: 3, requiredForCompletion: false,
          content: { prompt: "Расскажите о себе 5–6 предложений: имя, возраст, город, хобби.", rubric: ["Есть имя и возраст", "Упомянут город", "Рассказано о хобби", "Полные предложения"] },
        },
      ],
    },
    {
      id: "u2", courseId: "c1", title: "Еда и кафе", order: 2, cefrLevel: "A2",
      tasks: [
        {
          id: "u2t1", unitId: "u2", type: "VOCAB", order: 1, requiredForCompletion: true,
          content: {
            items: [
              { prompt: "«Чай» по-английски — это…", answer: "tea", options: ["tea", "coffee", "juice", "milk"] },
              { prompt: "Выберите напиток: «кофе»", answer: "coffee", options: ["coffee", "cake", "cheese", "chicken"] },
              { prompt: "What is «официант»?", answer: "waiter", options: ["waiter", "cook", "driver", "teacher"] },
            ],
          },
        },
        {
          id: "u2t2", unitId: "u2", type: "GRAMMAR", order: 2, requiredForCompletion: true,
          content: {
            items: [
              { prompt: "Соберите: «Я хочу пиццу, пожалуйста»", answer: "I would like a pizza please", options: ["I", "would", "like", "a", "pizza", "please", "am", "cat"], hint: "would like + существительное" },
              { prompt: "«Можно мне чай?» — Could I have some ___?", answer: "tea" },
            ],
          },
        },
        {
          id: "u2t3", unitId: "u2", type: "WRITING", order: 3, requiredForCompletion: true,
          content: { prompt: "Напишите 5–7 предложений о своём любимом кафе: где оно, что вы там едите, с кем ходите.", minWords: 25, rubric: ["Есть вступление", "Использованы слова темы «Еда»", "Правильный порядок слов", "5–7 предложений"] },
        },
      ],
    },
    {
      id: "u3", courseId: "c1", title: "Мой день", order: 3, cefrLevel: "A2",
      tasks: [
        {
          id: "u3t1", unitId: "u3", type: "LISTENING", order: 1, requiredForCompletion: true,
          content: {
            audioText: "Hi! I'm Tom. I get up at seven o'clock. I have breakfast and go to school. After school I play football with my friends. In the evening I read books.",
            items: [
              { prompt: "Во сколько Том встаёт?", answer: "At seven", options: ["At seven", "At six", "At eight", "At nine"] },
              { prompt: "Что Том делает после школы?", answer: "Plays football", options: ["Plays football", "Reads books", "Watches TV", "Sleeps"] },
            ],
          },
        },
        {
          id: "u3t2", unitId: "u3", type: "GRAMMAR", order: 2, requiredForCompletion: true,
          content: {
            items: [
              { prompt: "She ___ (get) up at 7 every day.", answer: "gets", hint: "3-е лицо ед. ч. → -s" },
              { prompt: "I ___ (not/like) coffee.", answer: "don't like", hint: "Отрицание в Present Simple" },
              { prompt: "___ he play football?", answer: "Does", hint: "Вопрос: Does + подлежащее" },
            ],
          },
        },
        {
          id: "u3t3", unitId: "u3", type: "VOCAB", order: 3, requiredForCompletion: true,
          content: {
            items: [
              { prompt: "«Завтракать» — это…", answer: "have breakfast", options: ["have breakfast", "go to bed", "do homework", "take a shower"] },
              { prompt: "Выберите «ложиться спать»", answer: "go to bed", options: ["go to bed", "get up", "have lunch", "come home"] },
            ],
          },
        },
      ],
    },
    {
      id: "u4", courseId: "c1", title: "Путешествия", order: 4, cefrLevel: "A2",
      tasks: [
        {
          id: "u4t1", unitId: "u4", type: "VOCAB", order: 1, requiredForCompletion: true,
          content: {
            items: [
              { prompt: "«Аэропорт» по-английски — это…", answer: "airport", options: ["airport", "station", "harbour", "square"] },
              { prompt: "Что мы кладём в «чемодан»?", answer: "suitcase", options: ["suitcase", "ticket", "passport", "wallet"] },
            ],
          },
        },
        {
          id: "u4t2", unitId: "u4", type: "LISTENING", order: 2, requiredForCompletion: true,
          content: {
            audioText: "Attention please! Flight 205 to London is now boarding at gate 7. Please have your boarding pass ready.",
            items: [
              { prompt: "Куда летит рейс 205?", answer: "To London", options: ["To London", "To Paris", "To Moscow", "To Rome"] },
              { prompt: "Какой выход (gate)?", answer: "Gate 7", options: ["Gate 7", "Gate 5", "Gate 9", "Gate 2"] },
            ],
          },
        },
        {
          id: "u4t3", unitId: "u4", type: "WRITING", order: 3, requiredForCompletion: true,
          content: { prompt: "Напишите открытку из поездки (5–8 предложений): где вы, какая погода, что видели.", minWords: 30, rubric: ["Есть приветствие и прощание", "Упомянуто место и погода", "6+ предложений", "Связный текст"] },
        },
      ],
    },
  ],
};

/* ---------------- StudentProgress (статусы + score) ---------------- */
const P = (studentId: string, taskId: string, score: number | null, daysAgo: number): StudentProgress => ({
  studentId,
  taskId,
  status: "COMPLETED",
  score,
  completedAt: d(daysAgo, 3),
});

const progress: StudentProgress[] = [
  // Аня: юнит 3 «провален» (55/50/40) → адаптивная рекомендация повтора
  P("s1", "u1t1", 100, 20), P("s1", "u1t2", 90, 19), P("s1", "u1t3", 95, 18),
  P("s1", "u2t1", 87, 13), P("s1", "u2t2", 80, 10), P("s1", "u2t3", 75, 9),
  P("s1", "u3t1", 55, 7), P("s1", "u3t2", 50, 4), P("s1", "u3t3", 40, 1),
  P("s2", "u1t1", 80, 19), P("s2", "u1t2", 75, 18), P("s2", "u1t3", 85, 17),
  P("s2", "u2t1", 93, 12), P("s2", "u2t2", 70, 6), P("s2", "u2t3", 75, 5),
  P("s2", "u3t1", 90, 2),
  P("s3", "u1t1", 70, 15), P("s3", "u1t2", 75, 11), P("s3", "u1t3", 60, 10),
  P("s3", "u2t1", 60, 6), P("s3", "u2t2", 66, 1),
  P("s4", "u1t1", 45, 14),
  P("s5", "u1t1", 60, 10), P("s5", "u1t2", 80, 7),
  P("s6", "u1t1", 40, 13),
  P("s7", "u1t1", 90, 8), P("s7", "u1t2", 85, 5), P("s7", "u1t3", 80, 2),
  P("s8", "u1t1", 70, 9), P("s8", "u1t2", 75, 5), P("s8", "u1t3", 70, 0),
  P("s9", "u1t1", 55, 8), P("s9", "u1t2", 70, 3),
  P("s10", "u1t1", 30, 12),
  P("s11", "u1t1", 95, 7), P("s11", "u1t2", 90, 4), P("s11", "u1t3", 85, 1),
  P("s12", "u1t1", 50, 6), P("s12", "u1t2", 65, 5),
];

/* ---------------- PointsLedger (append-only) ---------------- */
const L = (id: string, userId: string, daysAgo: number, points: number, reason: LedgerReason, sourceId: string): LedgerEntry => ({ id, userId, points, reason, sourceId, at: d(daysAgo, 5) });

const ledger: LedgerEntry[] = [
  L("l1", "s1", 20, 20, "TASK_COMPLETED", "u1t1"), L("l2", "s1", 19, 18, "TASK_COMPLETED", "u1t2"), L("l3", "s1", 18, 14, "TASK_COMPLETED", "u1t3"),
  L("l4", "s1", 13, 15, "TASK_COMPLETED", "u2t1"), L("l5", "s1", 10, 16, "TASK_COMPLETED", "u2t2"), L("l6", "s1", 9, 19, "TASK_COMPLETED", "u2t3"),
  L("l7", "s1", 7, 11, "TASK_COMPLETED", "u3t1"), L("l8", "s1", 4, 10, "TASK_COMPLETED", "u3t2"), L("l9", "s1", 1, 8, "TASK_COMPLETED", "u3t3"),
  L("l10", "s1", 6, 3, "TASK_COMPLETED", "doc1"), L("l11", "s1", 5, 5, "PEER_REVIEW_GIVEN", "sub1"), L("l12", "s1", 4, 5, "TASK_COMPLETED", "u4t1"),
  L("l13", "s1", 14, 10, "QUEST_COMPLETED", "q1"), L("l14", "s1", 21, 15, "TASK_COMPLETED", "u4t2"), L("l15", "s1", 28, 12, "TASK_COMPLETED", "u4t3"), L("l16", "s1", 35, 10, "TASK_COMPLETED", "u5t1"),
  L("l20", "s2", 19, 16, "TASK_COMPLETED", "u1t1"), L("l21", "s2", 18, 15, "TASK_COMPLETED", "u1t2"),
  L("l22", "s2", 12, 15, "TASK_COMPLETED", "u2t1"), L("l23", "s2", 6, 14, "TASK_COMPLETED", "u2t2"), L("l24", "s2", 2, 10, "TASK_COMPLETED", "u3t1"),
  L("l25", "s2", 14, 10, "QUEST_COMPLETED", "q1"), L("l26", "s2", 22, 14, "TASK_COMPLETED", "u3t2"), L("l27", "s2", 29, 12, "TASK_COMPLETED", "u3t3"), L("l28", "s2", 36, 10, "TASK_COMPLETED", "u4t1"),
  L("l30", "s3", 15, 14, "TASK_COMPLETED", "u1t1"), L("l31", "s3", 11, 15, "TASK_COMPLETED", "u1t2"), L("l32", "s3", 3, 5, "TASK_COMPLETED", "u2t1"),
  L("l33", "s3", 23, 10, "TASK_COMPLETED", "u2t2"), L("l34", "s3", 30, 8, "TASK_COMPLETED", "u2t3"),
  L("l36", "s4", 14, 9, "TASK_COMPLETED", "u1t1"),
  L("l38", "s5", 10, 12, "TASK_COMPLETED", "u1t1"), L("l39", "s5", 7, 16, "TASK_COMPLETED", "u1t2"),
  L("l41", "s6", 13, 8, "TASK_COMPLETED", "u1t1"),
  L("l43", "s7", 8, 18, "TASK_COMPLETED", "u1t1"), L("l44", "s7", 5, 17, "TASK_COMPLETED", "u1t2"), L("l45", "s7", 2, 16, "TASK_COMPLETED", "u1t3"), L("l46", "s7", 0, 3, "TASK_COMPLETED", "doc1"),
  L("l47", "s7", 24, 12, "TASK_COMPLETED", "u2t1"), L("l48", "s7", 31, 10, "TASK_COMPLETED", "u2t2"), L("l49", "s7", 38, 8, "TASK_COMPLETED", "u2t3"),
  L("l51", "s8", 9, 14, "TASK_COMPLETED", "u1t1"), L("l52", "s8", 5, 15, "TASK_COMPLETED", "u1t2"), L("l53", "s8", 0, 14, "TASK_COMPLETED", "u1t3"),
  L("l55", "s9", 8, 11, "TASK_COMPLETED", "u1t1"), L("l56", "s9", 3, 14, "TASK_COMPLETED", "u1t2"),
  L("l58", "s10", 12, 6, "TASK_COMPLETED", "u1t1"),
  L("l60", "s11", 7, 19, "TASK_COMPLETED", "u1t1"), L("l61", "s11", 4, 18, "TASK_COMPLETED", "u1t2"), L("l62", "s11", 1, 14, "TASK_COMPLETED", "u1t3"),
  L("l63", "s11", 25, 13, "TASK_COMPLETED", "u2t1"), L("l64", "s11", 32, 11, "TASK_COMPLETED", "u2t2"), L("l65", "s11", 39, 10, "TASK_COMPLETED", "u2t3"),
  L("l67", "s12", 6, 10, "TASK_COMPLETED", "u1t1"), L("l68", "s12", 5, 13, "TASK_COMPLETED", "u1t2"),
];

/* ---------------- сборка ---------------- */
export function buildSeed(): DB {
  const msgHiddenId = "m-hidden";
  return {
    version: 6,
    sessionId: null,
    users: [
      { id: "u-admin", role: "ADMIN", email: "root@lingua.school", passwordHash: PW, fullName: "Администратор платформы", displayName: "Админ", showAvatar: true, mustChangePassword: false, hue: 210, classGroupId: null, cefr: "B2", lastActiveAt: d(0, 1), createdAt: d(90) },
      { id: "u-t1", role: "TEACHER", email: "marina@lingua.school", passwordHash: PW, fullName: "Соколова Мария Викторовна", displayName: "Мария Викторовна", showAvatar: true, mustChangePassword: false, hue: 158, classGroupId: null, cefr: "B2", lastActiveAt: d(0, 2), createdAt: d(80) },
      { id: "u-t2", role: "TEACHER", email: "dmitry@lingua.school", passwordHash: PW, fullName: "Ким Дмитрий Сергеевич", displayName: "Дмитрий Сергеевич", showAvatar: true, mustChangePassword: false, hue: 24, classGroupId: null, cefr: "B2", lastActiveAt: d(1, 4), createdAt: d(75) },
      stu("s1", "anya@lingua.school", "Крылова Анна Дмитриевна", "Аня", "g1", 152, 0),
      stu("s2", "timur@lingua.school", "Валеев Тимур Русланович", "Тимур", "g1", 208, 1),
      stu("s3", "vera@lingua.school", "Чистова Вера Павловна", "Вера", "g1", 320, 1),
      stu("s4", "mark@lingua.school", "Орлов Марк Игоревич", "Марк", "g1", 16, 9),
      stu("s5", "sonya@lingua.school", "Литвинова София Олеговна", "Соня", "g1", 268, 2),
      stu("s6", "egor@lingua.school", "Савин Егор Алексеевич", "Егор", "g1", 44, 12),
      stu("s7", "liza@lingua.school", "Мороз Елизавета Артёмовна", "Лиза", "g1", 188, 0),
      stu("s8", "kirill@lingua.school", "Юдин Кирилл Максимович", "Кирилл", "g2", 96, 0),
      stu("s9", "dasha@lingua.school", "Белова Дарья Ильинична", "Даша", "g2", 288, 3),
      stu("s10", "ilya@lingua.school", "Громов Илья Романович", "Илья", "g2", 8, 8),
      stu("s11", "polina@lingua.school", "Ярцева Полина Андреевна", "Полина", "g2", 130, 1),
      stu("s12", "stepan@lingua.school", "Волков Степан Денисович", "Степан", "g2", 236, 5),
    ],
    groups: [
      { id: "g1", name: "7 «А»", teacherId: "u-t1", organizationName: "Школа № 17, лингвистический класс", diaryVisibleToTeacher: false },
      { id: "g2", name: "5 «Б»", teacherId: "u-t2", organizationName: "Школа № 17", diaryVisibleToTeacher: true },
    ],
    consents: [
      { userId: "s1", consentGivenBy: "Крылова Ольга Андреевна", consentDate: d(60) },
      { userId: "s2", consentGivenBy: "Валеев Руслан Маратович", consentDate: d(60) },
      { userId: "s3", consentGivenBy: "Чистов Павел Евгеньевич", consentDate: d(59) },
      { userId: "s4", consentGivenBy: "Орлова Наталья Викторовна", consentDate: d(59) },
      { userId: "s5", consentGivenBy: "Литвинов Олег Сергеевич", consentDate: d(30) },
      { userId: "s6", consentGivenBy: "Савина Елена Владимировна", consentDate: d(58) },
      { userId: "s7", consentGivenBy: "Мороз Артём Константинович", consentDate: d(58) },
      { userId: "s8", consentGivenBy: "Юдина Марина Петровна", consentDate: d(45) },
      { userId: "s9", consentGivenBy: "Белов Илья Николаевич", consentDate: d(45) },
      { userId: "s10", consentGivenBy: "Громова Анна Сергеевна", consentDate: d(44) },
      { userId: "s11", consentGivenBy: "Ярцев Андрей Львович", consentDate: d(44) },
      { userId: "s12", consentGivenBy: "Волкова Дарья Михайловна", consentDate: d(44) },
    ],
    courses: [course],
    progress,
    ledger,
    badges: [
      { id: "b1", code: "FIRST_10_TASKS", title: "Первые шаги", description: "Выполнить 10 заданий", iconUrl: "🌱" },
      { id: "b2", code: "STREAK_7_DAYS", title: "Неделя без пропусков", description: "7 дней подряд с активностью", iconUrl: "🔥" },
      { id: "b3", code: "PEER_REVIEW_5", title: "Критик", description: "Дать 5 peer-review", iconUrl: "✏️" },
      { id: "b4", code: "QUEST_COMPLETED_3", title: "Командный игрок", description: "Завершить 3 квеста", iconUrl: "🤝" },
      { id: "b5", code: "CHALLENGE_WON_1", title: "Победитель", description: "Выиграть 1 челлендж", iconUrl: "🏆" },
    ],
    studentBadges: [],
    challenges: [],
    challengeResults: [],
    mentorRoles: [],
    /* ---------- reflection: дневники, самооценки, обратная связь ---------- */
    diaryEntries: [
      { id: "de1", studentId: "s1", date: new Date(Date.now() - 2 * 86400000).toISOString().split('T')[0], promptType: "WHAT_LEARNED", content: "Сегодня выучила 10 новых слов по теме «Еда» и научилась заказывать в кафе.", createdAt: Date.now() - 2 * 86400000 },
      { id: "de2", studentId: "s1", date: new Date(Date.now() - 2 * 86400000).toISOString().split('T')[0], promptType: "WHAT_WAS_HARD", content: "Сложно запомнить разницу между some и any.", createdAt: Date.now() - 2 * 86400000 + 1000 },
      { id: "de3", studentId: "s2", date: new Date(Date.now() - 86400000).toISOString().split('T')[0], promptType: "WHAT_LEARNED", content: "Разобрался с Present Simple.", createdAt: Date.now() - 86400000 },
      { id: "de4", studentId: "s7", date: new Date(Date.now() - 86400000).toISOString().split('T')[0], promptType: "WHAT_TO_IMPROVE", content: "Нужно больше практиковать аудирование.", createdAt: Date.now() - 86400000 },
    ],
    selfAssessmentChecklists: [
      { id: "sac1", unitId: "u1", items: ["I can introduce myself", "I can ask someone's name", "I can say my age", "I can talk about my hobbies"] },
      { id: "sac2", unitId: "u2", items: ["I can order food in a café", "I can ask for the bill", "I can talk about my favorite food", "I can use 'would like' correctly"] },
      { id: "sac3", unitId: "u3", items: ["I can describe my daily routine", "I can use Present Simple correctly", "I can talk about time", "I can use adverbs of frequency"] },
      { id: "sac4", unitId: "u4", items: ["I can talk about travel", "I can use future tense", "I can ask for directions", "I can describe places"] },
    ],
    selfAssessmentResponses: [
      { studentId: "s1", checklistId: "sac1", itemIndex: 0, checked: true, respondedAt: Date.now() - 3 * 86400000 },
      { studentId: "s1", checklistId: "sac1", itemIndex: 1, checked: true, respondedAt: Date.now() - 3 * 86400000 },
      { studentId: "s1", checklistId: "sac1", itemIndex: 2, checked: true, respondedAt: Date.now() - 3 * 86400000 },
      { studentId: "s1", checklistId: "sac1", itemIndex: 3, checked: false, respondedAt: Date.now() - 3 * 86400000 },
      { studentId: "s2", checklistId: "sac1", itemIndex: 0, checked: true, respondedAt: Date.now() - 4 * 86400000 },
      { studentId: "s2", checklistId: "sac1", itemIndex: 1, checked: true, respondedAt: Date.now() - 4 * 86400000 },
    ],
    feedbackNotes: [
      { id: "fn1", taskSubmissionId: "sub1", authorId: "u-t1", whatWentWell: "Отличная структура текста, хорошее использование новой лексики.", whatToImprove: "Обратите внимание на согласование времен в последнем абзаце.", createdAt: Date.now() - 86400000 },
      { id: "fn2", taskSubmissionId: "sub3", authorId: "u-t1", whatWentWell: "Хорошее использование слов по теме, понятное изложение.", whatToImprove: "Попробуйте добавить больше деталей и примеров.", createdAt: Date.now() - 2 * 86400000 },
    ],
    /* ---------- social: тандемы (ZPD_MENTOR — сильный+слабый) ---------- */
    tandems: [
      { id: "t1", studentAId: "s1", studentBId: "s6", classGroupId: "g1", pairedReason: "ZPD_MENTOR", createdAt: d(12), active: true },
      { id: "t2", studentAId: "s2", studentBId: "s4", classGroupId: "g1", pairedReason: "ZPD_MENTOR", createdAt: d(12), active: true },
      { id: "t3", studentAId: "s7", studentBId: "s5", classGroupId: "g1", pairedReason: "ZPD_MENTOR", createdAt: d(12), active: true },
      { id: "t4", studentAId: "s11", studentBId: "s10", classGroupId: "g2", pairedReason: "ZPD_MENTOR", createdAt: d(10), active: true },
      { id: "t5", studentAId: "s8", studentBId: "s12", classGroupId: "g2", pairedReason: "PEER", createdAt: d(10), active: true },
    ],
    /* ---------- social: групповые квесты с ролями и дедлайном ---------- */
    quests: [
      {
        id: "q1", classGroupId: "g1", title: "Диалог в кафе", bonus: 20, status: "active", deadline: f(5),
        description: "Поставьте сценку «Заказ в кафе» на английском и запишите её для группы.",
        roles: [
          { name: "Сценарист", assignedTo: "s1", done: true },
          { name: "Переводчик", assignedTo: "s2", done: true },
          { name: "Актёр-официант", assignedTo: null, done: false },
          { name: "Редактор видео", assignedTo: null, done: false },
        ],
        contributions: ["s1", "s2"],
      },
      {
        id: "q2", classGroupId: "g1", title: "Карта школьного двора", bonus: 20, status: "active", deadline: f(7),
        description: "Нарисуйте карту и опишите её на английском: где что находится (opposite, next to, between).",
        roles: [
          { name: "Картограф", assignedTo: "s7", done: false },
          { name: "Гид", assignedTo: null, done: false },
          { name: "Летописец", assignedTo: null, done: false },
        ],
        contributions: [],
      },
      {
        id: "q3", classGroupId: "g2", title: "Видеооткрытка «Моя школа»", bonus: 25, status: "active", deadline: f(6),
        description: "Снимите короткую видеооткрытку о школе для англоязычных сверстников.",
        roles: [
          { name: "Режиссёр", assignedTo: "s11", done: false },
          { name: "Спикер", assignedTo: null, done: false },
          { name: "Субтитры", assignedTo: null, done: false },
        ],
        contributions: [],
      },
    ],
    /* ---------- social: совместные документы + история ревизий ---------- */
    docs: [
      { id: "doc1", classGroupId: "g1", title: "Письмо друзьям из Лондона", content: "Dear friends from London!\nHello! We are students from Russia, from school №17. We are in the 7th form.\nWe like English, football and pancakes! What do you like? Write to us!\n— Anya, Timur, Vera, Liza and friends", updatedAt: d(0, 4) },
      { id: "doc2", classGroupId: "g1", groupQuestId: "q1", title: "Сценарий «Заказ в кафе»", content: "Waiter: Good afternoon! What would you like?\nAnya: Hello! I'd like a cheese pizza and some juice, please.\nTimur: And could I have a cup of tea?", updatedAt: d(2, 6) },
      { id: "doc3", classGroupId: "g2", title: "Наша школа", content: "Hi! Our school is big and green. We have a nice garden.", updatedAt: d(1, 3) },
    ],
    docRevisions: [
      { id: "dr1", docId: "doc1", authorId: "s1", contentSnapshot: "Dear friends from London!\nHello! We are students from Russia. We like English.", createdAt: d(4, 6) },
      { id: "dr2", docId: "doc1", authorId: "s2", contentSnapshot: "Dear friends from London!\nHello! We are students from Russia, from school №17. We like English and football.\nWhat do you like?", createdAt: d(2, 5) },
      { id: "dr3", docId: "doc1", authorId: "s7", contentSnapshot: "Dear friends from London!\nHello! We are students from Russia, from school №17. We are in the 7th form.\nWe like English, football and pancakes! What do you like? Write to us!\n— Anya, Timur, Vera, Liza and friends", createdAt: d(0, 4) },
      { id: "dr4", docId: "doc2", authorId: "s1", contentSnapshot: "Waiter: Good afternoon! What would you like?\nAnya: Hello! I'd like a cheese pizza and some juice, please.\nTimur: And could I have a cup of tea?", createdAt: d(2, 6) },
      { id: "dr5", docId: "doc3", authorId: "s11", contentSnapshot: "Hi! Our school is big and green. We have a nice garden.", createdAt: d(1, 3) },
    ],
    /* ---------- social: работы на peer-review + разборы по рубрике ---------- */
    submissions: [
      { id: "sub1", taskId: "u2t3", studentId: "s5", title: "My favourite café", content: "My favourite café is «Keks». I go there with my mum on Sundays. I like hot chocolate and cheesecake. The waiters are friendly.", at: d(2, 2) },
      { id: "sub2", taskId: null, studentId: "s3", title: "My school day", content: "I get up at seven. I have six lesson every day. My favourite subject is Art because I likes drawing.", at: d(1, 2) },
      { id: "sub3", taskId: "u4t3", studentId: "s1", title: "My weekend", content: "On Saturday I went to the park with my dog. The weather was sunny. We played with a ball. On Sunday I read an English book and helped my mum.", at: d(1, 5) },
      { id: "sub4", taskId: null, studentId: "s9", title: "About me", content: "Hello! My name is Dasha. I am eleven. I like cats and music. I can play the guitar.", at: d(3, 5) },
    ],
    peerReviews: [
      {
        id: "pr1", taskSubmissionId: "sub1", reviewerId: "s1", createdAt: d(1, 6),
        rubricScores: [
          { criteria: "Содержание и идея", value: 4 },
          { criteria: "Словарный запас", value: 3 },
          { criteria: "Грамматика", value: 4 },
          { criteria: "Связность и оформление", value: 4 },
        ],
        comment: "Отличный текст! Добавь пару слов о том, что ты там делаешь, кроме еды. 🍰",
      },
      {
        id: "pr2", taskSubmissionId: "sub3", reviewerId: "s2", createdAt: d(0, 8),
        rubricScores: [
          { criteria: "Содержание и идея", value: 5 },
          { criteria: "Словарный запас", value: 4 },
          { criteria: "Грамматика", value: 4 },
          { criteria: "Связность и оформление", value: 5 },
        ],
        comment: "Круто! Особенно про субботу. Только «goed» → «went», это неправильный глагол 😉",
      },
    ],
    /* ---------- чаты групп (сообщение s6 автоскрыто стоп-фильтром) ---------- */
    messages: [
      { id: "m1", classGroupId: "g1", authorId: "s1", createdAt: d(1, 8), content: "Hi everyone! Кто уже прошёл юнит «Еда и кафе»? 🍩", hidden: false, hiddenReason: null },
      { id: "m2", classGroupId: "g1", authorId: "s2", createdAt: d(1, 7), content: "I did! The second task is fun — попробуйте собрать заказ пиццы 😄", hidden: false, hiddenReason: null },
      { id: "m3", classGroupId: "g1", authorId: "s3", createdAt: d(1, 6), content: "Ребят, объясните, пожалуйста, когда ставится «on», а когда «in»?", hidden: false, hiddenReason: null },
      { id: "m4", classGroupId: "g1", authorId: "s1", createdAt: d(1, 5), content: "Вера, on — с днями недели (on Monday), in — с частями дня (in the morning). Tomorrow объясню в тандеме!", hidden: false, hiddenReason: null },
      { id: "m5", classGroupId: "g2", authorId: "s11", createdAt: d(0, 9), content: "Good morning! Кто готов взять роль спикера в квесте?", hidden: false, hiddenReason: null },
      { id: msgHiddenId, classGroupId: "g1", authorId: "s6", createdAt: d(0, 6), content: "опять эти задания, глупый бот, не буду делать", hidden: true, hiddenReason: "Автофильтр: стоп-слово «глупый»" },
    ],
    queue: [
      { id: "q-1", messageId: msgHiddenId, reason: "Стоп-слово: «глупый»", status: "pending", at: d(0, 6) },
    ],
    safetyLog: [
      { id: "sl1", actorId: "AUTO", actionType: "MESSAGE_HIDDEN", targetType: "MESSAGE", targetId: msgHiddenId, reason: "Сработал фильтр запрещённых слов (severity=AUTO_HIDE): «глупый»", createdAt: d(0, 6) },
      { id: "sl2", actorId: "u-t1", actionType: "CONTENT_FLAGGED", targetType: "USER", targetId: "s5", reason: "Создан аккаунт ученика, согласие законного представителя получено", createdAt: d(30, 4) },
      { id: "sl3", actorId: "u-t1", actionType: "CONTENT_FLAGGED", targetType: "MESSAGE", targetId: "tandems", reason: "Автоподбор 3 пар «сильный + слабый» по среднему score (ZPD)", createdAt: d(12, 3) },
    ],
    contentFlags: [
      { id: "cf1", contentType: "MESSAGE", contentId: msgHiddenId, flaggedBy: "AUTO", flagReason: "Запрещённое слово (severity=AUTO_HIDE): «глупый»", status: "PENDING", createdAt: d(0, 6) },
    ],
    bannedWords: [
      { id: "bw1", word: "дурак", severity: "WARN" },
      { id: "bw2", word: "идиот", severity: "AUTO_HIDE" },
      { id: "bw3", word: "глупый", severity: "AUTO_HIDE" },
      { id: "bw4", word: "ненавижу", severity: "WARN" },
      { id: "bw5", word: "тупой", severity: "AUTO_HIDE" },
      { id: "bw6", word: "заткнись", severity: "AUTO_HIDE" },
      { id: "bw7", word: "отстой", severity: "WARN" },
      { id: "bw8", word: "лох", severity: "WARN" },
    ],
    reflections: [
      { id: "rf1", userId: "s1", type: "learned", at: d(1, 2), text: "Узнала, как вежливо заказать еду: «I'd like…» и «Could I have…». Ещё помогала Вере с временами." },
      { id: "rf2", userId: "s1", type: "hard", at: d(1, 2), text: "Путаю «some» и «any» в вопросах. Надо потренироваться." },
      { id: "rf3", userId: "s2", type: "learned", at: d(2, 4), text: "Выучил 10 новых слов по теме «Кафе». В квесте был переводчиком — оказалось сложно, но круто." },
      { id: "rf4", userId: "s3", type: "improve", at: d(3, 5), text: "Хочу писать короче и проще: сначала главное, потом детали." },
      { id: "rf5", userId: "s7", type: "learned", at: d(0, 3), text: "Дописали общее письмо в Лондон! Я добавила концовку и подписи всех ребят." },
      { id: "rf6", userId: "s11", type: "learned", at: d(1, 4), text: "Научилась говорить «opposite» и «between» — описывала нашу школу для видеооткрытки." },
    ],
    checklists: [
      { userId: "s1", updatedAt: d(1, 1), items: { cd1: 2, cd2: 2, cd3: 1, cd4: 2, cd5: 1, cd6: 0 } },
      { userId: "s2", updatedAt: d(2, 2), items: { cd1: 2, cd2: 1, cd3: 1, cd4: 0, cd5: 1, cd6: 1 } },
      { userId: "s3", updatedAt: d(3, 3), items: { cd1: 1, cd2: 1, cd3: 0, cd4: 1, cd5: 0, cd6: 0 } },
    ],
    canDoList: [
      { id: "cd1", text: "Я могу представиться и рассказать о себе", cefr: "A1" },
      { id: "cd2", text: "Я могу заказать еду в кафе", cefr: "A2" },
      { id: "cd3", text: "Я могу описать свой обычный день", cefr: "A2" },
      { id: "cd4", text: "Я могу написать короткое сообщение другу", cefr: "A2" },
      { id: "cd5", text: "Я понимаю простые объявления и вывески", cefr: "A2" },
      { id: "cd6", text: "Я могу спросить и понять дорогу", cefr: "A2" },
    ],
  };
}
