import { useState } from "react";
import { useApp } from "../lib/store";
import { levelFromPoints, pointsOf } from "../lib/logic";
import { Button, Chip, Icon, INPUT_CLS, Reveal, SectionTitle } from "../components/ui";

export function AdminView() {
  const { db, me, resetDemo, toast } = useApp();
  const [confirmReset, setConfirmReset] = useState(false);
  if (!me || me.role !== "ADMIN") return null;

  const teachers = db.users.filter((u) => u.role === "TEACHER");
  const students = db.users.filter((u) => u.role === "STUDENT");

  const exportJson = () => {
    const blob = new Blob([JSON.stringify(db, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "linguasocial-snapshot.json";
    a.click();
    URL.revokeObjectURL(url);
    toast("Снимок данных выгружен");
  };

  return (
    <div className="flex flex-col gap-6">
      <Reveal>
        <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
          {[
            { label: "Учителей", value: teachers.length, icon: "users", tone: "text-pine" },
            { label: "Учеников", value: students.length, icon: "home", tone: "text-amber" },
            { label: "Групп", value: db.groups.length, icon: "chat", tone: "text-sky" },
            { label: "Записей в ledger", value: db.ledger.length, icon: "trophy", tone: "text-berry" },
          ].map((s, i) => (
            <div key={s.label} className={`card-hover rounded-xl border border-line bg-card p-4 anim-fade-up`} style={{ animationDelay: `${i * 60}ms` }}>
              <Icon name={s.icon as import("../components/ui").IconName} size={18} className={s.tone} />
              <p className="mt-2 font-display text-2xl font-black text-ink">{s.value}</p>
              <p className="text-[11.5px] font-semibold text-ink-3">{s.label}</p>
            </div>
          ))}
        </div>
      </Reveal>

      <div className="grid gap-6 lg:grid-cols-2">
        {/* -------- статистика бейджей -------- */}
        <Reveal>
          <section>
            <SectionTitle kicker="автоматическое начисление" title="Бейджи" right={<Chip tone="ink">{db.badges.length} доступно</Chip>} />
            <div className="rounded-xl border border-line bg-card">
              {db.badges.map((badge) => {
                const earnedCount = db.studentBadges.filter((sb) => sb.badgeId === badge.id).length;
                return (
                  <div key={badge.id} className="flex items-center gap-3 border-b border-line/60 px-4 py-3 last:border-0">
                    <span className="grid h-9 w-9 shrink-0 place-items-center rounded-full text-xl" style={{ background: "var(--color-amber-soft)" }}>
                      {badge.iconUrl}
                    </span>
                    <div className="min-w-0 flex-1 leading-tight">
                      <p className="text-[13px] font-bold text-ink">{badge.title}</p>
                      <p className="text-[11.5px] text-ink-3">{badge.description}</p>
                    </div>
                    <Chip tone="green">{earnedCount} получено</Chip>
                  </div>
                );
              })}
            </div>
            <p className="mt-2 text-[12px] text-ink-2">Бейджи начисляются автоматически по правилам в mechanics.ts — легко добавлять новые.</p>
          </section>
        </Reveal>

        <div className="flex flex-col gap-6">
          {/* -------- структура -------- */}
          <Reveal delay={70}>
            <section>
              <SectionTitle kicker="структура платформы" title="Группы и учителя" />
              <div className="flex flex-col gap-3">
                {db.groups.map((g) => {
                  const t = db.users.find((u) => u.id === g.teacherId);
                  const members = students.filter((s) => s.classGroupId === g.id);
                  const avg = members.length ? Math.round(members.reduce((s, m) => s + pointsOf(db, m.id), 0) / members.length) : 0;
                  return (
                    <div key={g.id} className="card-hover rounded-xl border border-line bg-card p-4">
                      <div className="flex items-center justify-between gap-2">
                        <p className="font-display text-[15px] font-bold text-ink">{g.name}</p>
                        <Chip tone="green">уровень группы ≈ {levelFromPoints(avg).short}</Chip>
                      </div>
                      <p className="mt-1 text-[12.5px] text-ink-2">
                        Куратор: <b className="text-ink">{t?.fullName}</b> · {members.length} учеников · {avg} б. в среднем
                      </p>
                    </div>
                  );
                })}
              </div>
            </section>
          </Reveal>

          {/* -------- данные -------- */}
          <Reveal delay={130}>
            <section>
              <SectionTitle kicker="данные демо-среды" title="Снимок и сброс" />
              <div className="rounded-xl border border-line bg-card p-4">
                <div className="flex flex-wrap gap-2">
                  <Button variant="soft" onClick={exportJson}><Icon name="doc" size={14} /> Экспорт JSON</Button>
                  {!confirmReset ? (
                    <Button variant="ghost" onClick={() => setConfirmReset(true)}><Icon name="refresh" size={14} /> Сбросить демо</Button>
                  ) : (
                    <Button variant="danger" onClick={() => { resetDemo(); setConfirmReset(false); toast("Демо-данные восстановлены из сида"); }}>
                      <Icon name="alert" size={14} /> Точно сбросить?
                    </Button>
                  )}
                </div>
                <p className="mt-3 text-[12px] leading-relaxed text-ink-3">
                  Сброс возвращает сид: 12 учеников, 3 недели истории PointsLedger, очередь модерации
                  с одним автоскрытым сообщением. Ledger и SafetyLog в реальной системе append-only —
                  здесь сброс имитирует развёртывание свежей БД.
                </p>
              </div>
            </section>
          </Reveal>
        </div>
      </div>
    </div>
  );
}
