import { useApp } from "../../lib/store";
import { Button, Chip, Icon, Reveal, SectionTitle } from "../../components/ui";

type Nav = (r: string) => void;

export function SelfAssessmentOverview({ navigate }: { navigate: Nav }) {
  const { db, me } = useApp();

  if (!me) return null;

  const course = db.courses[0];
  if (!course) {
    return (
      <div className="py-16 text-center">
        <Icon name="alert" size={48} className="mx-auto text-ink-3" />
        <p className="mt-4 font-display text-lg font-bold text-ink">Курсы не найдены</p>
        <Button className="mt-4" onClick={() => navigate("student/courses")}>К курсам</Button>
      </div>
    );
  }

  // Статистика по самооценкам
  const totalChecklists = db.selfAssessmentChecklists.length;
  const completedChecklists = db.selfAssessmentChecklists.filter((checklist) => {
    const responses = db.selfAssessmentResponses.filter(
      (r) => r.studentId === me.id && r.checklistId === checklist.id
    );
    return responses.length > 0;
  }).length;

  // Статистика по дневнику
  const totalDiaryEntries = db.diaryEntries.filter((e) => e.studentId === me.id).length;
  const thisWeekEntries = db.diaryEntries.filter((e) => {
    const entryDate = new Date(e.createdAt);
    const weekAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
    return e.studentId === me.id && entryDate >= weekAgo;
  }).length;

  return (
    <div className="flex flex-col gap-6">
      <SectionTitle
        kicker="модуль reflection · самооценка и рефлексия"
        title="Моя рефлексия"
        right={<Chip tone="green">{completedChecklists}/{totalChecklists} самооценок</Chip>}
      />

      {/* Общая статистика */}
      <div className="grid gap-4 md:grid-cols-3">
        <Reveal>
          <div className="rounded-xl border border-line bg-card p-5">
            <div className="mb-2 flex items-center gap-2">
              <Icon name="check" size={20} className="text-sky" />
              <span className="font-display text-lg font-bold text-ink">Самооценки</span>
            </div>
            <p className="text-3xl font-black text-sky">{completedChecklists}</p>
            <p className="text-[12px] text-ink-3">из {totalChecklists} юнитов</p>
          </div>
        </Reveal>

        <Reveal delay={50}>
          <div className="rounded-xl border border-line bg-card p-5">
            <div className="mb-2 flex items-center gap-2">
              <Icon name="pen" size={20} className="text-amber" />
              <span className="font-display text-lg font-bold text-ink">Дневник</span>
            </div>
            <p className="text-3xl font-black text-amber">{totalDiaryEntries}</p>
            <p className="text-[12px] text-ink-3">записей ({thisWeekEntries} за неделю)</p>
          </div>
        </Reveal>

        <Reveal delay={100}>
          <div className="rounded-xl border border-line bg-card p-5">
            <div className="mb-2 flex items-center gap-2">
              <Icon name="trophy" size={20} className="text-pine" />
              <span className="font-display text-lg font-bold text-ink">Прогресс</span>
            </div>
            <p className="text-3xl font-black text-pine">
              {totalChecklists > 0 ? Math.round((completedChecklists / totalChecklists) * 100) : 0}%
            </p>
            <p className="text-[12px] text-ink-3">самооценок пройдено</p>
          </div>
        </Reveal>
      </div>

      {/* Быстрые действия */}
      <Reveal delay={150}>
        <div className="rounded-xl border border-line bg-card p-5">
          <h3 className="mb-4 font-display text-[15px] font-bold text-ink">Быстрые действия</h3>
          <div className="grid gap-3 md:grid-cols-3">
            <button
              onClick={() => navigate("student/diary")}
              className="flex flex-col items-start gap-2 rounded-xl border-2 border-line p-4 text-left transition hover:border-amber hover:bg-amber-soft/30"
            >
              <span className="text-3xl">📝</span>
              <span className="font-display text-[14px] font-bold text-ink">Записать в дневник</span>
              <span className="text-[12px] text-ink-3">Что узнал, что было сложно, что улучшу</span>
            </button>

            <button
              onClick={() => navigate("student/dashboard/progress")}
              className="flex flex-col items-start gap-2 rounded-xl border-2 border-line p-4 text-left transition hover:border-pine hover:bg-pine-soft/30"
            >
              <span className="text-3xl">📊</span>
              <span className="font-display text-[14px] font-bold text-ink">Мой прогресс</span>
              <span className="text-[12px] text-ink-3">Графики, статистика, достижения</span>
            </button>

            <button
              onClick={() => navigate("student/courses")}
              className="flex flex-col items-start gap-2 rounded-xl border-2 border-line p-4 text-left transition hover:border-sky hover:bg-sky-soft/30"
            >
              <span className="text-3xl">✅</span>
              <span className="font-display text-[14px] font-bold text-ink">Пройти самооценку</span>
              <span className="text-[12px] text-ink-3">После завершения юнита</span>
            </button>
          </div>
        </div>
      </Reveal>

      {/* Список юнитов с самооценками */}
      <Reveal delay={200}>
        <div className="rounded-xl border border-line bg-card p-5">
          <h3 className="mb-4 font-display text-[15px] font-bold text-ink">Самооценки по юнитам</h3>
          <div className="flex flex-col gap-3">
            {course.units.map((unit) => {
              const checklist = db.selfAssessmentChecklists.find((c) => c.unitId === unit.id);
              if (!checklist) return null;

              const responses = db.selfAssessmentResponses.filter(
                (r) => r.studentId === me.id && r.checklistId === checklist.id
              );
              const completed = responses.length > 0;
              const checkedCount = responses.filter((r) => r.checked).length;
              const percentage = Math.round((checkedCount / checklist.items.length) * 100);

              return (
                <div
                  key={unit.id}
                  className={`rounded-xl border-2 p-4 transition ${
                    completed ? "border-pine/30 bg-pine-soft/30" : "border-line hover:border-sky/50"
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <span
                        className={`grid h-10 w-10 place-items-center rounded-xl ${
                          completed ? "bg-pine text-white" : "bg-paper-2 text-ink-3"
                        }`}
                      >
                        {completed ? <Icon name="check" size={18} strokeWidth={3} /> : unit.order}
                      </span>
                      <div>
                        <p className="font-display text-[14px] font-bold text-ink">{unit.title}</p>
                        <p className="text-[11px] text-ink-3">
                          {unit.cefrLevel} · {checklist.items.length} пунктов самооценки
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      {completed && (
                        <div className="text-right">
                          <p className="text-[14px] font-black text-pine">{percentage}%</p>
                          <p className="text-[10px] text-ink-3">
                            {checkedCount}/{checklist.items.length}
                          </p>
                        </div>
                      )}
                      <Button
                        size="sm"
                        variant={completed ? "ghost" : "primary"}
                        onClick={() => navigate(`student/units/${unit.id}/self-assessment`)}
                      >
                        {completed ? "Перепройти" : "Пройти"}
                      </Button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </Reveal>

      {/* Последние записи в дневнике */}
      {totalDiaryEntries > 0 && (
        <Reveal delay={250}>
          <div className="rounded-xl border border-line bg-card p-5">
            <div className="mb-4 flex items-center justify-between">
              <h3 className="font-display text-[15px] font-bold text-ink">Последние записи в дневнике</h3>
              <Button variant="ghost" size="sm" onClick={() => navigate("student/diary")}>
                Все записи <Icon name="arrowRight" size={12} />
              </Button>
            </div>
            <div className="flex flex-col gap-3">
              {db.diaryEntries
                .filter((e) => e.studentId === me.id)
                .sort((a, b) => b.createdAt - a.createdAt)
                .slice(0, 3)
                .map((entry) => {
                  const promptInfo = {
                    WHAT_LEARNED: { icon: "💡", color: "bg-pine-soft text-pine-deep", label: "Что узнал" },
                    WHAT_WAS_HARD: { icon: "🎯", color: "bg-amber-soft text-[#8a5a10]", label: "Что было сложно" },
                    WHAT_TO_IMPROVE: { icon: "🚀", color: "bg-sky-soft text-[#275d7e]", label: "Что улучшу" },
                  }[entry.promptType];
                  return (
                    <div key={entry.id} className="rounded-lg border border-line bg-paper p-3">
                      <div className="mb-1 flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <span className="text-xl">{promptInfo.icon}</span>
                          <span className={`rounded-full px-2 py-0.5 text-[10px] font-bold ${promptInfo.color}`}>
                            {promptInfo.label}
                          </span>
                        </div>
                        <span className="text-[11px] text-ink-3">
                          {new Date(entry.createdAt).toLocaleDateString("ru-RU", {
                            day: "numeric",
                            month: "short",
                          })}
                        </span>
                      </div>
                      <p className="text-[12px] leading-relaxed text-ink-2">{entry.content}</p>
                    </div>
                  );
                })}
            </div>
          </div>
        </Reveal>
      )}
    </div>
  );
}
