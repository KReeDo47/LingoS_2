/* ============================================================
   Модуль users · unit-тесты Zod-валидации
   Запуск: npx vitest run
   Ключевое правило QWEN.md: создание ученика БЕЗ согласия
   законного представителя должно быть невозможно.
   ============================================================ */
import { describe, expect, it } from "vitest";
import {
  changePasswordSchema,
  createStudentSchema,
  generateTempPassword,
  hashPassword,
  loginSchema,
  parseWith,
  registerSchema,
} from "./validation";

const validInput = {
  displayName: "Аня",
  fullName: "Иванова Анна Сергеевна",
  email: "anya@lingua.school",
  classGroupId: "g1",
  cefr: "A2" as const,
  consentGiven: true,
  consentGivenBy: "Иванова Светлана Петровна",
};

describe("createStudentSchema — создание ученика (QWEN.md, модуль users)", () => {
  it("валидный ввод с согласием проходит схему", () => {
    expect(createStudentSchema.safeParse(validInput).success).toBe(true);
  });

  it("БЕЗ согласия законного представителя (consentGiven=false) создать ученика НЕЛЬЗЯ", () => {
    const res = createStudentSchema.safeParse({ ...validInput, consentGiven: false });
    expect(res.success).toBe(false);
    if (!res.success) {
      const issues = res.error.flatten().fieldErrors.consentGiven ?? [];
      expect(issues.length).toBeGreaterThan(0);
      expect(issues.join(" ")).toMatch(/согласи/i);
    }
  });

  it("consentGiven отсутствует вовсе (undefined) → отказ", () => {
    const { consentGiven: _omit, ...rest } = validInput;
    const res = createStudentSchema.safeParse(rest);
    expect(res.success).toBe(false);
  });

  it("галочка есть, но не указано, КТО дал согласие → отказ", () => {
    expect(createStudentSchema.safeParse({ ...validInput, consentGivenBy: "  " }).success).toBe(false);
  });

  it("отклоняет слишком короткий displayName и неполное ФИО", () => {
    expect(createStudentSchema.safeParse({ ...validInput, displayName: "Я" }).success).toBe(false);
    expect(createStudentSchema.safeParse({ ...validInput, fullName: "Аня" }).success).toBe(false);
  });

  it("отклоняет некорректный email и пустую группу", () => {
    expect(createStudentSchema.safeParse({ ...validInput, email: "не-email" }).success).toBe(false);
    expect(createStudentSchema.safeParse({ ...validInput, classGroupId: "" }).success).toBe(false);
  });

  it("parseWith возвращает ошибки по полям — их показывает форма «Добавить ученика»", () => {
    const res = parseWith(createStudentSchema, { ...validInput, consentGiven: false });
    expect(res.ok).toBe(false);
    if (!res.ok) {
      expect(res.errors.consentGiven?.[0]).toBeTruthy();
    }
  });
});

describe("registerSchema — прямая регистрация учителя/админа", () => {
  const base = {
    fullName: "Соколова Мария Викторовна",
    displayName: "Мария Викторовна",
    email: "marina@school.ru",
    password: "secret123",
    confirm: "secret123",
    role: "TEACHER" as const,
  };
  it("учитель регистрируется напрямую", () => {
    expect(registerSchema.safeParse(base).success).toBe(true);
  });
  it("роль STUDENT недоступна для саморегистрации", () => {
    expect(registerSchema.safeParse({ ...base, role: "STUDENT" }).success).toBe(false);
  });
  it("несовпадающие пароли отклоняются", () => {
    expect(registerSchema.safeParse({ ...base, confirm: "другой" }).success).toBe(false);
  });
});

describe("loginSchema и смена пароля", () => {
  it("loginSchema требует email и пароль", () => {
    expect(loginSchema.safeParse({ email: "a@b.c", password: "x" }).success).toBe(true);
    expect(loginSchema.safeParse({ email: "nope", password: "x" }).success).toBe(false);
    expect(loginSchema.safeParse({ email: "a@b.c", password: "" }).success).toBe(false);
  });
  it("changePasswordSchema: минимум 6 символов и совпадение", () => {
    expect(changePasswordSchema.safeParse({ password: "newpass1", confirm: "newpass1" }).success).toBe(true);
    expect(changePasswordSchema.safeParse({ password: "12345", confirm: "12345" }).success).toBe(false);
    expect(changePasswordSchema.safeParse({ password: "newpass1", confirm: "newpass2" }).success).toBe(false);
  });
});

describe("временный пароль и хэш", () => {
  it("generateTempPassword: формат ling-xxxxxx без неоднозначных символов", () => {
    for (let i = 0; i < 20; i++) {
      expect(generateTempPassword()).toMatch(/^ling-[a-hjkmnp-z2-9]{6}$/);
    }
  });
  it("generateTempPassword детерминирован при фиксированном rand", () => {
    const seq = [0.1, 0.42, 0.77, 0.05, 0.9, 0.33];
    const mk = () => {
      let i = 0;
      return () => seq[i++ % seq.length];
    };
    expect(generateTempPassword(mk())).toBe(generateTempPassword(mk()));
  });
  it("hashPassword: стабилен для пароля и различен для разных паролей", () => {
    expect(hashPassword("demo123")).toBe(hashPassword("demo123"));
    expect(hashPassword("demo123")).not.toBe(hashPassword("demo124"));
  });
});
