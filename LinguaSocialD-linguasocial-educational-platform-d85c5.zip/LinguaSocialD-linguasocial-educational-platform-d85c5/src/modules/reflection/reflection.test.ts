/* ============================================================
   Модуль reflection · unit-тесты
   Запуск: npx vitest run src/modules/reflection/reflection.test.ts
   ============================================================ */
import { describe, expect, it } from "vitest";
import type { DB, DiaryEntry, DiaryPromptType, User } from "../../lib/types";

const mkUser = (id: string, classGroupId: string | null = "g1", role: User["role"] = "STUDENT"): User => ({
  id,
  role,
  email: `${id}@test.io`,
  passwordHash: "x",
  fullName: `Полное Имя ${id}`,
  displayName: id.toUpperCase(),
  showAvatar: true,
  mustChangePassword: false,
  hue: 100,
  classGroupId,
  cefr: "A2",
  lastActiveAt: Date.now(),
  createdAt: Date.now(),
});

const mkDB = (overrides: Partial<DB> = {}): DB => ({
  version: 5,
  sessionId: null,
  users: [],
  groups: [],
  consents: [],
  courses: [],
  progress: [],
  ledger: [],
  badges: [],
  studentBadges: [],
  challenges: [],
  challengeResults: [],
  mentorRoles: [],
  tandems: [],
  quests: [],
  docs: [],
  docRevisions: [],
  submissions: [],
  peerReviews: [],
  messages: [],
  queue: [],
  safetyLog: [],
  reflections: [],
  diaryEntries: [],
  selfAssessmentChecklists: [],
  selfAssessmentResponses: [],
  feedbackNotes: [],
  checklists: [],
  canDoList: [],
  contentFlags: [],
  bannedWords: [],
  ...overrides,
});

describe("Модуль reflection · валидация дневника", () => {
  it("можно писать не более одной записи каждого типа в день", () => {
    const today = new Date().toISOString().split('T')[0];
    const db = mkDB({
      users: [mkUser("s1")],
      diaryEntries: [
        {
          id: "de1",
          studentId: "s1",
          date: today,
          promptType: "WHAT_LEARNED",
          content: "Первая запись",
          createdAt: Date.now(),
        },
      ],
    });

    // Проверяем, что для WHAT_LEARNED уже есть запись сегодня
    const todayEntries = db.diaryEntries.filter((e) => e.studentId === "s1" && e.date === today);
    const hasLearned = todayEntries.some((e) => e.promptType === "WHAT_LEARNED");
    const hasHard = todayEntries.some((e) => e.promptType === "WHAT_WAS_HARD");
    const hasImprove = todayEntries.some((e) => e.promptType === "WHAT_TO_IMPROVE");

    expect(hasLearned).toBe(true);
    expect(hasHard).toBe(false);
    expect(hasImprove).toBe(false);
  });

  it("можно писать разные типы записей в один день", () => {
    const today = new Date().toISOString().split('T')[0];
    const db = mkDB({
      users: [mkUser("s1")],
      diaryEntries: [
        {
          id: "de1",
          studentId: "s1",
          date: today,
          promptType: "WHAT_LEARNED",
          content: "Узнал новое",
          createdAt: Date.now(),
        },
        {
          id: "de2",
          studentId: "s1",
          date: today,
          promptType: "WHAT_WAS_HARD",
          content: "Было сложно",
          createdAt: Date.now() + 1000,
        },
      ],
    });

    const todayEntries = db.diaryEntries.filter((e) => e.studentId === "s1" && e.date === today);
    expect(todayEntries).toHaveLength(2);
  });

  it("можно писать те же типы записей на следующий день", () => {
    const yesterday = new Date(Date.now() - 86400000).toISOString().split('T')[0];
    const today = new Date().toISOString().split('T')[0];
    const db = mkDB({
      users: [mkUser("s1")],
      diaryEntries: [
        {
          id: "de1",
          studentId: "s1",
          date: yesterday,
          promptType: "WHAT_LEARNED",
          content: "Вчерашняя запись",
          createdAt: Date.now() - 86400000,
        },
      ],
    });

    const todayEntries = db.diaryEntries.filter((e) => e.studentId === "s1" && e.date === today);
    expect(todayEntries).toHaveLength(0);
  });
});

describe("Модуль reflection · самооценка", () => {
  it("самооценка привязана к unitId через checklistId", () => {
    const db = mkDB({
      users: [mkUser("s1")],
      selfAssessmentChecklists: [
        { id: "sac1", unitId: "u1", items: ["I can introduce myself", "I can ask names"] },
        { id: "sac2", unitId: "u2", items: ["I can order food", "I can ask for bill"] },
      ],
      selfAssessmentResponses: [
        { studentId: "s1", checklistId: "sac1", itemIndex: 0, checked: true, respondedAt: Date.now() },
        { studentId: "s1", checklistId: "sac1", itemIndex: 1, checked: false, respondedAt: Date.now() },
      ],
    });

    const checklist1 = db.selfAssessmentChecklists.find((c) => c.id === "sac1");
    const checklist2 = db.selfAssessmentChecklists.find((c) => c.id === "sac2");

    expect(checklist1?.unitId).toBe("u1");
    expect(checklist2?.unitId).toBe("u2");

    const responses1 = db.selfAssessmentResponses.filter((r) => r.checklistId === "sac1");
    expect(responses1).toHaveLength(2);
    expect(responses1.filter((r) => r.checked)).toHaveLength(1);
  });

  it("новая самооценка заменяет предыдущую для того же checklist", () => {
    const db = mkDB({
      users: [mkUser("s1")],
      selfAssessmentChecklists: [
        { id: "sac1", unitId: "u1", items: ["I can introduce myself"] },
      ],
      selfAssessmentResponses: [
        { studentId: "s1", checklistId: "sac1", itemIndex: 0, checked: false, respondedAt: Date.now() - 1000 },
      ],
    });

    // Имитация новой самооценки
    const newResponses = [
      { studentId: "s1", checklistId: "sac1", itemIndex: 0, checked: true, respondedAt: Date.now() },
    ];

    db.selfAssessmentResponses = [
      ...db.selfAssessmentResponses.filter((r) => !(r.studentId === "s1" && r.checklistId === "sac1")),
      ...newResponses,
    ];

    const responses = db.selfAssessmentResponses.filter((r) => r.checklistId === "sac1");
    expect(responses).toHaveLength(1);
    expect(responses[0].checked).toBe(true);
  });
});

describe("Модуль reflection · обратная связь", () => {
  it("FeedbackNote содержит два структурированных поля", () => {
    const db = mkDB({
      feedbackNotes: [
        {
          id: "fn1",
          taskSubmissionId: "sub1",
          authorId: "u-t1",
          whatWentWell: "Отличная структура текста",
          whatToImprove: "Обратите внимание на грамматику",
          createdAt: Date.now(),
        },
      ],
    });

    const note = db.feedbackNotes[0];
    expect(note.whatWentWell).toBe("Отличная структура текста");
    expect(note.whatToImprove).toBe("Обратите внимание на грамматику");
  });

  it("обратная связь привязана к taskSubmissionId", () => {
    const db = mkDB({
      feedbackNotes: [
        {
          id: "fn1",
          taskSubmissionId: "sub1",
          authorId: "u-t1",
          whatWentWell: "Хорошо",
          whatToImprove: "Улучшить",
          createdAt: Date.now(),
        },
        {
          id: "fn2",
          taskSubmissionId: "sub2",
          authorId: "u-t1",
          whatWentWell: "Отлично",
          whatToImprove: "Детали",
          createdAt: Date.now(),
        },
      ],
    });

    const notesForSub1 = db.feedbackNotes.filter((n) => n.taskSubmissionId === "sub1");
    expect(notesForSub1).toHaveLength(1);
  });
});

describe("Модуль reflection · настройки группы", () => {
  it("ClassGroup содержит флаг diaryVisibleToTeacher", () => {
    const db = mkDB({
      groups: [
        { id: "g1", name: "7 «А»", teacherId: "u-t1", organizationName: "Школа № 17", diaryVisibleToTeacher: false },
        { id: "g2", name: "5 «Б»", teacherId: "u-t2", organizationName: "Школа № 17", diaryVisibleToTeacher: true },
      ],
    });

    const group1 = db.groups.find((g) => g.id === "g1");
    const group2 = db.groups.find((g) => g.id === "g2");

    expect(group1?.diaryVisibleToTeacher).toBe(false);
    expect(group2?.diaryVisibleToTeacher).toBe(true);
  });

  it("учитель видит только факт заполнения дневника, если diaryVisibleToTeacher = false", () => {
    const db = mkDB({
      groups: [
        { id: "g1", name: "7 «А»", teacherId: "u-t1", organizationName: "Школа № 17", diaryVisibleToTeacher: false },
      ],
      users: [mkUser("s1", "g1")],
      diaryEntries: [
        {
          id: "de1",
          studentId: "s1",
          date: new Date().toISOString().split('T')[0],
          promptType: "WHAT_LEARNED",
          content: "Секретный контент",
          createdAt: Date.now(),
        },
      ],
    });

    const group = db.groups.find((g) => g.id === "g1");
    const studentEntries = db.diaryEntries.filter((e) => e.studentId === "s1");

    // Учитель может видеть количество записей
    expect(studentEntries.length).toBe(1);

    // Но если diaryVisibleToTeacher = false, содержимое скрыто
    if (!group?.diaryVisibleToTeacher) {
      // В реальном UI здесь будет проверка флага
      expect(group?.diaryVisibleToTeacher).toBe(false);
    }
  });
});
