import { useState } from "react";
import { useApp } from "../../lib/store";
import { Button, Chip, Icon, INPUT_CLS, Reveal, SectionTitle } from "../../components/ui";
import type { DiaryPromptType } from "../../lib/types";

type Nav = (r: string) => void;

const PROMPTS: { type: DiaryPromptType; title: string; icon: string; description: string; color: string }[] = [
  {
    type: "WHAT_LEARNED",
    title: "Что я узнал(а)?",
    icon: "💡",
    description: "Новые знания, навыки, открытия",
    color: "bg-pine-soft text-pine-deep",
  },
  {
    type: "WHAT_WAS_HARD",
    title: "Что было сложным?",
    icon: "🎯",
    description: "Трудности, вопросы, проблемы",
    color: "bg-amber-soft text-[#8a5a10]",
  },
  {
    type: "WHAT_TO_IMPROVE",
    title: "Что я улучшу?",
    icon: "🚀",
    description: "Планы, цели, следующие шаги",
    color: "bg-sky-soft text-[#275d7e]",
  },
];

export function DiaryPage({ navigate }: { navigate: Nav }) {
  const { db, me, addDiaryEntry, toast } = useApp();
  const [selectedPrompt, setSelectedPrompt] = useState<DiaryPromptType | null>(null);
  const [content, setContent] = useState("");

  if (!me) return null;

  const today = new Date().toISOString().split('T')[0];
  const todayEntries = db.diaryEntries.filter((e) => e.studentId === me.id && e.date === today);
  const allEntries = db.diaryEntries
    .filter((e) => e.studentId === me.id)
    .sort((a, b) => b.createdAt - a.createdAt);

  const canWrite = (type: DiaryPromptType) => {
    return !todayEntries.some((e) => e.promptType === type);
  };

  const handleSubmit = () => {
    if (!selectedPrompt || !content.trim()) {
      toast("Заполните содержание записи", "warn");
      return;
    }

    addDiaryEntry(selectedPrompt, content.trim());
    toast("Запись добавлена в дневник");
    setSelectedPrompt(null);
    setContent("");
  };

  const getPromptInfo = (type: DiaryPromptType) => PROMPTS.find((p) => p.type === type)!;

  return (
    <div className="flex flex-col gap-6">
      <SectionTitle
        kicker="модуль reflection · диагностико-рефлексивный блок"
        title="Мой дневник"
        right={<Chip tone="green">{allEntries.length} записей</Chip>}
      />

      {/* Форма добавления записи */}
      {!selectedPrompt ? (
        <Reveal>
          <div className="rounded-xl border border-line bg-card p-5">
            <h3 className="mb-4 font-display text-lg font-bold text-ink">Выберите тип записи на сегодня</h3>
            <div className="grid gap-3 md:grid-cols-3">
              {PROMPTS.map((prompt) => {
                const canWriteToday = canWrite(prompt.type);
                return (
                  <button
                    key={prompt.type}
                    onClick={() => canWriteToday && setSelectedPrompt(prompt.type)}
                    disabled={!canWriteToday}
                    className={`flex flex-col items-start gap-2 rounded-xl border-2 p-4 text-left transition ${
                      canWriteToday
                        ? "cursor-pointer border-line hover:border-pine hover:bg-pine-soft/30"
                        : "cursor-not-allowed border-line/50 bg-paper-2/50 opacity-50"
                    }`}
                  >
                    <span className="text-3xl">{prompt.icon}</span>
                    <span className="font-display text-[14px] font-bold text-ink">{prompt.title}</span>
                    <span className="text-[12px] text-ink-3">{prompt.description}</span>
                    {!canWriteToday && (
                      <Chip tone="ink" className="mt-1">
                        <Icon name="check" size={11} /> Уже записано сегодня
                      </Chip>
                    )}
                  </button>
                );
              })}
            </div>
            <p className="mt-3 text-[12px] text-ink-3">
              💡 Можно писать не более одной записи каждого типа в день
            </p>
          </div>
        </Reveal>
      ) : (
        <Reveal>
          <div className="rounded-xl border-2 border-pine/30 bg-card p-5">
            <div className="mb-4 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <span className="text-3xl">{getPromptInfo(selectedPrompt).icon}</span>
                <div>
                  <h3 className="font-display text-lg font-bold text-ink">{getPromptInfo(selectedPrompt).title}</h3>
                  <p className="text-[12px] text-ink-3">{getPromptInfo(selectedPrompt).description}</p>
                </div>
              </div>
              <Button variant="ghost" size="sm" onClick={() => { setSelectedPrompt(null); setContent(""); }}>
                <Icon name="x" size={14} /> Отмена
              </Button>
            </div>
            <textarea
              className={`${INPUT_CLS} min-h-[120px]`}
              placeholder="Напишите ваши мысли..."
              value={content}
              onChange={(e) => setContent(e.target.value)}
              autoFocus
            />
            <div className="mt-3 flex items-center justify-between">
              <span className="text-[12px] text-ink-3">{content.length} символов</span>
              <Button onClick={handleSubmit} disabled={!content.trim()}>
                <Icon name="check" size={14} /> Сохранить запись
              </Button>
            </div>
          </div>
        </Reveal>
      )}

      {/* История записей */}
      {allEntries.length > 0 && (
        <Reveal delay={100}>
          <div>
            <h3 className="mb-3 font-display text-[15px] font-bold text-ink">История дневника</h3>
            <div className="flex flex-col gap-3">
              {allEntries.map((entry) => {
                const prompt = getPromptInfo(entry.promptType);
                return (
                  <div key={entry.id} className="rounded-xl border border-line bg-card p-4">
                    <div className="mb-2 flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="text-2xl">{prompt.icon}</span>
                        <span className={`rounded-full px-2.5 py-0.5 text-[11px] font-bold ${prompt.color}`}>
                          {prompt.title}
                        </span>
                      </div>
                      <span className="text-[11px] text-ink-3">
                        {new Date(entry.createdAt).toLocaleDateString("ru-RU", { day: "numeric", month: "long", year: "numeric" })}
                      </span>
                    </div>
                    <p className="text-[13px] leading-relaxed text-ink-2">{entry.content}</p>
                  </div>
                );
              })}
            </div>
          </div>
        </Reveal>
      )}
    </div>
  );
}
