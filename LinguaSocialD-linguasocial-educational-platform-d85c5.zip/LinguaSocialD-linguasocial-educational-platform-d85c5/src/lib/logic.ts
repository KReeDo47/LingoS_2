import type {
  CEFR,
  DB,
  GroupQuest,
  PairedReason,
  PeerReview,
  ReflectionType,
  Role,
  StudentProgress,
  User,
} from "./types";

let counter = 0;
export function uid(prefix: string): string {
  counter += 1;
  return `${prefix}-${Date.now().toString(36)}-${counter}-${Math.random().toString(36).slice(2, 6)}`;
}

export const DAY = 86_400_000;
export const now = () => Date.now();

export function timeAgo(ts: number): string {
  const d = now() - ts;
  if (d < 60_000) return "только что";
  if (d < 3_600_000) return `${Math.floor(d / 60_000)} мин назад`;
  if (d < DAY) return `${Math.floor(d / 3_600_000)} ч назад`;
  const days = Math.floor(d / DAY);
  if (days === 1) return "вчера";
  return `${days} дн. назад`;
}

export function clockTime(ts: number): string {
  return new Date(ts).toLocaleTimeString("ru-RU", { hour: "2-digit", minute: "2-digit" });
}

export function dayKey(ts: number): string {
  const d = new Date(ts);
  return `${d.getFullYear()}-${d.getMonth()}-${d.getDate()}`;
}

export function sameDay(a: number, b: number): boolean {
  return dayKey(a) === dayKey(b);
}

export function initials(name: string): string {
  return name
    .split(/\s+/)
    .slice(0, 2)
    .map((w) => w[0] ?? "")
    .join("")
    .toUpperCase();
}

/* ============================================================
   МОДУЛЬ mechanics · чистые функции
   ============================================================ */

export const LEVELS = [
  { min: 0, name: "Росток слов", short: "Росток" },
  { min: 60, name: "Собиратель фраз", short: "Фразы" },
  { min: 150, name: "Строитель предложений", short: "Строитель" },
  { min: 300, name: "Архитектор текстов", short: "Архитектор" },
  { min: 520, name: "Мастер диалога", short: "Мастер" },
  { min: 800, name: "Знаток языка", short: "Знаток" },
  { min: 1150, name: "Хранитель LinguaSocial", short: "Хранитель" },
];

/** Расчётный уровень — чистая функция от суммы баллов */
export function levelFromPoints(points: number) {
  let index = 0;
  for (let i = 0; i < LEVELS.length; i++) if (points >= LEVELS[i].min) index = i;
  const cur = LEVELS[index];
  const next = LEVELS[index + 1] ?? null;
  const span = next ? next.min - cur.min : 1;
  const progress = next ? Math.min(1, (points - cur.min) / span) : 1;
  return { index, name: cur.name, short: cur.short, next, progress, levelNo: index + 1 };
}

export function pointsOf(db: DB, userId: string): number {
  return db.ledger.filter((e) => e.userId === userId).reduce((s, e) => s + e.points, 0);
}

export function weekPoints(db: DB, userId: string, weekOffset: number): number {
  const from = now() - (weekOffset + 1) * 7 * DAY;
  const to = now() - weekOffset * 7 * DAY;
  return db.ledger
    .filter((e) => e.userId === userId && e.at > from && e.at <= to)
    .reduce((s, e) => s + e.points, 0);
}

/** «Личный прогресс»: сравнение со своим прошлым (7 дней к предыдущим 7) */
export function growthInfo(db: DB, userId: string) {
  const cur = weekPoints(db, userId, 0);
  const prev = weekPoints(db, userId, 1);
  const pct = prev > 0 ? Math.round(((cur - prev) / prev) * 100) : cur > 0 ? 100 : 0;
  return { cur, prev, pct, delta: cur - prev };
}

export function personalRating(db: DB) {
  return db.users
    .filter((u) => u.role === "STUDENT")
    .map((u) => ({ user: u, total: pointsOf(db, u.id), ...growthInfo(db, u.id) }))
    .sort((a, b) => b.pct - a.pct || b.delta - a.delta);
}

/** Командный рейтинг — группы, НЕ единый публичный топ по классу */
export function teamRating(db: DB) {
  return db.groups
    .map((g) => {
      const members = db.users.filter((u) => u.classGroupId === g.id);
      const total = members.reduce((s, m) => s + pointsOf(db, m.id), 0);
      const week = members.reduce((s, m) => s + weekPoints(db, m.id, 0), 0);
      return { group: g, members: members.length, total, avg: members.length ? Math.round(total / members.length) : 0, week };
    })
    .sort((a, b) => b.avg - a.avg);
}

export function activeDaysStreak(db: DB, userId: string): number {
  const days = new Set(db.ledger.filter((e) => e.userId === userId).map((e) => dayKey(e.at)));
  let streak = 0;
  let cursor = now();
  if (!days.has(dayKey(cursor))) cursor -= DAY;
  while (days.has(dayKey(cursor))) {
    streak += 1;
    cursor -= DAY;
  }
  return streak;
}

/** Роль «языковой наставник»: проверяем mentorRoles */
export function isMentor(db: DB, userId: string): boolean {
  const role = db.mentorRoles.find((m) => m.studentId === userId);
  return role !== undefined && role.revokedAt === null;
}

/* ============================================================
   МОДУЛЬ social (QWEN.md, модуль 3) · тандемы по ZPD
   ============================================================ */

/** Средний score ученика по StudentProgress (модуль content) — база для ZPD-пар */
export function avgScoreFromProgress(progress: StudentProgress[], studentId: string): number {
  const scores = progress
    .filter((p) => p.studentId === studentId && p.status === "COMPLETED" && p.score !== null)
    .map((p) => p.score as number);
  if (!scores.length) return 0;
  return scores.reduce((s, v) => s + v, 0) / scores.length;
}

export interface TandemSuggestion {
  /** сильный партнёр */
  a: User;
  /** слабый партнёр */
  b: User;
  pairedReason: PairedReason;
  /** разница средних score — «ширина» зоны ближайшего развития */
  diff: number;
}

/**
 * Автоподбор пар «сильный + слабый» (ZPD_MENTOR) по среднему score
 * из StudentProgress: сортируем по убыванию и соединяем крайних.
 * При нечётном числе учеников средний остаётся без пары.
 */
export function suggestTandems(
  db: { users: User[]; progress: StudentProgress[] },
  classGroupId: string,
): TandemSuggestion[] {
  const students = db.users
    .filter((u) => u.role === "STUDENT" && u.classGroupId === classGroupId)
    .map((u) => ({ u, avg: avgScoreFromProgress(db.progress, u.id) }))
    .sort((x, y) => y.avg - x.avg || x.u.displayName.localeCompare(y.u.displayName, "ru"));
  const pairs: TandemSuggestion[] = [];
  for (let i = 0; i < Math.floor(students.length / 2); i++) {
    const strong = students[i];
    const weak = students[students.length - 1 - i];
    pairs.push({ a: strong.u, b: weak.u, pairedReason: "ZPD_MENTOR", diff: Math.round(strong.avg - weak.avg) });
  }
  return pairs;
}

export function questProgress(q: GroupQuest): number {
  const done = q.roles.filter((r) => r.done).length;
  return q.roles.length ? Math.round((done / q.roles.length) * 100) : 0;
}

export function reviewAverage(reviews: PeerReview[], submissionId: string): number | null {
  const own = reviews.filter((r) => r.taskSubmissionId === submissionId);
  if (!own.length) return null;
  const all = own.flatMap((r) => r.rubricScores.map((s) => s.value));
  return Math.round((all.reduce((s, v) => s + v, 0) / all.length) * 10) / 10;
}

export function daysLeft(deadline: number): number {
  return Math.ceil((deadline - Date.now()) / DAY);
}

/* ============================================================
   МОДУЛЬ users / moderation · видимость и фильтры
   ============================================================ */

/** fullName видят только TEACHER и ADMIN — применяется во всём UI */
export function canViewFullName(role: Role): boolean {
  return role === "TEACHER" || role === "ADMIN";
}

export function visibleName(viewerRole: Role, user: User): string {
  return canViewFullName(viewerRole) ? user.fullName : user.displayName;
}

export function filterText(text: string, stopwords: string[]): string[] {
  const lower = text.toLowerCase();
  return stopwords.filter((w) => w.trim() && lower.includes(w.trim().toLowerCase()));
}

export function inactiveStudents(db: DB, days = 7): { user: User; days: number }[] {
  return db.users
    .filter((u) => u.role === "STUDENT")
    .map((u) => ({ user: u, days: Math.floor((now() - u.lastActiveAt) / DAY) }))
    .filter((x) => x.days >= days)
    .sort((a, b) => b.days - a.days);
}

export function canWriteReflection(db: DB, userId: string, type: ReflectionType): boolean {
  return !db.reflections.some((r) => r.userId === userId && r.type === type && sameDay(r.at, now()));
}

export function studentById(db: DB, id: string | null | undefined): User | undefined {
  return db.users.find((u) => u.id === id);
}

export function groupById(db: DB, id: string | null | undefined) {
  return db.groups.find((g) => g.id === id);
}

export const CEFR_LABEL: Record<CEFR, string> = {
  A1: "A1 · Breakthrough",
  A2: "A2 · Waystage",
  B1: "B1 · Threshold",
  B2: "B2 · Vantage",
};

/* ============================================================
   МОДУЛЬ moderation · вспомогательные функции
   ============================================================ */

import type { BannedWord, ContentFlag, SafetyActionType, SafetyLogEntry } from "./types";

/**
 * Проверка текста на наличие запрещённых слов
 */
export function checkBannedWords(
  text: string,
  bannedWords: BannedWord[]
): { word: string; severity: BannedWord["severity"] }[] {
  const lowerText = text.toLowerCase();
  return bannedWords
    .filter((bw) => lowerText.includes(bw.word.toLowerCase()))
    .map((bw) => ({ word: bw.word, severity: bw.severity }));
}

/**
 * Создание записи в SafetyLog
 */
export function createSafetyLogEntry(
  actorId: string,
  actionType: SafetyActionType,
  targetType: string,
  targetId: string,
  reason: string
): SafetyLogEntry {
  return {
    id: uid("sl"),
    actorId,
    actionType,
    targetType,
    targetId,
    reason,
    createdAt: now(),
  };
}

/**
 * Создание ContentFlag
 */
export function createContentFlag(
  contentType: ContentFlag["contentType"],
  contentId: string,
  flaggedBy: string,
  flagReason: string
): ContentFlag {
  return {
    id: uid("cf"),
    contentType,
    contentId,
    flaggedBy,
    flagReason,
    status: "PENDING",
    createdAt: now(),
  };
}
