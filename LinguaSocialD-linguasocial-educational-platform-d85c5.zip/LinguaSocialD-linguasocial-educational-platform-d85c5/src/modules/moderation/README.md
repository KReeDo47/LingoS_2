# Модуль Moderation (QWEN.md, модуль 6)

Обеспечивает педагогический контроль и безопасность несовершеннолетних пользователей поверх всех остальных механик.

## Модели данных

### SafetyLogEntry (Журнал безопасности)
```typescript
interface SafetyLogEntry {
  id: string;
  actorId: string; // userId или "AUTO"
  actionType: "MESSAGE_HIDDEN" | "MESSAGE_DELETED" | "USER_WARNED" | "USER_SUSPENDED" | "CONTENT_FLAGGED";
  targetType: string; // "MESSAGE", "DIARY_ENTRY", "COLLAB_DOC", "USER"
  targetId: string;
  reason: string;
  createdAt: number;
}
```

**Важно:** Append-only журнал, никогда не удаляется. Все действия модерации записываются автоматически.

### ContentFlag (Флаг контента)
```typescript
interface ContentFlag {
  id: string;
  contentType: "MESSAGE" | "DIARY_ENTRY" | "COLLAB_DOC";
  contentId: string;
  flaggedBy: string; // userId или "AUTO"
  flagReason: string;
  status: "PENDING" | "REVIEWED_OK" | "REVIEWED_REMOVED";
  createdAt: number;
  reviewedBy?: string;
  reviewedAt?: number;
}
```

### BannedWord (Запрещённое слово)
```typescript
interface BannedWord {
  id: string;
  word: string;
  severity: "WARN" | "AUTO_HIDE";
}
```

## Функциональность

### 1. Фильтр запрещённых слов

При создании сообщения (модуль social) автоматически проверяется наличие запрещённых слов из `BannedWordList`:

- **severity=AUTO_HIDE**: сообщение создаётся с `hidden=true`, автоматически создаётся `ContentFlag` (flaggedBy="AUTO") и запись в `SafetyLog` с actionType="MESSAGE_HIDDEN".
- **severity=WARN**: сообщение остаётся видимым, но создаётся `ContentFlag` со статусом PENDING для проверки учителем.

**Пример:**
```typescript
// Сообщение: "Ты идиот"
// bannedWords: [{ word: "идиот", severity: "AUTO_HIDE" }]
// Результат: message.hidden = true, создаётся ContentFlag и SafetyLogEntry
```

### 2. Очередь модерации для учителя (`/teacher/moderation`)

Учитель видит очередь `ContentFlag` со статусом PENDING для своих групп:
- Фильтрация по статусу (PENDING, REVIEWED_OK, REVIEWED_REMOVED, ALL)
- Просмотр содержимого flagged контента
- Действия: "Оставить" (REVIEWED_OK) или "Удалить" (REVIEWED_REMOVED)
- Каждое решение записывается в SafetyLog

### 3. Журнал безопасности для админа (`/admin/safety-log`)

Полный журнал `SafetyLog` с фильтрами:
- По типу действия (actionType)
- По актору (actorId)
- По диапазону дат (createdAt)
- Read-only доступ (только для роли ADMIN)

### 4. Функция `canViewFullName`

Учитель и админ видят `fullName` пользователей. Ученики видят только `displayName` + аватар везде в UI.

**Проверка во всех местах модуля social:**
- Тандемы: `visibleName(me.role, partner)`
- Peer-review: `visibleName(me.role, author)`
- Чат: `visibleName(me.role, author)`

### 5. Страница правовой информации (`/legal/data-processing`)

Описание сбора и обработки персональных данных:
- Какие данные собираются для учеников, учителей, админов
- Цели обработки данных
- Согласие законных представителей
- Приватность и видимость данных
- Модерация и безопасность
- Ссылки на 152-ФЗ и 436-ФЗ (TODO: согласовать с юристом)

## Вспомогательные функции

### `checkBannedWords(text, bannedWords)`
Проверяет текст на наличие запрещённых слов. Возвращает массив найденных слов с их severity.

### `createSafetyLogEntry(actorId, actionType, targetType, targetId, reason)`
Создаёт запись в SafetyLog с автоматической генерацией id и timestamp.

### `createContentFlag(contentType, contentId, flaggedBy, flagReason)`
Создаёт флаг контента со статусом PENDING.

### `processMessage(db, messageId, content, authorId)`
Полная обработка сообщения: проверка на запрещённые слова, создание флагов и записей в SafetyLog.

## Навигация

### Для учителя:
- `/teacher/moderation` - Очередь модерации и управление запрещёнными словами

### Для админа:
- `/admin/safety-log` - Полный журнал безопасности с фильтрами

### Для всех:
- `/legal/data-processing` - Правовая информация о защите данных

## Тесты

Запуск тестов:
```bash
npx vitest run src/modules/moderation/moderation.test.ts
```

Покрытие:
- `checkBannedWords`: фильтрация запрещённых слов, регистронезависимость, severity
- `createSafetyLogEntry`: создание записей с правильными полями
- `createContentFlag`: создание флагов с правильными полями
- Интеграция: обработка сообщений с AUTO_HIDE и WARN

## Интеграция с другими модулями

- **Social**: `sendMessage` вызывает `checkBannedWords` и создаёт флаги/записи в SafetyLog
- **Reflection**: `addDiaryEntry` может создавать флаги для дневниковых записей
- **Users**: `canViewFullName` используется во всех местах для контроля видимости fullName

## Примеры использования

### Добавление запрещённого слова:
```typescript
addBannedWord("идиот", "AUTO_HIDE");
```

### Проверка флага учителем:
```typescript
reviewFlag("cf1", "REVIEWED_OK"); // Одобрить контент
reviewFlag("cf2", "REVIEWED_REMOVED"); // Удалить контент
```

### Просмотр журнала безопасности:
```typescript
// Фильтр по типу действия
const hiddenMessages = db.safetyLog.filter(e => e.actionType === "MESSAGE_HIDDEN");

// Фильтр по актору
const autoActions = db.safetyLog.filter(e => e.actorId === "AUTO");

// Фильтр по дате
const recentLogs = db.safetyLog.filter(e => e.createdAt > Date.now() - 7 * 24 * 60 * 60 * 1000);
```

## Педагогическая ценность

1. **Безопасность**: Автоматическая защита несовершеннолетних от нежелательного контента
2. **Прозрачность**: Все действия модерации записываются в append-only журнал
3. **Контроль**: Учителя могут просматривать и обрабатывать флаги для своих групп
4. **Гибкость**: Два уровня severity (WARN и AUTO_HIDE) для разных типов нарушений
5. **Подотчётность**: Админы могут отслеживать все действия через SafetyLog
