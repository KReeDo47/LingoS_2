import { useState } from "react";
import { useApp } from "../../lib/store";
import { canViewFullName, inactiveStudents, levelFromPoints, pointsOf, timeAgo } from "../../lib/logic";
import { Avatar, Button, Chip, Icon, INPUT_CLS, Modal, Reveal, SectionTitle } from "../../components/ui";
import type { FieldErrors } from "../../lib/validation";
import type { CEFR } from "../../lib/types";

export function UsersView() {
  const { db, me, addStudent, toast } = useApp();
  const [fullName, setFullName] = useState("");
  const [displayName, setDisplayName] = useState("");
  const [email, setEmail] = useState("");
  const [classGroupId, setClassGroupId] = useState("g1");
  const [cefr, setCefr] = useState<CEFR>("A2");
  const [consent, setConsent] = useState(false);
  const [consentBy, setConsentBy] = useState("");
  const [errors, setErrors] = useState<FieldErrors>({});
  const [created, setCreated] = useState<{ name: string; email: string; tempPassword: string } | null>(null);
  const [copied, setCopied] = useState(false);

  if (!me || me.role === "STUDENT") return null;
  const students = db.users.filter((u) => u.role === "STUDENT");
  const atRisk = inactiveStudents(db, 7);
  const viewFull = canViewFullName(me.role);

  const submit = () => {
    const res = addStudent({ displayName, fullName, email, classGroupId, cefr, consentGiven: consent, consentGivenBy: consentBy });
    if (!res.ok) {
      setErrors(res.errors ?? {});
      if (res.error) toast(res.error, "err");
      return;
    }
    setErrors({});
    setCreated({ name: res.user.displayName, email: res.user.email, tempPassword: res.tempPassword });
    setFullName(""); setDisplayName(""); setEmail(""); setConsent(false); setConsentBy(""); setCopied(false);
    toast("Ученик создан и добавлен в группу");
  };

  const err = (f: string) => (errors[f]?.[0] ? <p className="mt-1 flex items-center gap-1 text-[12px] font-semibold text-coral"><Icon name="alert" size={12} /> {errors[f]![0]}</p> : null);

  return (
    <div className="grid gap-6 lg:grid-cols-[380px_1fr]">
      {/* -------- добавление ученика -------- */}
      <Reveal>
        <div className="rounded-xl border border-line bg-card p-5">
          <SectionTitle kicker="модуль users · только учитель/админ" title="Добавить ученика" />
          <p className="mb-4 -mt-2 text-[12.5px] leading-relaxed text-ink-2">
            Открытой регистрации детей нет: аккаунт создаётся внутри ClassGroup.
            При создании генерируется <b>временный пароль</b> — передайте его ученику лично.
          </p>
          <label className="mb-1 block text-[12px] font-semibold text-ink-2">ФИО (видит только учитель и админ)</label>
          <input className={INPUT_CLS} placeholder="Иванова Анна Сергеевна" value={fullName} onChange={(e) => setFullName(e.target.value)} />
          {err("fullName")}
          <label className="mb-1 mt-3 block text-[12px] font-semibold text-ink-2">displayName — ник (видят сверстники)</label>
          <input className={INPUT_CLS} placeholder="Аня" value={displayName} onChange={(e) => setDisplayName(e.target.value)} />
          {err("displayName")}
          <label className="mb-1 mt-3 block text-[12px] font-semibold text-ink-2">Email (для входа)</label>
          <input className={INPUT_CLS} placeholder="anya@school.ru" value={email} onChange={(e) => setEmail(e.target.value)} />
          {err("email")}
          <div className="mt-3 grid grid-cols-2 gap-3">
            <div>
              <label className="mb-1 block text-[12px] font-semibold text-ink-2">ClassGroup</label>
              <select className={INPUT_CLS} value={classGroupId} onChange={(e) => setClassGroupId(e.target.value)}>
                {db.groups.map((g) => <option key={g.id} value={g.id}>{g.name}</option>)}
              </select>
            </div>
            <div>
              <label className="mb-1 block text-[12px] font-semibold text-ink-2">Уровень CEFR</label>
              <select className={INPUT_CLS} value={cefr} onChange={(e) => setCefr(e.target.value as CEFR)}>
                {(["A1", "A2", "B1", "B2"] as CEFR[]).map((c) => <option key={c} value={c}>{c}</option>)}
              </select>
            </div>
          </div>

          <div className={`mt-4 rounded-xl border-2 p-3.5 transition ${consent ? "border-pine bg-pine-soft/50" : "border-line bg-paper"}`}>
            <label className="flex cursor-pointer items-start gap-3">
              <input type="checkbox" checked={consent} onChange={(e) => setConsent(e.target.checked)} className="mt-0.5 h-4 w-4 accent-[#0c7a5f]" />
              <span className="text-[12.5px] leading-relaxed text-ink-2">
                <b className="text-ink">Согласие законного представителя получено</b> — на обработку
                персональных данных несовершеннолетнего (обязательное поле).
              </span>
            </label>
            {err("consentGiven")}
            {consent && (
              <div className="mt-2.5 pl-7">
                <input className={INPUT_CLS} placeholder="ФИО представителя (кто дал согласие)" value={consentBy} onChange={(e) => setConsentBy(e.target.value)} />
                {err("consentGivenBy")}
              </div>
            )}
          </div>

          <Button className="mt-4 w-full" onClick={submit}><Icon name="key" size={15} /> Создать аккаунт</Button>
        </div>
      </Reveal>

      {/* -------- список учеников -------- */}
      <div>
        <SectionTitle
          kicker={`canViewFullName(${me.role}) = ${String(viewFull)}`}
          title={`Ученики · ${students.length}`}
          right={<Chip tone="sky">fullName {viewFull ? "виден вам" : "скрыт"}</Chip>}
        />
        <div className="overflow-x-auto rounded-xl border border-line bg-card">
          <table className="w-full min-w-[680px] text-left text-[13px]">
            <thead>
              <tr className="border-b border-line text-[11px] uppercase tracking-wider text-ink-3">
                <th className="px-4 py-3 font-bold">Ученик</th>
                <th className="px-3 py-3 font-bold">Группа</th>
                <th className="px-3 py-3 font-bold">Уровень</th>
                <th className="px-3 py-3 font-bold">Баллы</th>
                <th className="px-3 py-3 font-bold">Активность</th>
                <th className="px-3 py-3 font-bold">Согласие (кем, когда)</th>
              </tr>
            </thead>
            <tbody>
              {students.map((u) => {
                const p = pointsOf(db, u.id);
                const lvl = levelFromPoints(p);
                const risk = atRisk.some((a) => a.user.id === u.id);
                const c = db.consents.find((x) => x.userId === u.id);
                return (
                  <tr key={u.id} className={`border-b border-line/60 transition last:border-0 hover:bg-paper-2/50 ${risk ? "bg-amber-soft/40" : ""}`}>
                    <td className="px-4 py-2.5">
                      <div className="flex items-center gap-2.5">
                        <Avatar user={u} size={32} />
                        <div className="leading-tight">
                          <p className="font-bold text-ink">{u.displayName}</p>
                          <p className="text-[11.5px] text-ink-3">{viewFull ? u.fullName : "••• •••••• ••••••••••"}</p>
                        </div>
                      </div>
                    </td>
                    <td className="px-3 py-2.5 text-ink-2">{db.groups.find((g) => g.id === u.classGroupId)?.name}</td>
                    <td className="px-3 py-2.5"><Chip tone="green">{lvl.short} · {u.cefr}</Chip></td>
                    <td className="px-3 py-2.5 font-bold text-ink">{p}</td>
                    <td className="px-3 py-2.5">
                      {risk ? <Chip tone="amber"><Icon name="alert" size={12} /> {timeAgo(u.lastActiveAt)}</Chip> : <span className="text-ink-2">{timeAgo(u.lastActiveAt)}</span>}
                    </td>
                    <td className="px-3 py-2.5">
                      {c ? (
                        <span className="flex items-center gap-1.5 text-[12px] font-semibold text-pine-deep">
                          <Icon name="check" size={14} className="text-pine" /> {c.consentGivenBy} · {new Date(c.consentDate).toLocaleDateString("ru-RU")}
                        </span>
                      ) : (
                        <Icon name="x" size={14} className="text-coral" />
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        <div className="mt-4 flex items-start gap-2.5 rounded-xl border border-sky/25 bg-sky-soft/60 px-4 py-3 text-[12.5px] leading-relaxed text-[#275d7e]">
          <Icon name="shield" size={16} className="mt-0.5 shrink-0" />
          <p>
            Сверстникам в чатах, тандемах и рейтингах показываются только <b>displayName + аватар</b>.
            Колонка с ФИО существует исключительно для ролей TEACHER/ADMIN — функция{" "}
            <code className="rounded bg-card px-1 font-mono text-[11.5px]">canViewFullName()</code> применена во всех местах вывода участников.
          </p>
        </div>
      </div>

      {/* -------- модалка с временным паролем -------- */}
      <Modal open={!!created} onClose={() => setCreated(null)} title="Аккаунт создан">
        {created && (
          <div>
            <p className="text-[13.5px] leading-relaxed text-ink-2">
              Ученик <b className="text-ink">{created.name}</b> ({created.email}) добавлен в группу.
              Покажите ему <b>временный пароль</b> — при первом входе платформа попросит его сменить.
            </p>
            <div className="mt-4 flex items-center gap-2 rounded-xl border-2 border-dashed border-amber bg-amber-soft/50 px-4 py-3">
              <Icon name="key" size={18} className="text-amber" />
              <code className="flex-1 font-mono text-[17px] font-black tracking-wider text-ink">{created.tempPassword}</code>
              <Button size="sm" variant="amber" onClick={() => { navigator.clipboard?.writeText(created.tempPassword).catch(() => undefined); setCopied(true); window.setTimeout(() => setCopied(false), 2000); }}>
                {copied ? <><Icon name="check" size={13} /> Скопировано</> : "Копировать"}
              </Button>
            </div>
            <p className="mt-3 text-[11.5px] text-ink-3">Пароль показывается один раз и не хранится в открытом виде (только хэш).</p>
            <Button className="mt-4 w-full" onClick={() => setCreated(null)}>Понятно</Button>
          </div>
        )}
      </Modal>
    </div>
  );
}
