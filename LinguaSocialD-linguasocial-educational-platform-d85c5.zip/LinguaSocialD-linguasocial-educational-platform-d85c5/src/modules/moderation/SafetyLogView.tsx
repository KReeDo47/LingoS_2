import { useState } from "react";
import { useApp } from "../../lib/store";
import { timeAgo, visibleName } from "../../lib/logic";
import { Avatar, Button, Chip, Icon, Reveal, SectionTitle } from "../../components/ui";
import type { SafetyActionType } from "../../lib/types";

export function SafetyLogView() {
  const { db, me } = useApp();
  const [filterAction, setFilterAction] = useState<SafetyActionType | "ALL">("ALL");
  const [filterActor, setFilterActor] = useState<string>("ALL");
  const [dateFrom, setDateFrom] = useState("");
  const [dateTo, setDateTo] = useState("");

  if (!me || me.role !== "ADMIN") return null;

  const actionTypes: SafetyActionType[] = [
    "MESSAGE_HIDDEN",
    "MESSAGE_DELETED",
    "USER_WARNED",
    "USER_SUSPENDED",
    "CONTENT_FLAGGED",
  ];

  const actors = Array.from(new Set(db.safetyLog.map((e) => e.actorId)));

  const filteredLog = db.safetyLog.filter((entry) => {
    if (filterAction !== "ALL" && entry.actionType !== filterAction) return false;
    if (filterActor !== "ALL" && entry.actorId !== filterActor) return false;
    if (dateFrom) {
      const entryDate = new Date(entry.createdAt);
      const fromDate = new Date(dateFrom);
      if (entryDate < fromDate) return false;
    }
    if (dateTo) {
      const entryDate = new Date(entry.createdAt);
      const toDate = new Date(dateTo);
      toDate.setHours(23, 59, 59, 999);
      if (entryDate > toDate) return false;
    }
    return true;
  });

  const resetFilters = () => {
    setFilterAction("ALL");
    setFilterActor("ALL");
    setDateFrom("");
    setDateTo("");
  };

  return (
    <div className="flex flex-col gap-6">
      <SectionTitle
        kicker="модуль moderation · журнал безопасности"
        title="SafetyLog"
        right={<Chip tone="ink">{filteredLog.length} записей</Chip>}
      />

      {/* Фильтры */}
      <Reveal>
        <div className="rounded-xl border border-line bg-card p-5">
          <h3 className="mb-4 font-display text-[15px] font-bold text-ink">Фильтры</h3>
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            <div>
              <label className="mb-1 block text-[12px] font-semibold text-ink-2">Тип действия</label>
              <select
                className="w-full rounded-lg border-2 border-line bg-card px-3 py-2 text-[13px] font-medium"
                value={filterAction}
                onChange={(e) => setFilterAction(e.target.value as SafetyActionType | "ALL")}
              >
                <option value="ALL">Все</option>
                {actionTypes.map((type) => (
                  <option key={type} value={type}>
                    {type}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="mb-1 block text-[12px] font-semibold text-ink-2">Актор</label>
              <select
                className="w-full rounded-lg border-2 border-line bg-card px-3 py-2 text-[13px] font-medium"
                value={filterActor}
                onChange={(e) => setFilterActor(e.target.value)}
              >
                <option value="ALL">Все</option>
                {actors.map((actorId) => {
                  const actor = db.users.find((u) => u.id === actorId);
                  return (
                    <option key={actorId} value={actorId}>
                      {actor ? visibleName(me.role, actor) : actorId}
                    </option>
                  );
                })}
              </select>
            </div>
            <div>
              <label className="mb-1 block text-[12px] font-semibold text-ink-2">Дата от</label>
              <input
                type="date"
                className="w-full rounded-lg border-2 border-line bg-card px-3 py-2 text-[13px] font-medium"
                value={dateFrom}
                onChange={(e) => setDateFrom(e.target.value)}
              />
            </div>
            <div>
              <label className="mb-1 block text-[12px] font-semibold text-ink-2">Дата до</label>
              <input
                type="date"
                className="w-full rounded-lg border-2 border-line bg-card px-3 py-2 text-[13px] font-medium"
                value={dateTo}
                onChange={(e) => setDateTo(e.target.value)}
              />
            </div>
          </div>
          <div className="mt-4 flex gap-2">
            <Button variant="ghost" onClick={resetFilters}>
              <Icon name="refresh" size={14} /> Сбросить фильтры
            </Button>
          </div>
        </div>
      </Reveal>

      {/* Журнал */}
      <Reveal delay={100}>
        <div className="rounded-xl border border-line bg-card">
          <div className="max-h-[600px] overflow-y-auto">
            {filteredLog.length === 0 ? (
              <div className="px-6 py-10 text-center">
                <Icon name="shield" size={48} className="mx-auto text-ink-3" />
                <p className="mt-4 font-display text-[14px] font-bold text-ink">Нет записей</p>
                <p className="mt-1 text-[12.5px] text-ink-3">Нет записей с выбранными фильтрами</p>
              </div>
            ) : (
              <div className="flex flex-col">
                {filteredLog
                  .slice()
                  .reverse()
                  .map((entry, i) => {
                    const actor = db.users.find((u) => u.id === entry.actorId);
                    const tone =
                      entry.actionType === "MESSAGE_HIDDEN" || entry.actionType === "MESSAGE_DELETED"
                        ? "coral"
                        : entry.actionType === "USER_SUSPENDED" || entry.actionType === "USER_WARNED"
                          ? "amber"
                          : "green";
                    return (
                      <div key={entry.id} className={`flex items-start gap-3 border-b border-line/60 px-4 py-3 last:border-0 ${i % 2 === 0 ? "bg-paper/30" : ""}`}>
                        <Chip tone={tone as "coral" | "amber" | "green"} className="mt-0.5 shrink-0">
                          {entry.actionType}
                        </Chip>
                        <div className="min-w-0 flex-1 leading-tight">
                          <p className="text-[12.5px] font-bold text-ink">
                            {entry.targetType}: {entry.targetId}
                          </p>
                          <p className="text-[11.5px] text-ink-3">{entry.reason}</p>
                          <p className="mt-1 text-[11px] text-ink-3">
                            Актор: {actor ? visibleName(me.role, actor) : entry.actorId}
                          </p>
                        </div>
                        <div className="shrink-0 text-right">
                          <p className="text-[11px] font-semibold text-ink-3">{timeAgo(entry.createdAt)}</p>
                          <p className="text-[10px] text-ink-3">
                            {new Date(entry.createdAt).toLocaleString("ru-RU")}
                          </p>
                        </div>
                      </div>
                    );
                  })}
              </div>
            )}
          </div>
        </div>
      </Reveal>

      <Reveal delay={200}>
        <div className="rounded-xl border border-sky/25 bg-sky-soft/60 px-4 py-3 text-[12.5px] leading-relaxed text-[#275d7e]">
          <p className="flex items-start gap-2">
            <Icon name="shield" size={16} className="mt-0.5 shrink-0" />
            <span>
              <b>SafetyLog</b> — это append-only журнал, который никогда не удаляется. Все действия
              модерации, скрытия сообщений, предупреждения и блокировки пользователей записываются
              сюда автоматически. Это обеспечивает прозрачность и подотчётность всех действий в
              системе.
            </span>
          </p>
        </div>
      </Reveal>
    </div>
  );
}
