import { useCallback, useEffect, useState } from "react";
import type { ReactNode } from "react";
import { AppProvider, useApp } from "./lib/store";
import { Shell } from "./components/shell";
import { Button, Icon } from "./components/ui";
import { AuthPage } from "./views/Auth";
import { AdminView } from "./views/AdminView";
import { ChangePasswordView, DashboardRouter } from "./views/Dashboards";
import { UsersView } from "./modules/users/UsersView";
import { CoursesPage, CourseDetailPage } from "./modules/content/CoursesPages";
import { TaskPlayerPage } from "./modules/content/TaskPlayer";
import { TeacherCoursesPage, CourseEditorPage } from "./modules/content/CourseEditor";
import { SocialView, QuestPage } from "./modules/social/SocialView";
import { MechanicsView } from "./modules/mechanics/MechanicsView";
import { AchievementsPage } from "./modules/mechanics/AchievementsPage";
import { SelfAssessmentOverview } from "./modules/reflection/SelfAssessmentOverview";
import { DiaryPage } from "./modules/reflection/DiaryPage";
import { SelfAssessmentPage } from "./modules/reflection/SelfAssessmentPage";
import { ProgressDashboard } from "./modules/reflection/ProgressDashboard";
import { TeacherGroupDashboard } from "./modules/reflection/TeacherGroupDashboard";
import { ModerationView } from "./modules/moderation/ModerationView";
import { SafetyLogView } from "./modules/moderation/SafetyLogView";
import { LegalPage } from "./views/LegalPage";

function getRoute(): string {
  const h = window.location.hash.replace(/^#\/?/, "");
  return h || "dashboard";
}

function useRouteGuard() {
  const { me } = useApp();
  const [route, setRoute] = useState(getRoute);
  const navigate = useCallback((r: string) => {
    window.location.hash = "/" + r;
    setRoute(r);
    window.scrollTo({ top: 0 });
  }, []);
  useEffect(() => {
    const onHash = () => setRoute(getRoute());
    window.addEventListener("hashchange", onHash);
    return () => window.removeEventListener("hashchange", onHash);
  }, []);
  // Аналог NextAuth middleware (см. middleware.ts для боевого стека):
  // /student/* → STUDENT, /teacher/* → TEACHER|ADMIN, /admin/* → ADMIN.
  let allowed = true;
  if (me) {
    if (route.startsWith("student/") && me.role !== "STUDENT") allowed = false;
    if (route.startsWith("teacher/") && !(me.role === "TEACHER" || me.role === "ADMIN")) allowed = false;
    if (route.startsWith("admin/") && me.role !== "ADMIN") allowed = false;
  }
  return { route, navigate, allowed };
}

function Forbidden({ navigate }: { navigate: (r: string) => void }) {
  const { me } = useApp();
  return (
    <div className="anim-fade-up mx-auto mt-14 max-w-md rounded-2xl border border-coral/30 bg-card p-8 text-center">
      <span className="mx-auto grid h-16 w-16 place-items-center rounded-full bg-coral-soft text-coral">
        <Icon name="lock" size={28} />
      </span>
      <h2 className="mt-4 font-display text-xl font-black text-ink">403 · доступ запрещён</h2>
      <p className="mt-2 text-[13.5px] leading-relaxed text-ink-2">
        Эта страница защищена middleware по роли из сессии. Вы вошли как{" "}
        <b>{me?.role}</b> — прав недостаточно.
      </p>
      <Button className="mt-5" onClick={() => navigate("dashboard")}>
        <Icon name="home" size={15} /> На мой дашборд
      </Button>
    </div>
  );
}

function Router() {
  const { me } = useApp();
  const { route, navigate, allowed } = useRouteGuard();

  if (!me) return <AuthPage navigate={navigate} />;
  if (me.mustChangePassword) return <ChangePasswordView navigate={navigate} />;

  const param = (i: number) => route.split("/")[i] ?? "";
  let page: ReactNode;
  switch (true) {
    /* ---------- дашборды (редирект по роли) ---------- */
    case route === "dashboard":
    case route === "student/dashboard":
    case route === "teacher/dashboard":
    case route === "admin/dashboard":
      page = <DashboardRouter route={route} navigate={navigate} />;
      break;
    /* ---------- модуль content: страницы ученика ---------- */
    case route === "student/courses":
      page = <CoursesPage navigate={navigate} />;
      break;
    case route.startsWith("student/courses/"):
      page = <CourseDetailPage courseId={param(2)} navigate={navigate} />;
      break;
    case route.startsWith("student/tasks/"):
      page = <TaskPlayerPage taskId={param(2)} navigate={navigate} />;
      break;
    /* ---------- модуль content: CRUD учителя/админа ---------- */
    case route === "teacher/courses":
      page = <TeacherCoursesPage navigate={navigate} />;
      break;
    case route === "teacher/courses/new":
      page = <CourseEditorPage courseId={null} navigate={navigate} />;
      break;
    case route.startsWith("teacher/courses/") && route.endsWith("/edit"):
      page = <CourseEditorPage courseId={param(2)} navigate={navigate} />;
      break;
    /* ---------- модуль social ---------- */
    case route === "social":
      page = <SocialView navigate={navigate} />;
      break;
    case route.startsWith("student/quests/"):
      page = <QuestPage questId={param(2)} navigate={navigate} />;
      break;
    case route === "student/achievements":
      page = <AchievementsPage navigate={navigate} />;
      break;
    /* ---------- модуль reflection ---------- */
    case route === "student/diary":
      page = <DiaryPage navigate={navigate} />;
      break;
    case route.startsWith("student/units/") && route.endsWith("/self-assessment"):
      page = <SelfAssessmentPage unitId={param(2)} navigate={navigate} />;
      break;
    case route === "student/dashboard/progress":
      page = <ProgressDashboard navigate={navigate} />;
      break;
    case route.startsWith("teacher/dashboard/group/"):
      page = <TeacherGroupDashboard groupId={param(3)} navigate={navigate} />;
      break;
    /* ---------- остальные модули ---------- */
    case route === "progress":
      page = <MechanicsView />;
      break;
    case route === "reflection":
      page = <SelfAssessmentOverview navigate={navigate} />;
      break;
    case route === "teacher/students":
      page = <UsersView />;
      break;
    case route === "teacher/moderation":
      page = <ModerationView />;
      break;
    case route === "admin/panel":
      page = <AdminView />;
      break;
    case route === "admin/safety-log":
      page = <SafetyLogView />;
      break;
    case route === "legal/data-processing":
      page = <LegalPage navigate={navigate} />;
      break;
    default:
      page = <DashboardRouter route="dashboard" navigate={navigate} />;
  }

  return (
    <Shell route={route} navigate={navigate}>
      {!allowed ? <Forbidden navigate={navigate} /> : page}
    </Shell>
  );
}

export default function App() {
  return (
    <AppProvider>
      <Router />
    </AppProvider>
  );
}
