import { useState } from "react";
import { useApp } from "../../lib/store";
import { findTask, sortedTasks, TASK_TYPE_META, unitProgress } from "./suggest";
import { Button, Chip, Icon, INPUT_CLS, Reveal, SectionTitle } from "../../components/ui";
import type { IconName } from "../../components/ui";

const norm = (s: string) => s.trim().toLowerCase().replace(/\s+/g, " ");

type Nav = (r: string) => void;

/* ================= /student/tasks/[id] — прохождение задания ================= */
export function TaskPlayerPage({ taskId, navigate }: { taskId: string; navigate: Nav }) {
  const { db, me, startTask, completeTask, submitForReview, toast } = useApp();
  const [started, setStarted] = useState(false);
  const [qi, setQi] = useState(0);
  const [picked, setPicked] = useState("");
  const [built, setBuilt] = useState<string[]>([]);
  const [checked, setChecked] = useState(false);
  const [correct, setCorrect] = useState(0);
  const [shake, setShake] = useState(false);
  const [heard, setHeard] = useState(false);
  const [written, setWritten] = useState("");
  const [speaks, setSpeaks] = useState<Record<number, boolean>>({});
  const [toReview, setToReview] = useState(true);
  const [done, setDone] = useState<{ score: number | null } | null>(null);

  if (!me) return null;
  const found = findTask(db, taskId);
  if (!found) {
    return (
      <div className="py-16 text-center">
        <p className="font-display text-lg font-bold text-ink">Задание не найдено</p>
        <Button className="mt-4" onClick={() => navigate("student/courses")}>К курсам</Button>
      </div>
    );
  }
  const { course, unit, task } = found;
  const meta = TASK_TYPE_META[task.type];
  const prog = db.progress.find((p) => p.studentId === me.id && p.taskId === task.id);
  const items = task.content.items ?? [];
  const q = items[qi];

  const back = () => navigate(`student/courses/${course.id}`);

  /* -------- вводный экран -------- */
  if (!started && !done) {
    return (
      <div className="mx-auto max-w-2xl">
        <button onClick={back} className="mb-4 flex cursor-pointer items-center gap-1.5 text-[12.5px] font-bold text-ink-3 transition hover:text-pine">
          <Icon name="arrowRight" size={13} className="rotate-180" /> {course.title} · {unit.title}
        </button>
        <Reveal>
          <div className="rounded-xl border border-line bg-card p-6">
            <div className="flex items-center gap-3">
              <span className="grid h-12 w-12 place-items-center rounded-xl" style={{ background: `hsl(${meta.hue} 50% 90%)`, color: `hsl(${meta.hue} 45% 30%)` }}>
                <Icon name={meta.icon as IconName} size={22} />
              </span>
              <div>
                <p className="text-[11px] font-bold uppercase tracking-[0.14em] text-pine">{unit.title} · {unit.cefrLevel}</p>
                <h2 className="font-display text-xl font-black text-ink">{meta.label} · задание {task.order}</h2>
              </div>
            </div>
            <p className="mt-4 text-[13.5px] leading-relaxed text-ink-2">
              {task.type === "VOCAB" || task.type === "GRAMMAR" ? `Простая форма ответа с мгновенной проверкой: ${items.length} вопроса(ов).` : ""}
              {task.type === "LISTENING" ? "Прослушайте текст (озвучка браузером) и ответьте на вопросы." : ""}
              {task.type === "WRITING" ? `Напишите текст (${task.content.minWords ?? 25}+ слов). Работу можно отправить на peer-review одноклассникам.` : ""}
              {task.type === "SPEAKING_PROMPT" ? "Проговорите ответ вслух и отметьте пункты самопроверки — честно!" : ""}
            </p>
            {task.content.prompt && (
              <p className="mt-3 rounded-lg border border-sky/25 bg-sky-soft/60 px-4 py-3 text-[13.5px] font-semibold leading-relaxed text-[#275d7e]">{task.content.prompt}</p>
            )}
            {prog?.status === "COMPLETED" && prog.score !== null && (
              <Chip tone={prog.score >= 60 ? "green" : "amber"} className="mt-3">Прошлый результат: {prog.score}% — можно перепройти</Chip>
            )}
            <div className="mt-5 flex gap-2">
              <Button size="lg" onClick={() => { startTask(task.id); setStarted(true); }}>Начать <Icon name="arrowRight" size={16} /></Button>
              <Button size="lg" variant="ghost" onClick={back}>Позже</Button>
            </div>
          </div>
        </Reveal>
      </div>
    );
  }

  /* -------- финальный экран -------- */
  if (done) {
    const up = unitProgress(db.progress, me.id, unit);
    return (
      <div className="mx-auto max-w-xl">
        <div className="anim-pop rounded-xl border border-line bg-card p-8 text-center">
          <span className={`mx-auto grid h-20 w-20 place-items-center rounded-full ${done.score !== null && done.score >= 60 ? "bg-pine-soft text-pine" : "bg-amber-soft text-amber"}`}>
            <Icon name={done.score !== null && done.score >= 60 ? "star" : "target"} size={34} strokeWidth={2} />
          </span>
          <h2 className="mt-4 font-display text-3xl font-black text-ink">{done.score !== null ? `${done.score}%` : "Готово!"}</h2>
          <p className="mt-1.5 text-[13.5px] leading-relaxed text-ink-2">
            {done.score !== null ? `Задание «${meta.label}» завершено. ` : ""}
            Юнит «{unit.title}»: {up.done}/{up.total} заданий, обязательных {up.requiredDone}/{up.requiredTotal}.
          </p>
          {done.score !== null && done.score < 60 && (
            <p className="mx-auto mt-3 max-w-sm rounded-lg bg-amber-soft px-3 py-2 text-[12.5px] font-semibold text-[#7a4d0d]">
              Если последние 3 задания юнита дадут средний балл ниже 60%, платформа порекомендует повтор перед новым юнитом.
            </p>
          )}
          <p className="mt-3 text-[11.5px] text-ink-3">TODO: onTaskCompleted(studentId, taskId, score) → модуль mechanics начислит баллы</p>
          <div className="mt-5 flex justify-center gap-2">
            <Button onClick={() => navigate(`student/courses/${course.id}`)}><Icon name="book" size={14} /> К юнитам</Button>
            {up.complete && <Button variant="amber" onClick={() => navigate("social")}><Icon name="users" size={14} /> В сообщество</Button>}
          </div>
        </div>
      </div>
    );
  }

  /* -------- рабочие потоки -------- */

  // WRITING
  if (task.type === "WRITING") {
    const words = written.trim() ? written.trim().split(/\s+/).length : 0;
    const minWords = task.content.minWords ?? 25;
    const finish = () => {
      const score = Math.min(100, 40 + words);
      completeTask(task.id, score);
      if (toReview) {
        const res = submitForReview(task.content.prompt ? "Письмо: " + task.content.prompt.slice(0, 40) : "Моё письмо", written, task.id);
        if (res.ok) toast("Работа отправлена на peer-review");
        else toast("Стоп-фильтр не пропустил текст — проверьте комментарий", "warn");
      }
      setDone({ score });
    };
    return (
      <div className="mx-auto max-w-2xl">
        <Header course={course.title} unitTitle={unit.title} meta={meta} onBack={back} />
        <Reveal>
          <div className="rounded-xl border border-line bg-card p-5">
            <p className="rounded-lg border border-sky/25 bg-sky-soft/60 px-4 py-3 text-[13.5px] font-semibold leading-relaxed text-[#275d7e]">{task.content.prompt}</p>
            <textarea className={`${INPUT_CLS} mt-4 min-h-[220px] leading-relaxed`} placeholder="Write here…" value={written} onChange={(e) => setWritten(e.target.value)} />
            <div className="mt-2 flex items-center justify-between">
              <span className={`text-[12px] font-bold ${words >= minWords ? "text-pine" : "text-ink-3"}`}>{words} слов {words >= minWords ? "✓" : `/ минимум ${minWords}`}</span>
              <label className="flex cursor-pointer items-center gap-2 text-[12.5px] font-semibold text-ink-2">
                <input type="checkbox" checked={toReview} onChange={(e) => setToReview(e.target.checked)} className="h-4 w-4 accent-[#0c7a5f]" />
                Отправить на peer-review
              </label>
            </div>
            <Button className="mt-4" disabled={words < minWords} onClick={finish}><Icon name="send" size={14} /> Завершить задание</Button>
          </div>
        </Reveal>
      </div>
    );
  }

  // SPEAKING_PROMPT
  if (task.type === "SPEAKING_PROMPT") {
    const rubric = task.content.rubric ?? [];
    const allDone = rubric.every((_, i) => speaks[i]);
    return (
      <div className="mx-auto max-w-2xl">
        <Header course={course.title} unitTitle={unit.title} meta={meta} onBack={back} />
        <Reveal>
          <div className="rounded-xl border border-line bg-card p-5">
            <p className="rounded-lg border border-berry/25 bg-[#f5e7ef] px-4 py-3 text-[13.5px] font-semibold leading-relaxed text-[#6d3350]">{task.content.prompt}</p>
            <p className="mt-4 text-[12.5px] font-bold uppercase tracking-wider text-ink-3">Самопроверка — отметьте, что получилось</p>
            <div className="mt-2 flex flex-col gap-2">
              {rubric.map((r, i) => (
                <button key={i} onClick={() => setSpeaks((s) => ({ ...s, [i]: !s[i] }))} className={`flex cursor-pointer items-center gap-3 rounded-lg border-2 px-3.5 py-2.5 text-left transition ${speaks[i] ? "border-pine bg-pine-soft/50" : "border-line bg-paper hover:border-ink-3/40"}`}>
                  <span className={`grid h-6 w-6 shrink-0 place-items-center rounded-full ${speaks[i] ? "bg-pine text-white" : "bg-paper-2 text-ink-3"}`}>{speaks[i] && <Icon name="check" size={13} strokeWidth={3} />}</span>
                  <span className="text-[13px] font-semibold text-ink">{r}</span>
                </button>
              ))}
            </div>
            <Button className="mt-4" disabled={!allDone} onClick={() => { completeTask(task.id, 100); setDone({ score: 100 }); }}>
              <Icon name="mic" size={14} /> Я всё проговорил(а)
            </Button>
          </div>
        </Reveal>
      </div>
    );
  }

  // VOCAB / GRAMMAR / LISTENING — общий поток по items
  const answer = task.type === "GRAMMAR" && q?.options ? built.join(" ") : picked;
  const isRight = checked && q ? norm(answer) === norm(q.answer) : false;

  const listen = () => {
    if (!task.content.audioText) return;
    setHeard(true);
    if ("speechSynthesis" in window) {
      const u1 = new SpeechSynthesisUtterance(task.content.audioText);
      u1.lang = "en-US";
      u1.rate = 0.92;
      window.speechSynthesis.cancel();
      window.speechSynthesis.speak(u1);
    }
  };

  const check = () => {
    if (!answer.trim()) return;
    setChecked(true);
    if (norm(answer) === norm(q.answer)) setCorrect((c) => c + 1);
    else {
      setShake(true);
      window.setTimeout(() => setShake(false), 500);
    }
  };

  const next = () => {
    if (qi + 1 < items.length) {
      setQi(qi + 1);
      setPicked("");
      setBuilt([]);
      setChecked(false);
      return;
    }
    const score = Math.round((correct / items.length) * 100);
    completeTask(task.id, score);
    setDone({ score });
  };

  const showOptions = task.type === "VOCAB" || task.type === "LISTENING";

  return (
    <div className="mx-auto max-w-2xl">
      <Header course={course.title} unitTitle={unit.title} meta={meta} onBack={back} />
      <Reveal>
        <div className="rounded-xl border border-line bg-card p-5">
          <div className="mb-4 flex items-center gap-2">
            {items.map((_, i) => (
              <span key={i} className={`h-1.5 flex-1 rounded-full transition-all duration-300 ${i < qi ? "bg-pine" : i === qi ? "bg-amber" : "bg-line"}`} />
            ))}
            <span className="ml-2 text-[12px] font-bold text-ink-3">{qi + 1}/{items.length}</span>
          </div>

          {task.type === "LISTENING" && (
            <div className="mb-4 flex items-center gap-3 rounded-xl border border-sky/25 bg-sky-soft/50 px-4 py-3">
              <Button size="sm" variant="night" onClick={listen}><Icon name="volume" size={15} /> Прослушать</Button>
              <span className="text-[12px] font-semibold text-[#275d7e]">{heard ? "Текст озвучен браузером (en-US). Вопросы — ниже." : "Сначала послушайте, потом отвечайте."}</span>
            </div>
          )}

          <p className="font-display text-[15px] font-bold leading-snug text-ink">{q?.prompt}</p>

          <div className={`mt-4 ${shake ? "anim-shake" : ""}`}>
            {showOptions && (
              <div className="grid gap-2">
                {q?.options?.map((opt) => {
                  const state = checked ? (norm(opt) === norm(q.answer) ? "right" : opt === picked ? "wrong" : "dim") : "idle";
                  return (
                    <button key={opt} disabled={checked} onClick={() => setPicked(opt)} className={`flex cursor-pointer items-center justify-between rounded-xl border-2 px-4 py-2.5 text-left text-[14px] font-semibold transition-all ${state === "right" ? "border-pine bg-pine-soft text-pine-deep" : state === "wrong" ? "border-coral bg-coral-soft text-[#8f341a]" : state === "dim" ? "border-line bg-paper text-ink-3" : picked === opt ? "border-pine bg-card shadow-sm" : "border-line bg-card hover:border-ink-3/50"}`}>
                      {opt}
                      {state === "right" && <Icon name="check" size={16} strokeWidth={2.6} />}
                      {state === "wrong" && <Icon name="x" size={16} strokeWidth={2.6} />}
                    </button>
                  );
                })}
              </div>
            )}

            {task.type === "GRAMMAR" && q?.options && (
              <div>
                <div className="mb-3 flex min-h-[52px] flex-wrap items-center gap-1.5 rounded-xl border-2 border-dashed border-line bg-paper-2/60 p-2.5">
                  {built.length === 0 && <span className="px-1 text-[13px] text-ink-3">Соберите ответ из слов…</span>}
                  {built.map((w, i) => (
                    <button key={`${w}-${i}`} onClick={() => !checked && setBuilt((b) => b.filter((_, j) => j !== i))} className="anim-pop cursor-pointer rounded-lg bg-night px-2.5 py-1 text-[13px] font-semibold text-paper transition hover:bg-coral">{w}</button>
                  ))}
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {q.options.map((w, i) => {
                    const used = built.filter((x) => x === w).length >= q.options!.filter((x) => x === w).length;
                    return (
                      <button key={`${w}-${i}`} disabled={used || checked} onClick={() => setBuilt((b) => [...b, w])} className={`cursor-pointer rounded-lg border-2 px-2.5 py-1 text-[13px] font-semibold transition ${used ? "border-line text-ink-3 opacity-40" : "border-line bg-card hover:border-pine hover:text-pine"}`}>{w}</button>
                    );
                  })}
                </div>
              </div>
            )}

            {task.type === "GRAMMAR" && !q?.options && (
              <input className={INPUT_CLS} autoFocus placeholder="Введите ответ…" value={picked} disabled={checked} onChange={(e) => setPicked(e.target.value)} onKeyDown={(e) => e.key === "Enter" && (checked ? next() : check())} />
            )}

            {checked && q && (
              <p className={`mt-2.5 text-[13px] font-semibold ${isRight ? "text-pine" : "text-coral"}`}>
                {isRight ? "Верно!" : <>Правильный ответ: <b>{q.answer}</b></>}
              </p>
            )}
            {checked && !isRight && q?.hint && (
              <p className="mt-2 flex items-center gap-1.5 rounded-lg bg-sky-soft px-3 py-2 text-[12.5px] font-semibold text-[#275d7e]"><Icon name="sparkle" size={14} /> {q.hint}</p>
            )}
          </div>

          <div className="mt-5 flex justify-end gap-2">
            {!checked ? (
              <Button onClick={check} disabled={!answer.trim()}>Проверить</Button>
            ) : (
              <Button variant={isRight ? "primary" : "amber"} onClick={next}>
                {qi + 1 < items.length ? "Дальше" : "Завершить"} <Icon name="arrowRight" size={15} />
              </Button>
            )}
          </div>
        </div>
      </Reveal>
    </div>
  );
}

function Header({ course, unitTitle, meta, onBack }: { course: string; unitTitle: string; meta: { label: string; icon: string; hue: number }; onBack: () => void }) {
  return (
    <>
      <button onClick={onBack} className="mb-4 flex cursor-pointer items-center gap-1.5 text-[12.5px] font-bold text-ink-3 transition hover:text-pine">
        <Icon name="arrowRight" size={13} className="rotate-180" /> {course} · {unitTitle}
      </button>
      <div className="mb-4 flex items-center gap-3">
        <span className="grid h-11 w-11 place-items-center rounded-xl" style={{ background: `hsl(${meta.hue} 50% 90%)`, color: `hsl(${meta.hue} 45% 30%)` }}>
          <Icon name={meta.icon as IconName} size={20} />
        </span>
        <div>
          <p className="text-[11px] font-bold uppercase tracking-[0.14em] text-pine">{unitTitle}</p>
          <h2 className="font-display text-lg font-black text-ink">{meta.label}</h2>
        </div>
      </div>
    </>
  );
}

void sortedTasks;
