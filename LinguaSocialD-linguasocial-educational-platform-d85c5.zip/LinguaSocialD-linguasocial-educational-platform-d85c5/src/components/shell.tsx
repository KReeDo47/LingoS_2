import type { ReactNode } from "react";
import { useApp } from "../lib/store";
import { canViewFullName, groupById } from "../lib/logic";
import { Avatar, Chip, Icon } from "./ui";
import type { IconName } from "./ui";
import type { Role } from "../lib/types";

export interface NavItem {
  route: string;
  label: string;
  icon: IconName;
  section: string;
}

export function navFor(role: Role): NavItem[] {
  const student: NavItem[] = [
    { route: "student/dashboard", label: "Обзор", icon: "home", section: "Мой курс" },
    { route: "student/courses", label: "Курсы", icon: "book", section: "Мой курс" },
    { route: "social", label: "Сообщество", icon: "users", section: "Мой курс" },
    { route: "progress", label: "Прогресс", icon: "trophy", section: "Мой курс" },
    { route: "student/achievements", label: "Достижения", icon: "medal", section: "Мой курс" },
    { route: "student/dashboard/progress", label: "Мой прогресс", icon: "chart", section: "Рефлексия" },
    { route: "student/diary", label: "Дневник", icon: "pen", section: "Рефлексия" },
    { route: "reflection", label: "Самооценка", icon: "check", section: "Рефлексия" },
  ];
  if (role === "STUDENT") return student;
  const teacher: NavItem[] = [
    { route: "teacher/dashboard", label: "Дашборд группы", icon: "chart", section: "Кабинет" },
    { route: "teacher/students", label: "Ученики", icon: "users", section: "Кабинет" },
    { route: "teacher/courses", label: "Курсы (CRUD)", icon: "book", section: "Кабинет" },
    { route: "social", label: "Сообщество", icon: "users", section: "Сообщество" },
    { route: "teacher/moderation", label: "Модерация", icon: "shield", section: "Безопасность" },
  ];
  if (role === "TEACHER") return teacher;
  return [
    { route: "admin/dashboard", label: "Обзор", icon: "home", section: "Админ" },
    { route: "admin/panel", label: "Панель платформы", icon: "sliders", section: "Админ" },
    { route: "admin/safety-log", label: "Журнал безопасности", icon: "shield", section: "Админ" },
    ...teacher,
  ];
}

const TITLES: Record<string, string> = {
  "student/dashboard": "Обзор",
  "admin/dashboard": "Обзор",
  "student/courses": "Мои курсы",
  "student/achievements": "Достижения",
  "student/dashboard/progress": "Мой прогресс",
  "student/diary": "Дневник",
  social: "Сообщество",
  progress: "Прогресс",
  reflection: "Самооценка",
  "teacher/dashboard": "Дашборд группы",
  "teacher/students": "Ученики",
  "teacher/courses": "Курсы (CRUD)",
  "teacher/courses/new": "Новый курс",
  "teacher/moderation": "Модерация",
  "admin/panel": "Панель платформы",
  "admin/safety-log": "Журнал безопасности",
  "legal/data-processing": "Обработка персональных данных",
};

function titleFor(route: string): string {
  if (TITLES[route]) return TITLES[route];
  if (route.startsWith("student/courses/")) return "Курс";
  if (route.startsWith("student/tasks/")) return "Задание";
  if (route.startsWith("student/quests/")) return "Квест";
  if (route.startsWith("student/units/") && route.endsWith("/self-assessment")) return "Самооценка";
  if (route.startsWith("teacher/courses/") && route.endsWith("/edit")) return "Редактор курса";
  if (route.startsWith("teacher/dashboard/group/")) return "Дашборд группы";
  return "LinguaSocial";
}

export function Shell({ route, navigate, children }: { route: string; navigate: (r: string) => void; children: ReactNode }) {
  const { db, me, logout, toasts } = useApp();
  if (!me) return null;
  const nav = navFor(me.role);
  const pending = db.queue.filter((q) => q.status === "pending").length;
  const group = groupById(db, me.classGroupId);
  const sections = [...new Set(nav.map((n) => n.section))];

  return (
    <div className="min-h-screen lg:pl-[248px]">
      {/* ---------- sidebar (desktop) ---------- */}
      <aside className="fixed inset-y-0 left-0 z-40 hidden w-[248px] flex-col bg-night text-paper lg:flex">
        <div className="flex items-center gap-2.5 px-5 pb-5 pt-6">
          <span className="grid h-9 w-9 place-items-center rounded-lg bg-pine font-display text-[13px] font-black text-white">Aa</span>
          <div className="font-display leading-tight">
            <p className="text-[15px] font-bold">Lingua<span className="text-amber">Social</span></p>
            <p className="text-[10px] text-paper/50">язык через общение</p>
          </div>
        </div>
        <nav className="flex-1 overflow-y-auto px-3">
          {sections.map((s) => (
            <div key={s} className="mb-4">
              <p className="mb-1.5 px-2 text-[10px] font-bold uppercase tracking-[0.16em] text-paper/35">{s}</p>
              {nav.filter((n) => n.section === s).map((n) => {
                const active = route === n.route;
                return (
                  <button
                    key={n.route}
                    onClick={() => navigate(n.route)}
                    className={`group mb-0.5 flex w-full cursor-pointer items-center gap-2.5 rounded-lg px-2.5 py-2 text-left text-[13.5px] font-semibold transition-all ${
                      active ? "bg-night-3 text-white shadow-inner" : "text-paper/65 hover:bg-night-2 hover:text-paper"
                    }`}
                  >
                    <span className={`grid h-6 w-6 place-items-center rounded-md transition ${active ? "bg-pine text-white" : "bg-night-2 text-paper/50 group-hover:text-paper"}`}>
                      <Icon name={n.icon} size={13} />
                    </span>
                    {n.label}
                    {n.route === "teacher/moderation" && pending > 0 && (
                      <span className="ml-auto rounded-full bg-coral px-1.5 py-px text-[11px] font-bold text-white blink-dot">{pending}</span>
                    )}
                  </button>
                );
              })}
            </div>
          ))}
          <div className="mx-1 mb-4 rounded-lg border border-night-3 bg-night-2/60 p-3 text-[12px] leading-relaxed text-paper/55">
            <p className="mb-1 flex items-center gap-1.5 font-semibold text-paper/80"><Icon name="shield" size={13} className="text-pine" /> Безопасная среда</p>
            Чат только внутри учебной группы. Личные сообщения отключены конструктивно.
          </div>
        </nav>
        <div className="border-t border-night-3 p-3">
          <div className="flex items-center gap-2.5 rounded-lg px-1.5 py-1">
            <Avatar user={me} size={36} />
            <div className="min-w-0 flex-1 leading-tight">
              <p className="truncate text-[13px] font-bold">{canViewFullName(me.role) ? me.fullName : me.displayName}</p>
              <p className="truncate text-[11px] text-paper/50">
                {me.role === "STUDENT" ? `Ученик · ${group?.name ?? "—"}` : me.role === "TEACHER" ? "Учитель" : "Администратор"}
              </p>
            </div>
            <button onClick={logout} title="Выйти" className="grid h-8 w-8 cursor-pointer place-items-center rounded-lg text-paper/50 transition hover:bg-night-3 hover:text-coral">
              <Icon name="logout" size={16} />
            </button>
          </div>
        </div>
      </aside>

      {/* ---------- topbar ---------- */}
      <header className="sticky top-0 z-30 flex items-center justify-between gap-3 border-b border-line bg-paper/85 px-4 py-3 backdrop-blur lg:px-8">
        <div className="flex items-center gap-2.5">
          <span className="grid h-8 w-8 place-items-center rounded-lg bg-pine font-display text-[12px] font-black text-white lg:hidden">Aa</span>
          <h1 className="font-display text-[16px] font-bold text-ink sm:text-lg">{titleFor(route)}</h1>
          {me.role === "STUDENT" && group && <Chip tone="green">{group.name}</Chip>}
        </div>
        <div className="flex items-center gap-2">
          <Chip tone={me.role === "STUDENT" ? "sky" : me.role === "TEACHER" ? "green" : "night"}>
            {me.role === "STUDENT" ? "Ученик" : me.role === "TEACHER" ? "Учитель" : "Админ"}
          </Chip>
          <Avatar user={me} size={32} />
          <button onClick={logout} title="Выйти" className="grid h-8 w-8 cursor-pointer place-items-center rounded-lg text-ink-2 transition hover:bg-paper-2 lg:hidden">
            <Icon name="logout" size={16} />
          </button>
        </div>
      </header>

      <main className="mx-auto max-w-[1120px] px-4 pb-28 pt-6 lg:px-8 lg:pb-14">{children}</main>

      {/* ---------- bottom nav (mobile) ---------- */}
      <nav className="fixed inset-x-0 bottom-0 z-40 border-t border-line bg-card/95 px-2 pb-[max(env(safe-area-inset-bottom),6px)] pt-1.5 backdrop-blur lg:hidden">
        <div className="flex justify-around">
          {nav.slice(0, 6).map((n) => {
            const active = route === n.route;
            return (
              <button key={n.route} onClick={() => navigate(n.route)} className={`relative flex w-14 cursor-pointer flex-col items-center gap-0.5 rounded-lg py-1.5 text-[9.5px] font-semibold transition ${active ? "text-pine" : "text-ink-3"}`}>
                <span className={`grid h-7 w-11 place-items-center rounded-full transition ${active ? "bg-pine-soft" : ""}`}>
                  <Icon name={n.icon} size={17} />
                </span>
                {n.label.split(" ")[0]}
                {n.route === "teacher/moderation" && pending > 0 && <span className="absolute right-1 top-0.5 h-2 w-2 rounded-full bg-coral blink-dot" />}
              </button>
            );
          })}
        </div>
      </nav>

      {/* ---------- toasts ---------- */}
      <div className="pointer-events-none fixed bottom-20 right-4 z-[60] flex w-[min(92vw,360px)] flex-col gap-2 lg:bottom-5">
        {toasts.map((t) => (
          <div
            key={t.id}
            className={`anim-slide-right pointer-events-auto flex items-start gap-2.5 rounded-xl border px-4 py-3 text-[13px] font-semibold shadow-lg ${
              t.tone === "ok" ? "border-pine/25 bg-card text-ink" : t.tone === "warn" ? "border-amber/40 bg-amber-soft text-[#7a4d0d]" : "border-coral/40 bg-coral-soft text-[#8f341a]"
            }`}
          >
            <Icon name={t.tone === "ok" ? "check" : t.tone === "warn" ? "alert" : "shield"} size={16} className={t.tone === "ok" ? "text-pine" : t.tone === "warn" ? "text-amber" : "text-coral"} />
            <span>{t.text}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
