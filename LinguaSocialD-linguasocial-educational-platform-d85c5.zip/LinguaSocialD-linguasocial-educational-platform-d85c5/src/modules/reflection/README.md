# Модуль Reflection (QWEN.md, модуль 5)

Диагностико-рефлексивный блок педагогической модели LinguaSocial.

## Модели данных

### DiaryEntry (Дневник ученика)
```typescript
interface DiaryEntry {
  id: string;
  studentId: string;
  date: string; // YYYY-MM-DD
  promptType: "WHAT_LEARNED" | "WHAT_WAS_HARD" | "WHAT_TO_IMPROVE";
  content: string;
  createdAt: number;
}
```

**Валидация:** Не более одной записи каждого типа в день.

### SelfAssessmentChecklist (Самооценка по юниту)
```typescript
interface SelfAssessmentChecklist {
  id: string;
  unitId: string;
  items: string[]; // "I can..." формулировки
}
```

### SelfAssessmentResponse (Ответы ученика)
```typescript
interface SelfAssessmentResponse {
  studentId: string;
  checklistId: string;
  itemIndex: number;
  checked: boolean;
  respondedAt: number;
}
```

### FeedbackNote (Структурированная обратная связь)
```typescript
interface FeedbackNote {
  id: string;
  taskSubmissionId: string;
  authorId: string; // учитель или система
  whatWentWell: string;
  whatToImprove: string;
  createdAt: number;
}
```

### ClassGroup (добавлено поле)
```typescript
interface ClassGroup {
  // ... существующие поля
  diaryVisibleToTeacher: boolean; // учитель видит содержимое дневников
}
```

## Функциональность

### 1. Дневник ученика (`/student/diary`)
- Три типа записей: "Что узнал", "Что было сложно", "Что улучшу"
- Валидация: не более одной записи каждого типа в день
- История записей с фильтрацией по дате
- Иконки и цветовая кодировка для каждого типа

### 2. Самооценка после юнита (`/student/units/[id]/self-assessment`)
- Автоматическое предложение после завершения юнита
- Чеклист "I can..." формулировок
- Возможность перепрохождения (новая оценка заменяет старую)
- Визуализация прогресса

### 3. Дашборд прогресса ученика (`/student/dashboard/progress`)
- График баллов во времени (LineChart)
- Статистика по уровням CEFR (BarChart)
- Результаты самооценок по юнитам
- Последние записи в дневнике
- Общая статистика (баллы, записи, самооценки)

### 4. Дашборд учителя по группе (`/teacher/dashboard/group/[id]`)
- Агрегированная статистика группы
- График баллов учеников (BarChart)
- Подсветка учеников с падением активности (0 баллов за 7 дней)
- Статистика дневников (количество записей)
- Настраиваемый флаг `diaryVisibleToTeacher`
- Список всех учеников с сортировкой по баллам

### 5. Структурированная обратная связь (`FeedbackNoteForm`)
- Два поля: "Что получилось" и "Что улучшить"
- Привязка к taskSubmissionId
- Шаблоны для быстрой оценки

## Навигация

### Для ученика:
- `/reflection` - Обзор рефлексии (статистика, быстрые действия, список самооценок)
- `/student/dashboard/progress` - Дашборд прогресса (графики, статистика)
- `/student/diary` - Дневник (записи по трём промптам)
- `/student/units/[id]/self-assessment` - Самооценка конкретного юнита

### Для учителя:
- `/teacher/dashboard` - Дашборд группы (автоматически выбирает первую группу учителя)
- `/teacher/dashboard/group/[id]` - Дашборд конкретной группы
- Доступ к дневникам учеников (настраивается флагом `diaryVisibleToTeacher`)
- Возможность оставлять FeedbackNote через форму

## Визуализация (recharts)

Используются следующие графики:
- **LineChart** - динамика баллов во времени
- **BarChart** - сравнение по уровням CEFR, баллам учеников

## Тесты

Запуск тестов:
```bash
npx vitest run src/modules/reflection/reflection.test.ts
```

Покрытие:
- Валидация дневника (не более одной записи каждого типа в день)
- Самооценка (привязка к unitId, замена предыдущей оценки)
- Обратная связь (структурированные поля, привязка к submission)
- Настройки группы (флаг diaryVisibleToTeacher)

## Интеграция с другими модулями

- **Content**: SelfAssessmentChecklist привязан к Unit
- **Mechanics**: PointsLedger используется для графиков прогресса
- **Social**: FeedbackNote может быть связан с TaskSubmission из peer-review

## Примеры использования

### Добавление записи в дневник:
```typescript
addDiaryEntry("WHAT_LEARNED", "Сегодня выучил 10 новых слов");
```

### Отправка самооценки:
```typescript
submitSelfAssessment("sac1", [
  { itemIndex: 0, checked: true },
  { itemIndex: 1, checked: false },
]);
```

### Добавление обратной связи:
```typescript
addFeedbackNote(
  "sub1",
  "Отличная структура текста, хорошее использование лексики",
  "Обратите внимание на согласование времен"
);
```

### Переключение видимости дневников:
```typescript
toggleDiaryVisibility("g1"); // teacher sees content / teacher sees only stats
```

## Педагогическая ценность

1. **Рефлексия**: Ученики учатся анализировать свой прогресс
2. **Самооценка**: Развитие метакогнитивных навыков
3. **Обратная связь**: Структурированный подход к оценке работ
4. **Прозрачность**: Учитель видит прогресс группы без нарушения приватности
5. **Мотивация**: Визуализация прогресса повышает вовлеченность
