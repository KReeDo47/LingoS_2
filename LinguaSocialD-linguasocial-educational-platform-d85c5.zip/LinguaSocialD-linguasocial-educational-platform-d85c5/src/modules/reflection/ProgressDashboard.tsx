import { useApp } from "../../lib/store";
import { pointsOf, timeAgo } from "../../lib/logic";
import { getLevel } from "../mechanics/mechanics";
import { Button, Chip, Icon, Reveal, SectionTitle } from "../../components/ui";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar, Legend } from "recharts";

type Nav = (r: string) => void;

export function ProgressDashboard({ navigate }: { navigate: Nav }) {
  const { db, me } = useApp();

  if (!me) return null;

  const totalPoints = pointsOf(db, me.id);
  const level = getLevel(totalPoints);

  // Данные для графика баллов во времени
  const ledgerData = db.ledger
    .filter((e) => e.userId === me.id)
    .sort((a, b) => a.at - b.at)
    .map((entry, index, arr) => {
      const cumulativePoints = arr.slice(0, index + 1).reduce((sum, e) => sum + e.points, 0);
      return {
        date: new Date(entry.at).toLocaleDateString("ru-RU", { day: "numeric", month: "short" }),
        points: entry.points,
        cumulative: cumulativePoints,
      };
    });

  // Статистика по уровням CEFR
  const courses = db.courses;
  const cefrStats = courses.map((course) => {
    const totalTasks = course.units.reduce((sum, u) => sum + u.tasks.length, 0);
    const completedTasks = course.units.reduce((sum, u) => {
      return sum + u.tasks.filter((t) => {
        const progress = db.progress.find((p) => p.studentId === me.id && p.taskId === t.id);
        return progress?.status === "COMPLETED";
      }).length;
    }, 0);
    const percentage = totalTasks > 0 ? Math.round((completedTasks / totalTasks) * 100) : 0;
    return {
      name: `${course.levelFrom}-${course.levelTo}`,
      completed: completedTasks,
      total: totalTasks,
      percentage,
    };
  });

  // Статистика самооценок
  const selfAssessmentStats = db.selfAssessmentChecklists.map((checklist) => {
    const responses = db.selfAssessmentResponses.filter(
      (r) => r.studentId === me.id && r.checklistId === checklist.id
    );
    const checkedCount = responses.filter((r) => r.checked).length;
    const unit = courses[0]?.units.find((u) => u.id === checklist.unitId);
    return {
      unit: unit?.title || "Unknown",
      checked: checkedCount,
      total: checklist.items.length,
      percentage: Math.round((checkedCount / checklist.items.length) * 100),
    };
  });

  // Статистика дневника
  const diaryStats = {
    total: db.diaryEntries.filter((e) => e.studentId === me.id).length,
    thisWeek: db.diaryEntries.filter((e) => {
      const entryDate = new Date(e.createdAt);
      const weekAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
      return e.studentId === me.id && entryDate >= weekAgo;
    }).length,
  };

  return (
    <div className="flex flex-col gap-6">
      <SectionTitle
        kicker="модуль reflection · дашборд прогресса"
        title="Мой прогресс"
        right={
          <Button variant="ghost" size="sm" onClick={() => navigate("student/dashboard")}>
            <Icon name="arrowRight" size={13} className="rotate-180" /> Назад
          </Button>
        }
      />

      {/* Общая статистика */}
      <div className="grid gap-4 md:grid-cols-3">
        <Reveal>
          <div className="rounded-xl border border-line bg-card p-5">
            <div className="mb-2 flex items-center gap-2">
              <span className="text-2xl">{level.icon}</span>
              <span className="font-display text-lg font-bold text-ink">{level.name}</span>
            </div>
            <p className="text-3xl font-black text-pine">{totalPoints}</p>
            <p className="text-[12px] text-ink-3">баллов всего</p>
          </div>
        </Reveal>

        <Reveal delay={50}>
          <div className="rounded-xl border border-line bg-card p-5">
            <div className="mb-2 flex items-center gap-2">
              <Icon name="pen" size={20} className="text-amber" />
              <span className="font-display text-lg font-bold text-ink">Дневник</span>
            </div>
            <p className="text-3xl font-black text-amber">{diaryStats.total}</p>
            <p className="text-[12px] text-ink-3">записей ({diaryStats.thisWeek} за неделю)</p>
          </div>
        </Reveal>

        <Reveal delay={100}>
          <div className="rounded-xl border border-line bg-card p-5">
            <div className="mb-2 flex items-center gap-2">
              <Icon name="check" size={20} className="text-sky" />
              <span className="font-display text-lg font-bold text-ink">Самооценки</span>
            </div>
            <p className="text-3xl font-black text-sky">{selfAssessmentStats.length}</p>
            <p className="text-[12px] text-ink-3">юнитов оценено</p>
          </div>
        </Reveal>
      </div>

      {/* График баллов во времени */}
      {ledgerData.length > 0 && (
        <Reveal delay={150}>
          <div className="rounded-xl border border-line bg-card p-5">
            <h3 className="mb-4 font-display text-[15px] font-bold text-ink">
              Динамика баллов
            </h3>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={ledgerData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e2e8df" />
                <XAxis dataKey="date" stroke="#748a94" fontSize={12} />
                <YAxis stroke="#748a94" fontSize={12} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "#fbfcf9",
                    border: "1px solid #d8e0d4",
                    borderRadius: "8px",
                  }}
                />
                <Line
                  type="monotone"
                  dataKey="cumulative"
                  stroke="#0c7a5f"
                  strokeWidth={2}
                  name="Всего баллов"
                  dot={{ fill: "#0c7a5f", r: 4 }}
                />
                <Line
                  type="monotone"
                  dataKey="points"
                  stroke="#eda12f"
                  strokeWidth={2}
                  name="За задание"
                  dot={{ fill: "#eda12f", r: 4 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </Reveal>
      )}

      {/* Прогресс по уровням CEFR */}
      <Reveal delay={200}>
        <div className="rounded-xl border border-line bg-card p-5">
          <h3 className="mb-4 font-display text-[15px] font-bold text-ink">
            Прогресс по уровням CEFR
          </h3>
          <ResponsiveContainer width="100%" height={250}>
            <BarChart data={cefrStats}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e2e8df" />
              <XAxis dataKey="name" stroke="#748a94" fontSize={12} />
              <YAxis stroke="#748a94" fontSize={12} />
              <Tooltip
                contentStyle={{
                  backgroundColor: "#fbfcf9",
                  border: "1px solid #d8e0d4",
                  borderRadius: "8px",
                }}
              />
              <Legend />
              <Bar dataKey="completed" fill="#0c7a5f" name="Выполнено" />
              <Bar dataKey="total" fill="#d8e0d4" name="Всего" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </Reveal>

      {/* Самооценки по юнитам */}
      {selfAssessmentStats.length > 0 && (
        <Reveal delay={250}>
          <div className="rounded-xl border border-line bg-card p-5">
            <h3 className="mb-4 font-display text-[15px] font-bold text-ink">
              Результаты самооценок
            </h3>
            <div className="flex flex-col gap-3">
              {selfAssessmentStats.map((stat, index) => (
                <div key={index} className="flex items-center gap-3">
                  <span className="min-w-[150px] text-[13px] font-semibold text-ink">
                    {stat.unit}
                  </span>
                  <div className="flex-1">
                    <div className="h-2 overflow-hidden rounded-full bg-paper-2">
                      <div
                        className="h-full rounded-full bg-sky transition-all"
                        style={{ width: `${stat.percentage}%` }}
                      />
                    </div>
                  </div>
                  <span className="min-w-[60px] text-right text-[12px] font-bold text-ink-3">
                    {stat.checked}/{stat.total}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </Reveal>
      )}

      {/* Последние записи в дневнике */}
      {db.diaryEntries.filter((e) => e.studentId === me.id).length > 0 && (
        <Reveal delay={300}>
          <div className="rounded-xl border border-line bg-card p-5">
            <div className="mb-4 flex items-center justify-between">
              <h3 className="font-display text-[15px] font-bold text-ink">
                Последние записи в дневнике
              </h3>
              <Button variant="ghost" size="sm" onClick={() => navigate("student/diary")}>
                Все записи <Icon name="arrowRight" size={12} />
              </Button>
            </div>
            <div className="flex flex-col gap-3">
              {db.diaryEntries
                .filter((e) => e.studentId === me.id)
                .sort((a, b) => b.createdAt - a.createdAt)
                .slice(0, 3)
                .map((entry) => {
                  const promptInfo = {
                    WHAT_LEARNED: { icon: "💡", color: "bg-pine-soft text-pine-deep" },
                    WHAT_WAS_HARD: { icon: "🎯", color: "bg-amber-soft text-[#8a5a10]" },
                    WHAT_TO_IMPROVE: { icon: "🚀", color: "bg-sky-soft text-[#275d7e]" },
                  }[entry.promptType];
                  return (
                    <div key={entry.id} className="rounded-lg border border-line bg-paper p-3">
                      <div className="mb-1 flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <span className="text-xl">{promptInfo.icon}</span>
                          <span className={`rounded-full px-2 py-0.5 text-[10px] font-bold ${promptInfo.color}`}>
                            {entry.promptType === "WHAT_LEARNED" && "Что узнал"}
                            {entry.promptType === "WHAT_WAS_HARD" && "Что было сложно"}
                            {entry.promptType === "WHAT_TO_IMPROVE" && "Что улучшу"}
                          </span>
                        </div>
                        <span className="text-[11px] text-ink-3">{timeAgo(entry.createdAt)}</span>
                      </div>
                      <p className="text-[12px] leading-relaxed text-ink-2">{entry.content}</p>
                    </div>
                  );
                })}
            </div>
          </div>
        </Reveal>
      )}
    </div>
  );
}
