import { useState } from "react";
import { useApp } from "../../lib/store";
import { uid } from "../../lib/logic";
import { courseSchema, parseWith } from "../../lib/validation";
import { sortedUnits, TASK_TYPE_META } from "./suggest";
import { Button, Chip, Icon, INPUT_CLS, Reveal, SectionTitle } from "../../components/ui";
import type { IconName } from "../../components/ui";
import type { CEFRLevel, Course, Task, TaskContent, TaskType, Unit } from "../../lib/types";

type Nav = (r: string) => void;
const CEFR: CEFRLevel[] = ["A1", "A2", "B1", "B2"];
const TYPES: TaskType[] = ["VOCAB", "GRAMMAR", "LISTENING", "WRITING", "SPEAKING_PROMPT"];

const defaultContent = (type: TaskType): TaskContent => {
  switch (type) {
    case "VOCAB":
    case "LISTENING":
      return { items: [{ prompt: "Новый вопрос?", answer: "answer", options: ["answer", "option 2", "option 3"] }], audioText: type === "LISTENING" ? "Hello! This is a listening text." : undefined };
    case "GRAMMAR":
      return { items: [{ prompt: "She ___ (go) to school.", answer: "goes", hint: "3-е лицо ед. ч." }] };
    case "WRITING":
      return { prompt: "Напишите 5–7 предложений по теме.", minWords: 25, rubric: ["Есть вступление", "Слова по теме", "Правильный порядок слов", "5–7 предложений"] };
    case "SPEAKING_PROMPT":
      return { prompt: "Расскажите 5–6 предложений по теме.", rubric: ["Названо имя/тема", "Есть детали", "Полные предложения"] };
  }
};

/* ================= /teacher/courses — список (CRUD) ================= */
export function TeacherCoursesPage({ navigate }: { navigate: Nav }) {
  const { db, me, deleteCourse, toast } = useApp();
  const [confirmId, setConfirmId] = useState<string | null>(null);
  if (!me) return null;
  return (
    <div>
      <SectionTitle
        kicker="модуль content · CRUD (TEACHER/ADMIN)"
        title="Курсы платформы"
        right={<Button size="sm" onClick={() => navigate("teacher/courses/new")}><Icon name="plus" size={13} /> Новый курс</Button>}
      />
      <div className="grid gap-4 md:grid-cols-2">
        {db.courses.map((c, i) => {
          const units = sortedUnits(c);
          return (
            <Reveal key={c.id} delay={i * 60}>
              <div className="card-hover flex h-full flex-col rounded-xl border border-line bg-card p-5">
                <div className="flex items-start justify-between gap-3">
                  <span className="grid h-12 w-12 place-items-center rounded-xl bg-night font-display text-[15px] font-black uppercase text-amber">{c.languageCode}</span>
                  <Chip tone="sky">{c.levelFrom} → {c.levelTo}</Chip>
                </div>
                <h3 className="mt-3 font-display text-[17px] font-black text-ink">{c.title}</h3>
                <p className="mt-1 line-clamp-2 text-[12.5px] text-ink-2">{c.description}</p>
                <p className="mt-1.5 text-[11.5px] font-semibold text-ink-3">{units.length} юнитов · {units.reduce((s, u) => s + u.tasks.length, 0)} заданий</p>
                <div className="mt-4 flex gap-2 border-t border-line pt-3.5">
                  <Button size="sm" variant="soft" onClick={() => navigate(`teacher/courses/${c.id}/edit`)}><Icon name="pen" size={13} /> Редактировать</Button>
                  {confirmId === c.id ? (
                    <Button size="sm" variant="danger" onClick={() => { deleteCourse(c.id); toast("Курс удалён вместе с прогрессом", "warn"); setConfirmId(null); }}><Icon name="trash" size={13} /> Точно удалить?</Button>
                  ) : (
                    <Button size="sm" variant="ghost" onClick={() => setConfirmId(c.id)}><Icon name="trash" size={13} /> Удалить</Button>
                  )}
                </div>
              </div>
            </Reveal>
          );
        })}
      </div>
    </div>
  );
}

/* ================= /teacher/courses/new и /teacher/courses/[id]/edit ================= */
export function CourseEditorPage({ courseId, navigate }: { courseId: string | null; navigate: Nav }) {
  const { db, me, saveCourse, toast } = useApp();
  const existing = courseId ? db.courses.find((c) => c.id === courseId) : null;
  const [draft, setDraft] = useState<Course>(() =>
    existing
      ? (JSON.parse(JSON.stringify(existing)) as Course)
      : { id: uid("c"), title: "", languageCode: "en", levelFrom: "A1", levelTo: "A2", description: "", units: [] },
  );
  const [errors, setErrors] = useState<string[]>([]);
  if (!me) return null;

  const patch = (p: Partial<Course>) => setDraft((d) => ({ ...d, ...p }));
  const patchUnit = (uidU: string, p: Partial<Unit>) => setDraft((d) => ({ ...d, units: d.units.map((u) => (u.id === uidU ? { ...u, ...p } : u)) }));
  const patchTask = (uidU: string, tid: string, p: Partial<Task>) =>
    setDraft((d) => ({ ...d, units: d.units.map((u) => (u.id === uidU ? { ...u, tasks: u.tasks.map((t) => (t.id === tid ? { ...t, ...p } : t)) } : u)) }));

  const addUnit = () => patch({ units: [...draft.units, { id: uid("u"), courseId: draft.id, title: `Юнит ${draft.units.length + 1}`, order: draft.units.length + 1, cefrLevel: draft.levelFrom, tasks: [] }] });
  const addTask = (unit: Unit, type: TaskType) =>
    patchUnit(unit.id, { tasks: [...unit.tasks, { id: uid("t"), unitId: unit.id, type, content: defaultContent(type), order: unit.tasks.length + 1, requiredForCompletion: true }] });

  const save = () => {
    const res = saveCourse(draft);
    if (!res.ok) {
      const list = Object.entries(res.errors ?? {}).flatMap(([k, v]) => (v ?? []).map((m) => `${k}: ${m}`));
      setErrors(list);
      toast("Проверьте форму — есть ошибки валидации (Zod)", "err");
      return;
    }
    // курс валиден и в реальном стеке здесь будет server action + Prisma write
    const check = parseWith(courseSchema, draft);
    void check;
    toast(existing ? "Курс обновлён" : "Курс создан");
    navigate("teacher/courses");
  };

  return (
    <div className="flex flex-col gap-5">
      <button onClick={() => navigate("teacher/courses")} className="flex w-fit cursor-pointer items-center gap-1.5 text-[12.5px] font-bold text-ink-3 transition hover:text-pine">
        <Icon name="arrowRight" size={13} className="rotate-180" /> Все курсы
      </button>

      <Reveal>
        <div className="rounded-xl border border-line bg-card p-5">
          <SectionTitle kicker={existing ? "редактирование" : "новый курс"} title="Паспорт курса" />
          <div className="grid gap-3 sm:grid-cols-2">
            <div className="sm:col-span-2">
              <label className="mb-1 block text-[12px] font-semibold text-ink-2">Название</label>
              <input className={INPUT_CLS} placeholder="English Quest" value={draft.title} onChange={(e) => patch({ title: e.target.value })} />
            </div>
            <div>
              <label className="mb-1 block text-[12px] font-semibold text-ink-2">Код языка (languageCode)</label>
              <input className={INPUT_CLS} placeholder="en" value={draft.languageCode} onChange={(e) => patch({ languageCode: e.target.value })} />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="mb-1 block text-[12px] font-semibold text-ink-2">levelFrom</label>
                <select className={INPUT_CLS} value={draft.levelFrom} onChange={(e) => patch({ levelFrom: e.target.value as CEFRLevel })}>
                  {CEFR.map((c) => <option key={c} value={c}>{c}</option>)}
                </select>
              </div>
              <div>
                <label className="mb-1 block text-[12px] font-semibold text-ink-2">levelTo</label>
                <select className={INPUT_CLS} value={draft.levelTo} onChange={(e) => patch({ levelTo: e.target.value as CEFRLevel })}>
                  {CEFR.map((c) => <option key={c} value={c}>{c}</option>)}
                </select>
              </div>
            </div>
            <div className="sm:col-span-2">
              <label className="mb-1 block text-[12px] font-semibold text-ink-2">Описание</label>
              <textarea className={INPUT_CLS} rows={2} value={draft.description ?? ""} onChange={(e) => patch({ description: e.target.value })} />
            </div>
          </div>
        </div>
      </Reveal>

      {/* юниты и задания */}
      {draft.units.map((unit, ui) => (
        <Reveal key={unit.id} delay={ui * 50}>
          <div className="rounded-xl border border-line bg-card p-5">
            <div className="grid items-end gap-3 sm:grid-cols-[1fr_120px_100px]">
              <div>
                <label className="mb-1 block text-[12px] font-semibold text-ink-2">Юнит {ui + 1} · название</label>
                <input className={INPUT_CLS} value={unit.title} onChange={(e) => patchUnit(unit.id, { title: e.target.value })} />
              </div>
              <div>
                <label className="mb-1 block text-[12px] font-semibold text-ink-2">cefrLevel</label>
                <select className={INPUT_CLS} value={unit.cefrLevel} onChange={(e) => patchUnit(unit.id, { cefrLevel: e.target.value as CEFRLevel })}>
                  {CEFR.map((c) => <option key={c} value={c}>{c}</option>)}
                </select>
              </div>
              <Button variant="ghost" size="sm" className="mb-0.5" onClick={() => patch({ units: draft.units.filter((u) => u.id !== unit.id).map((u, i) => ({ ...u, order: i + 1 })) })}>
                <Icon name="trash" size={13} /> Удалить
              </Button>
            </div>

            <div className="mt-4 flex flex-col gap-3">
              {unit.tasks.map((task, ti) => (
                <TaskEditor key={task.id} unit={unit} task={task} index={ti} patchTask={patchTask} remove={() => patchUnit(unit.id, { tasks: unit.tasks.filter((t) => t.id !== task.id).map((t, i) => ({ ...t, order: i + 1 })) })} />
              ))}
              <div className="flex flex-wrap items-center gap-1.5">
                <span className="text-[11.5px] font-bold uppercase tracking-wider text-ink-3">Добавить задание:</span>
                {TYPES.map((t) => (
                  <button key={t} onClick={() => addTask(unit, t)} className="flex cursor-pointer items-center gap-1 rounded-full border border-line bg-paper px-2.5 py-1 text-[11.5px] font-bold text-ink-2 transition hover:border-pine hover:text-pine-deep">
                    <Icon name={TASK_TYPE_META[t].icon as IconName} size={11} /> {TASK_TYPE_META[t].label}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </Reveal>
      ))}

      <div className="flex flex-wrap items-center gap-3">
        <Button variant="soft" onClick={addUnit}><Icon name="plus" size={14} /> Добавить юнит</Button>
        <Button size="lg" onClick={save}><Icon name="check" size={15} /> {existing ? "Сохранить изменения" : "Создать курс"}</Button>
        <Button variant="ghost" onClick={() => navigate("teacher/courses")}>Отмена</Button>
      </div>

      {errors.length > 0 && (
        <div className="rounded-xl border border-coral/35 bg-coral-soft/60 px-4 py-3">
          <p className="text-[12.5px] font-black text-[#8f341a]">Zod-валидация не пропустила курс:</p>
          <ul className="mt-1 list-inside list-disc text-[12.5px] font-semibold text-[#8f341a]">
            {errors.map((e, i) => <li key={i}>{e}</li>)}
          </ul>
        </div>
      )}
    </div>
  );
}

/* ================= редактор задания (content Json по типу) ================= */
function TaskEditor({ unit, task, index, patchTask, remove }: {
  unit: Unit; task: Task; index: number;
  patchTask: (unitId: string, taskId: string, p: Partial<Task>) => void;
  remove: () => void;
}) {
  const meta = TASK_TYPE_META[task.type];
  const items = task.content.items ?? [];
  const setItem = (i: number, p: Partial<NonNullable<TaskContent["items"]>[number]>) =>
    patchTask(unit.id, task.id, { content: { ...task.content, items: items.map((it, j) => (j === i ? { ...it, ...p } : it)) } });

  return (
    <div className="rounded-xl border border-line bg-paper p-3.5">
      <div className="flex flex-wrap items-center gap-2">
        <span className="grid h-7 w-7 place-items-center rounded-lg" style={{ background: `hsl(${meta.hue} 50% 88%)`, color: `hsl(${meta.hue} 45% 30%)` }}>
          <Icon name={meta.icon as IconName} size={13} />
        </span>
        <p className="text-[13px] font-black text-ink">Задание {index + 1} · {meta.label}</p>
        <label className="ml-auto flex cursor-pointer items-center gap-1.5 text-[11.5px] font-bold text-ink-2">
          <input type="checkbox" checked={task.requiredForCompletion} onChange={(e) => patchTask(unit.id, task.id, { requiredForCompletion: e.target.checked })} className="h-3.5 w-3.5 accent-[#0c7a5f]" />
          requiredForCompletion
        </label>
        <button onClick={remove} className="grid h-7 w-7 cursor-pointer place-items-center rounded-lg text-ink-3 transition hover:bg-coral-soft hover:text-coral"><Icon name="trash" size={13} /></button>
      </div>

      {(task.type === "VOCAB" || task.type === "GRAMMAR" || task.type === "LISTENING") && (
        <div className="mt-3 flex flex-col gap-2.5">
          {task.type === "LISTENING" && (
            <div>
              <label className="mb-1 block text-[11.5px] font-bold text-ink-3">Текст для озвучки (audioText)</label>
              <textarea className={INPUT_CLS} rows={2} value={task.content.audioText ?? ""} onChange={(e) => patchTask(unit.id, task.id, { content: { ...task.content, audioText: e.target.value } })} />
            </div>
          )}
          {items.map((it, i) => (
            <div key={i} className="rounded-lg border border-line bg-card p-3">
              <div className="grid gap-2 sm:grid-cols-[1fr_180px]">
                <input className={INPUT_CLS} placeholder="Вопрос / пропуск" value={it.prompt} onChange={(e) => setItem(i, { prompt: e.target.value })} />
                <input className={INPUT_CLS} placeholder="Правильный ответ" value={it.answer} onChange={(e) => setItem(i, { answer: e.target.value })} />
              </div>
              {(task.type === "VOCAB" || task.type === "LISTENING") && (
                <input className={`${INPUT_CLS} mt-2`} placeholder="Варианты через запятую (первый — правильный)" value={(it.options ?? []).join(", ")} onChange={(e) => setItem(i, { options: e.target.value.split(",").map((s) => s.trim()).filter(Boolean) })} />
              )}
              {task.type === "GRAMMAR" && (
                <input className={`${INPUT_CLS} mt-2`} placeholder="Подсказка (необязательно)" value={it.hint ?? ""} onChange={(e) => setItem(i, { hint: e.target.value })} />
              )}
            </div>
          ))}
          <Button size="sm" variant="ghost" className="self-start" onClick={() => patchTask(unit.id, task.id, { content: { ...task.content, items: [...items, { prompt: "", answer: "", options: task.type === "GRAMMAR" ? undefined : ["", ""] }] } })}>
            <Icon name="plus" size={12} /> Вопрос
          </Button>
        </div>
      )}

      {(task.type === "WRITING" || task.type === "SPEAKING_PROMPT") && (
        <div className="mt-3 flex flex-col gap-2">
          <div>
            <label className="mb-1 block text-[11.5px] font-bold text-ink-3">Промпт задания</label>
            <textarea className={INPUT_CLS} rows={2} value={task.content.prompt ?? ""} onChange={(e) => patchTask(unit.id, task.id, { content: { ...task.content, prompt: e.target.value } })} />
          </div>
          {task.type === "WRITING" && (
            <div className="w-36">
              <label className="mb-1 block text-[11.5px] font-bold text-ink-3">minWords</label>
              <input type="number" min={5} className={INPUT_CLS} value={task.content.minWords ?? 25} onChange={(e) => patchTask(unit.id, task.id, { content: { ...task.content, minWords: parseInt(e.target.value || "25", 10) } })} />
            </div>
          )}
          <div>
            <label className="mb-1 block text-[11.5px] font-bold text-ink-3">Критерии самопроверки / рубрики (по строке)</label>
            <textarea className={INPUT_CLS} rows={3} value={(task.content.rubric ?? []).join("\n")} onChange={(e) => patchTask(unit.id, task.id, { content: { ...task.content, rubric: e.target.value.split("\n").filter((s) => s.trim()) } })} />
          </div>
        </div>
      )}
    </div>
  );
}
