/* ============================================================
   LinguaSocial · доменные модели (зеркало prisma/schema.prisma)
   Модули: users / content / social / mechanics / reflection / moderation
   ============================================================ */

export type Role = "STUDENT" | "TEACHER" | "ADMIN";

/** CEFR A1–B2 (enum CEFRLevel в Prisma) */
export type CEFRLevel = "A1" | "A2" | "B1" | "B2";
export type CEFR = CEFRLevel;

/* ---------- модуль users (QWEN.md, модуль 1) ---------- */

export interface User {
  id: string;
  role: Role;
  email: string;
  passwordHash: string;
  /** публичный ник — НЕ полное имя */
  displayName: string;
  /** видно только TEACHER/ADMIN (canViewFullName) */
  fullName: string;
  avatarUrl?: string | null;
  /** приватность: показывать ли аватар другим ученикам группы (по умолчанию да) */
  showAvatar: boolean;
  /** после создания учителем — временный пароль, обязательная смена */
  mustChangePassword: boolean;
  hue: number;
  /** только для STUDENT */
  classGroupId: string | null;
  cefr: CEFR;
  lastActiveAt: number;
  createdAt: number;
}

export interface ClassGroup {
  id: string;
  name: string;
  teacherId: string;
  organizationName: string;
  diaryVisibleToTeacher: boolean; // учитель видит содержимое дневников учеников
}

/** Фиксация согласия законного представителя (обязательно для ученика) */
export interface ParentalConsent {
  userId: string;
  consentGivenBy: string;
  consentDate: number;
}

/* ---------- модуль content (QWEN.md, модуль 2) ---------- */

export interface Course {
  id: string;
  title: string;
  languageCode: string; // "en", "de", "fr"…
  levelFrom: CEFRLevel;
  levelTo: CEFRLevel;
  description?: string;
  units: Unit[];
}

export interface Unit {
  id: string;
  courseId: string;
  title: string;
  order: number;
  cefrLevel: CEFRLevel;
  tasks: Task[];
}

export type TaskType = "VOCAB" | "GRAMMAR" | "LISTENING" | "WRITING" | "SPEAKING_PROMPT";

export interface QuestionItem {
  prompt: string;
  answer: string;
  options?: string[];
  hint?: string;
}

/** Гибкая структура под тип задания */
export interface TaskContent {
  /** WRITING / SPEAKING_PROMPT: формулировка задания */
  prompt?: string;
  items?: QuestionItem[];
  /** LISTENING: озвучиваемый текст */
  audioText?: string;
  /** WRITING: минимальное число слов */
  minWords?: number;
  /** WRITING / SPEAKING_PROMPT: пункты для самопроверки/рубрики */
  rubric?: string[];
}

export interface Task {
  id: string;
  unitId: string;
  type: TaskType;
  content: TaskContent;
  order: number;
  requiredForCompletion: boolean;
}

export type ProgressStatus = "NOT_STARTED" | "IN_PROGRESS" | "COMPLETED";

export interface StudentProgress {
  studentId: string;
  taskId: string;
  status: ProgressStatus;
  /** null — ещё не оценено (WRITING / SPEAKING_PROMPT) */
  score: number | null;
  completedAt: number | null;
}

/* ---------- модуль mechanics (QWEN.md, модуль 4) ---------- */

export type LedgerReason = "TASK_COMPLETED" | "PEER_REVIEW_GIVEN" | "QUEST_COMPLETED" | "CHALLENGE_WON";

export interface LedgerEntry {
  id: string;
  userId: string;
  points: number;
  reason: LedgerReason;
  sourceId: string;
  at: number;
}

export interface LevelConfig {
  threshold: number;
  name: string;
  icon: string;
}

export interface Badge {
  id: string;
  code: string;
  title: string;
  description: string;
  iconUrl: string;
}

export interface StudentBadge {
  studentId: string;
  badgeId: string;
  earnedAt: number;
}

export type ChallengeType = "TIMED_QUIZ" | "VOCAB_SPRINT";

export interface Challenge {
  id: string;
  classGroupId: string;
  title: string;
  type: ChallengeType;
  startsAt: number;
  endsAt: number;
  teamBased: boolean;
}

export interface ChallengeResult {
  challengeId: string;
  studentId: string | null;
  teamId: string | null;
  score: number;
  rank: number;
}

export interface MentorRole {
  studentId: string;
  grantedAt: number;
  revokedAt: number | null;
}

/* ---------- модуль social (QWEN.md, модуль 3) ---------- */

/** Почему создана пара: ZPD_MENTOR — сильный+слабый, PEER — примерно равные */
export type PairedReason = "ZPD_MENTOR" | "PEER";

export interface LanguageTandem {
  id: string;
  studentAId: string;
  studentBId: string;
  classGroupId: string;
  pairedReason: PairedReason;
  createdAt: number;
  active: boolean;
}

export interface QuestRole {
  name: string;
  /** назначает учитель */
  assignedTo: string | null;
  done: boolean;
}

export type QuestStatus = "active" | "done" | "archived";

export interface GroupQuest {
  id: string;
  classGroupId: string;
  title: string;
  description: string;
  roles: QuestRole[];
  deadline: number;
  status: QuestStatus;
  bonus: number;
  contributions: string[];
}

export interface CollaborativeDoc {
  id: string;
  classGroupId: string;
  /** документ принадлежит квесту ИЛИ тандему (либо общий групповой) */
  groupQuestId?: string;
  tandemId?: string;
  title: string;
  content: string;
  updatedAt: number;
}

/** История правок документа — отдельная таблица, снапшоты при каждом сохранении */
export interface CollaborativeDocRevision {
  id: string;
  docId: string;
  authorId: string;
  contentSnapshot: string;
  createdAt: number;
}

/** Работа ученика, выставленная на peer-review (в т.ч. из WRITING-заданий) */
export interface TaskSubmission {
  id: string;
  taskId: string | null;
  studentId: string;
  title: string;
  content: string;
  at: number;
}

export interface RubricScore {
  criteria: string;
  value: number; // 1..5
}

export interface PeerReview {
  id: string;
  taskSubmissionId: string;
  reviewerId: string;
  rubricScores: RubricScore[];
  comment: string;
  createdAt: number;
}

/** Критерии рубрики peer-review (1–5 по каждому) */
export const RUBRIC_CRITERIA = ["Содержание и идея", "Словарный запас", "Грамматика", "Связность и оформление"];

/** Сообщение чата: принадлежит ТОЛЬКО учебной группе, не произвольному диалогу */
export interface ModeratedMessage {
  id: string;
  classGroupId: string;
  authorId: string;
  content: string;
  createdAt: number;
  /** для модерации: скрытые не возвращаются обычным пользователям */
  hidden: boolean;
  hiddenReason: string | null;
}

/* ---------- модуль moderation (QWEN.md, модуль 6) ---------- */

export type SafetyActionType = 
  | "MESSAGE_HIDDEN" 
  | "MESSAGE_DELETED" 
  | "USER_WARNED" 
  | "USER_SUSPENDED" 
  | "CONTENT_FLAGGED";

export interface SafetyLogEntry {
  id: string;
  actorId: string; // userId или "AUTO"
  actionType: SafetyActionType;
  targetType: string; // "MESSAGE", "DIARY_ENTRY", "COLLAB_DOC", "USER"
  targetId: string;
  reason: string;
  createdAt: number;
}

export type ContentType = "MESSAGE" | "DIARY_ENTRY" | "COLLAB_DOC";
export type FlagStatus = "PENDING" | "REVIEWED_OK" | "REVIEWED_REMOVED";

export interface ContentFlag {
  id: string;
  contentType: ContentType;
  contentId: string;
  flaggedBy: string; // userId или "AUTO"
  flagReason: string;
  status: FlagStatus;
  createdAt: number;
  reviewedBy?: string;
  reviewedAt?: number;
}

export type BannedWordSeverity = "WARN" | "AUTO_HIDE";

export interface BannedWord {
  id: string;
  word: string;
  severity: BannedWordSeverity;
}

export interface QueueItem {
  id: string;
  messageId: string;
  reason: string;
  status: "pending" | "approved" | "removed";
  at: number;
}

/* ---------- модуль reflection ---------- */

export type DiaryPromptType = "WHAT_LEARNED" | "WHAT_WAS_HARD" | "WHAT_TO_IMPROVE";

export interface DiaryEntry {
  id: string;
  studentId: string;
  date: string; // YYYY-MM-DD
  promptType: DiaryPromptType;
  content: string;
  createdAt: number;
}

export interface SelfAssessmentChecklist {
  id: string;
  unitId: string;
  items: string[]; // "I can..." формулировки
}

export interface SelfAssessmentResponse {
  studentId: string;
  checklistId: string;
  itemIndex: number;
  checked: boolean;
  respondedAt: number;
}

export interface FeedbackNote {
  id: string;
  taskSubmissionId: string;
  authorId: string; // учитель или система
  whatWentWell: string;
  whatToImprove: string;
  createdAt: number;
}

export type ReflectionType = "learned" | "hard" | "improve";

export interface ReflectionEntry {
  id: string;
  userId: string;
  type: ReflectionType;
  text: string;
  at: number;
}

export interface ChecklistState {
  userId: string;
  /** canDoId -> 0 нет / 1 почти / 2 уверенно */
  items: Record<string, number>;
  updatedAt: number;
}

export interface CanDoItem {
  id: string;
  text: string;
  cefr: CEFR;
}

/* ---------- DB ---------- */

export interface DB {
  version: number;
  sessionId: string | null;
  users: User[];
  groups: ClassGroup[];
  consents: ParentalConsent[];
  courses: Course[];
  progress: StudentProgress[];
  ledger: LedgerEntry[];
  badges: Badge[];
  studentBadges: StudentBadge[];
  challenges: Challenge[];
  challengeResults: ChallengeResult[];
  mentorRoles: MentorRole[];
  tandems: LanguageTandem[];
  quests: GroupQuest[];
  docs: CollaborativeDoc[];
  docRevisions: CollaborativeDocRevision[];
  submissions: TaskSubmission[];
  peerReviews: PeerReview[];
  messages: ModeratedMessage[];
  queue: QueueItem[];
  safetyLog: SafetyLogEntry[];
  contentFlags: ContentFlag[];
  bannedWords: BannedWord[];
  reflections: ReflectionEntry[];
  diaryEntries: DiaryEntry[];
  selfAssessmentChecklists: SelfAssessmentChecklist[];
  selfAssessmentResponses: SelfAssessmentResponse[];
  feedbackNotes: FeedbackNote[];
  checklists: ChecklistState[];
  canDoList: CanDoItem[];
}
