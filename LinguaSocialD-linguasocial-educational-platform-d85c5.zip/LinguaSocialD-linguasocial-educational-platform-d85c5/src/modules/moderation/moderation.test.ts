/* ============================================================
   Модуль moderation · unit-тесты
   Запуск: npx vitest run src/modules/moderation/moderation.test.ts
   ============================================================ */
import { describe, expect, it } from "vitest";
import { checkBannedWords, createContentFlag, createSafetyLogEntry } from "./moderation";
import type { BannedWord, ContentFlag, SafetyLogEntry } from "../../lib/types";

describe("checkBannedWords — фильтр запрещённых слов", () => {
  const bannedWords: BannedWord[] = [
    { id: "bw1", word: "дурак", severity: "WARN" },
    { id: "bw2", word: "идиот", severity: "AUTO_HIDE" },
    { id: "bw3", word: "глупый", severity: "AUTO_HIDE" },
  ];

  it("не находит запрещённых слов в чистом тексте", () => {
    const result = checkBannedWords("Привет, как дела?", bannedWords);
    expect(result).toHaveLength(0);
  });

  it("находит одно запрещённое слово", () => {
    const result = checkBannedWords("Ты дурак", bannedWords);
    expect(result).toHaveLength(1);
    expect(result[0].word).toBe("дурак");
    expect(result[0].severity).toBe("WARN");
  });

  it("находит несколько запрещённых слов", () => {
    const result = checkBannedWords("Ты дурак и идиот", bannedWords);
    expect(result).toHaveLength(2);
    expect(result.map((r) => r.word)).toContain("дурак");
    expect(result.map((r) => r.word)).toContain("идиот");
  });

  it("регистронезависимый поиск", () => {
    const result = checkBannedWords("ТЫ ДУРАК", bannedWords);
    expect(result).toHaveLength(1);
    expect(result[0].word).toBe("дурак");
  });

  it("различает severity: WARN и AUTO_HIDE", () => {
    const result = checkBannedWords("Ты дурак и глупый", bannedWords);
    expect(result).toHaveLength(2);
    const warn = result.find((r) => r.word === "дурак");
    const autoHide = result.find((r) => r.word === "глупый");
    expect(warn?.severity).toBe("WARN");
    expect(autoHide?.severity).toBe("AUTO_HIDE");
  });
});

describe("createSafetyLogEntry — создание записи в журнале", () => {
  it("создаёт запись с правильными полями", () => {
    const entry = createSafetyLogEntry("u1", "MESSAGE_HIDDEN", "MESSAGE", "m1", "Тестовая причина");
    expect(entry.id).toMatch(/^sl-/);
    expect(entry.actorId).toBe("u1");
    expect(entry.actionType).toBe("MESSAGE_HIDDEN");
    expect(entry.targetType).toBe("MESSAGE");
    expect(entry.targetId).toBe("m1");
    expect(entry.reason).toBe("Тестовая причина");
    expect(entry.createdAt).toBeGreaterThan(0);
  });

  it("поддерживает все типы действий", () => {
    const actions: Array<SafetyLogEntry["actionType"]> = [
      "MESSAGE_HIDDEN",
      "MESSAGE_DELETED",
      "USER_WARNED",
      "USER_SUSPENDED",
      "CONTENT_FLAGGED",
    ];
    actions.forEach((action) => {
      const entry = createSafetyLogEntry("u1", action, "MESSAGE", "m1", "Тест");
      expect(entry.actionType).toBe(action);
    });
  });
});

describe("createContentFlag — создание флага контента", () => {
  it("создаёт флаг с правильными полями", () => {
    const flag = createContentFlag("MESSAGE", "m1", "AUTO", "Запрещённое слово");
    expect(flag.id).toMatch(/^cf-/);
    expect(flag.contentType).toBe("MESSAGE");
    expect(flag.contentId).toBe("m1");
    expect(flag.flaggedBy).toBe("AUTO");
    expect(flag.flagReason).toBe("Запрещённое слово");
    expect(flag.status).toBe("PENDING");
    expect(flag.createdAt).toBeGreaterThan(0);
  });

  it("поддерживает все типы контента", () => {
    const types: Array<ContentFlag["contentType"]> = ["MESSAGE", "DIARY_ENTRY", "COLLAB_DOC"];
    types.forEach((type) => {
      const flag = createContentFlag(type, "c1", "AUTO", "Тест");
      expect(flag.contentType).toBe(type);
    });
  });

  it("поддерживает flaggedBy = userId", () => {
    const flag = createContentFlag("MESSAGE", "m1", "u-teacher1", "Ручной флаг");
    expect(flag.flaggedBy).toBe("u-teacher1");
  });
});

describe("Интеграция: обработка сообщения", () => {
  it("сообщение с AUTO_HIDE словом должно быть скрыто", () => {
    const bannedWords: BannedWord[] = [
      { id: "bw1", word: "идиот", severity: "AUTO_HIDE" },
    ];
    const violations = checkBannedWords("Ты идиот", bannedWords);
    const autoHideViolations = violations.filter((v) => v.severity === "AUTO_HIDE");
    expect(autoHideViolations.length).toBeGreaterThan(0);
  });

  it("сообщение с WARN словом не должно быть скрыто автоматически", () => {
    const bannedWords: BannedWord[] = [
      { id: "bw1", word: "дурак", severity: "WARN" },
    ];
    const violations = checkBannedWords("Ты дурак", bannedWords);
    const autoHideViolations = violations.filter((v) => v.severity === "AUTO_HIDE");
    expect(autoHideViolations.length).toBe(0);
  });

  it("сообщение с обоими типами слов должно быть скрыто", () => {
    const bannedWords: BannedWord[] = [
      { id: "bw1", word: "дурак", severity: "WARN" },
      { id: "bw2", word: "идиот", severity: "AUTO_HIDE" },
    ];
    const violations = checkBannedWords("Ты дурак и идиот", bannedWords);
    const autoHideViolations = violations.filter((v) => v.severity === "AUTO_HIDE");
    expect(autoHideViolations.length).toBeGreaterThan(0);
  });
});
